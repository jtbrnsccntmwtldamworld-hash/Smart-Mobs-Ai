# Smart Mobs AI

A Fabric mod for Minecraft 1.20.1 that expands mob behavior, reactions, interactions, and gameplay systems.

## Requirements

- Minecraft 1.20.1
- Java 17
- Fabric Loader 0.19.3 or newer
- Fabric API

## Development

Clone the repository and run:

```text
./gradlew build
```

On Windows:

```text
gradlew.bat build
```

The project uses Fabric Loom and separate main/client source sets.

## License

See `LICENSE` for the current project license.
