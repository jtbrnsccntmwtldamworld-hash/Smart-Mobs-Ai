package com.smartanimals;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;

public class ModSounds {


    public static final SoundEvent UI_CLICK =
            register(
                    "ui.click",
                    SoundEvent.createVariableRangeEvent(
                            new ResourceLocation(
                                    "smartanimals",
                                    "ui.click"
                            )
                    )
            );

    private static SoundEvent register(
            String name,
            SoundEvent soundEvent
    ) {
        return Registry.register(
                BuiltInRegistries.SOUND_EVENT,
                new ResourceLocation(
                        "smartanimals",
                        name
                ),
                soundEvent
        );
    }

    public static void register() {
    }
}
