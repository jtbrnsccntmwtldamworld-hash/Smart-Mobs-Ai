package com.smartanimals.ai;

import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.monster.Pillager;
import net.minecraft.world.entity.player.Player;

import java.util.EnumSet;
import java.util.Random;

public class PillagerRetreatGoal extends Goal {

    private final Pillager pillager;


    private static final double MIN_DISTANCE = 4.0D;


    private static final double RETREAT_DISTANCE = 7.0D;


    private static final double SPEED = 1.2D;

    private static final Random RANDOM =
            new Random();

    private Player target;

    private double targetX;
    private double targetY;
    private double targetZ;

    public PillagerRetreatGoal(
            Pillager pillager) {

        this.pillager = pillager;


        this.setFlags(
                EnumSet.of(Flag.MOVE)
        );
    }

    @Override
    public boolean canUse() {


        if (this.pillager.getTarget() == null) {
            return false;
        }


        if (!(this.pillager.getTarget()
                instanceof Player)) {

            return false;
        }

        Player player =
                (Player) this.pillager.getTarget();


        if (!player.isAlive()) {
            return false;
        }


        if (this.pillager.distanceToSqr(player)
                >= MIN_DISTANCE * MIN_DISTANCE) {

            return false;
        }

        this.target = player;

        chooseRetreatPosition();

        return true;
    }

    @Override
    public boolean canContinueToUse() {

        if (this.target == null) {
            return false;
        }

        if (!this.target.isAlive()) {
            return false;
        }


        return this.pillager.distanceToSqr(
                this.target
        ) < MIN_DISTANCE * MIN_DISTANCE;
    }

    @Override
    public void start() {

        retreat();
    }

    @Override
    public void tick() {


        if (this.pillager.getNavigation().isDone()) {

            chooseRetreatPosition();

            retreat();
        }
    }

    @Override
    public void stop() {

        this.target = null;

        this.pillager.getNavigation().stop();
    }

    private void chooseRetreatPosition() {

        if (this.target == null) {
            return;
        }


        double dx =
                this.pillager.getX()
                - this.target.getX();

        double dz =
                this.pillager.getZ()
                - this.target.getZ();

        double distance =
                Math.sqrt(
                        dx * dx +
                        dz * dz
                );


        if (distance < 0.001D) {

            double angle =
                    RANDOM.nextDouble()
                    * Math.PI * 2.0D;

            dx = Math.cos(angle);
            dz = Math.sin(angle);

        } else {

            dx /= distance;
            dz /= distance;
        }

        double randomAngle =
                (RANDOM.nextDouble() - 0.5D)
                * 0.7D;

        double rotatedX =
                dx * Math.cos(randomAngle)
                - dz * Math.sin(randomAngle);

        double rotatedZ =
                dx * Math.sin(randomAngle)
                + dz * Math.cos(randomAngle);

        dx = rotatedX;
        dz = rotatedZ;


        this.targetX =
                this.pillager.getX()
                + dx * RETREAT_DISTANCE;

        this.targetY =
                this.pillager.getY();

        this.targetZ =
                this.pillager.getZ()
                + dz * RETREAT_DISTANCE;
    }

    private void retreat() {

        this.pillager.getNavigation().moveTo(
                this.targetX,
                this.targetY,
                this.targetZ,
                SPEED
        );
    }
}