package com.smartanimals.ai;

import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Sheep;

import java.util.EnumSet;
import java.util.List;

public class SheepNightGroupGoal extends Goal {

    private final Sheep sheep;
    private final double speed;

    private Sheep targetSheep;

    private static final int CHECK_COOLDOWN = 10;
    private int checkTimer;

    public SheepNightGroupGoal(Sheep sheep, double speed) {
        this.sheep = sheep;
        this.speed = speed;

        this.setFlags(EnumSet.of(Flag.MOVE));
    }

    @Override
    public boolean canUse() {

        if (this.sheep.level().isDay()) {
            return false;
        }


        if (this.checkTimer > 0) {
            this.checkTimer--;
            return false;
        }

        List<Sheep> nearbySheep =
                this.sheep.level().getEntitiesOfClass(
                        Sheep.class,
                        this.sheep.getBoundingBox().inflate(10.0D)
                );

        Sheep nearestSheep = null;
        double nearestDistance = Double.MAX_VALUE;

        for (Sheep other : nearbySheep) {

            if (other == this.sheep) {
                continue;
            }

            double distance =
                    this.sheep.distanceToSqr(other);

            if (distance < 16.0D) {
                continue;
            }

            if (distance < nearestDistance) {
                nearestDistance = distance;
                nearestSheep = other;
            }
        }


        this.checkTimer = CHECK_COOLDOWN;

        if (nearestSheep == null) {
            return false;
        }

        this.targetSheep = nearestSheep;

        return true;
    }

    @Override
    public boolean canContinueToUse() {

        if (this.sheep.level().isDay()) {
            return false;
        }

        if (this.targetSheep == null) {
            return false;
        }

        if (!this.targetSheep.isAlive()) {
            return false;
        }

        return this.sheep.distanceToSqr(
                this.targetSheep
        ) > 16.0D;
    }

    @Override
    public void start() {
        moveToGroup();
    }

    @Override
    public void tick() {

        if (this.targetSheep == null) {
            return;
        }

        if (this.sheep.getNavigation().isDone()) {
            moveToGroup();
        }
    }

    @Override
    public void stop() {

        this.targetSheep = null;
        this.checkTimer = 0;
        this.sheep.getNavigation().stop();
    }

    private void moveToGroup() {

        if (this.targetSheep == null) {
            return;
        }

        this.sheep.getNavigation().moveTo(
                this.targetSheep,
                this.speed
        );
    }
}