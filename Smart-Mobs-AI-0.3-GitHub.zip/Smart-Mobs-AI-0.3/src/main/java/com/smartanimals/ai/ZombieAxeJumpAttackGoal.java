 package com.smartanimals.ai;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;

import java.util.EnumSet;

public class ZombieAxeJumpAttackGoal extends Goal {

    private final Zombie zombie;

    private int attackCooldown = 0;

    private int jumpTicks = 0;

    private boolean jumping = false;

    private boolean attackDone = false;

    private static final int ATTACK_COOLDOWN = 15;

    private static final double START_DISTANCE = 3.0D;

    private static final double ATTACK_DISTANCE = 2.7D;

    private static final double JUMP_SPEED = 0.35D;

    private static final double JUMP_POWER = 0.5D;

    private static final double MAX_HEIGHT_DIFFERENCE = 3.0D;

    public ZombieAxeJumpAttackGoal(Zombie zombie) {

        this.zombie = zombie;

        setFlags(
                EnumSet.of(
                        Flag.MOVE,
                        Flag.LOOK
                )
        );
    }

    @Override
    public boolean canUse() {

        LivingEntity target =
                zombie.getTarget();

        if (target == null) {
            return false;
        }

        if (!target.isAlive()) {
            return false;
        }


        if (!isHoldingAxe()) {
            return false;
        }


        if (attackCooldown > 0) {

            attackCooldown--;

            return false;
        }


        return zombie.distanceToSqr(target)
                <= START_DISTANCE * START_DISTANCE;
    }

    @Override
    public boolean canContinueToUse() {

        LivingEntity target =
                zombie.getTarget();

        if (target == null) {
            return false;
        }

        if (!target.isAlive()) {
            return false;
        }

        if (!isHoldingAxe()) {
            return false;
        }


        if (jumping) {
            return jumpTicks < 30;
        }

        return zombie.distanceToSqr(target)
                <= 64.0D;
    }

    @Override
    public void start() {

        jumpTicks = 0;

        jumping = false;

        attackDone = false;
    }

    @Override
    public void stop() {

        jumping = false;

        attackDone = false;

        jumpTicks = 0;

        zombie.getNavigation().stop();
    }

    @Override
    public void tick() {

        LivingEntity target =
                zombie.getTarget();

        if (target == null) {
            return;
        }

        if (!target.isAlive()) {
            return;
        }

        if (!isHoldingAxe()) {
            return;
        }


        zombie.getLookControl().setLookAt(
                target,
                30.0F,
                30.0F
        );



        if (!jumping) {


            double dx =
                    target.getX()
                            - zombie.getX();

            double dz =
                    target.getZ()
                            - zombie.getZ();

            double horizontalDistance =
                    Math.sqrt(
                            dx * dx
                                    + dz * dz
                    );

            double zombieY =
                    zombie.getBoundingBox()
                            .getCenter()
                            .y;

            double targetY =
                    target.getBoundingBox()
                            .getCenter()
                            .y;

            double heightDifference =
                    targetY - zombieY;

            if (attackCooldown > 0) {

                attackCooldown--;

                if (horizontalDistance
                        > ATTACK_DISTANCE) {

                    zombie.getNavigation().moveTo(
                            target,
                            1.0D
                    );
                }

                return;
            }

            if (horizontalDistance
                    > 1.5D
                    || heightDifference
                    > MAX_HEIGHT_DIFFERENCE) {

                zombie.getNavigation().moveTo(
                        target,
                        1.0D
                );

                return;
            }



            zombie.getNavigation().stop();

            jumping = true;
            jumpTicks = 0;

            attackDone = false;

            jumpTowardsTarget(target);

            return;
        }



        jumpTicks++;





        if (!attackDone
                && !zombie.onGround()
                && zombie.getDeltaMovement().y < -0.05D) {

            double distance =
                    zombie.distanceToSqr(target);

            if (distance <=
                    ATTACK_DISTANCE * ATTACK_DISTANCE) {

                performCriticalAttack(target);

                attackDone = true;
            }
        }



        if (jumping && zombie.onGround()) {


            if (!attackDone) {

                double distance =
                        zombie.distanceToSqr(target);

                if (distance <=
                        ATTACK_DISTANCE * ATTACK_DISTANCE) {

                    performAxeAttack(target);

                    attackDone = true;
                }
            }


            jumping = false;

            attackCooldown =
                    ATTACK_COOLDOWN;


            zombie.getNavigation().stop();

            return;
        }


        if (jumpTicks > 30) {

            jumping = false;

            attackCooldown = 20;

            zombie.getNavigation().stop();
        }
    }



    private void jumpTowardsTarget(
            LivingEntity target) {

        double dx =
                target.getX()
                        - zombie.getX();

        double dz =
                target.getZ()
                        - zombie.getZ();

        double distance =
                Math.sqrt(
                        dx * dx
                                + dz * dz
                );

        if (distance < 0.01D) {

            double vertical =
                    target.getBoundingBox()
                            .getCenter()
                            .y
                            - zombie.getBoundingBox()
                                    .getCenter()
                                    .y;

            if (vertical > 0.0D) {

                zombie.setDeltaMovement(
                        0.0D,
                        JUMP_POWER,
                        0.0D
                );

                zombie.hasImpulse = true;
            }

            return;
        }

        double directionX =
                dx / distance;

        double directionZ =
                dz / distance;


        zombie.setDeltaMovement(
                directionX * JUMP_SPEED,
                JUMP_POWER,
                directionZ * JUMP_SPEED
        );

        zombie.hasImpulse = true;
    }



    private void performCriticalAttack(
            LivingEntity target) {


        if (zombie.distanceToSqr(target)
                > ATTACK_DISTANCE * ATTACK_DISTANCE) {

            return;
        }


        zombie.getLookControl().setLookAt(
                target,
                30.0F,
                30.0F
        );


        double attackDamage =
                zombie.getAttributeValue(
                        Attributes.ATTACK_DAMAGE
                );


        float criticalDamage =
                (float) Math.max(
                        1.0D,
                        attackDamage * 1.75D
                );


        boolean hit =
                target.hurt(
                        zombie.damageSources().mobAttack(
                                zombie
                        ),
                        criticalDamage
                );

        if (!hit) {
            return;
        }


        zombie.swing(
                InteractionHand.MAIN_HAND
        );


        spawnCriticalParticles(target);
    }



    private void performAxeAttack(
            LivingEntity target) {

        if (zombie.distanceToSqr(target)
                > ATTACK_DISTANCE * ATTACK_DISTANCE) {

            return;
        }

        boolean hit =
                zombie.doHurtTarget(target);

        if (!hit) {
            return;
        }

        zombie.swing(
                InteractionHand.MAIN_HAND
        );

        spawnCriticalParticles(target);
    }



    private void spawnCriticalParticles(
            LivingEntity target) {

        if (!(zombie.level()
                instanceof ServerLevel serverLevel)) {

            return;
        }

        serverLevel.sendParticles(
                ParticleTypes.CRIT,

                target.getX(),
                target.getY() + 1.0D,
                target.getZ(),

                12,

                0.35D,
                0.5D,
                0.35D,

                0.15D
        );
    }



    private boolean isHoldingAxe() {

        ItemStack stack =
                zombie.getMainHandItem();

        return stack.getItem()
                instanceof AxeItem;
    }
}
