package com.smartanimals.ai;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PiglinTradeData extends SavedData {

    private static final String DATA_NAME = "smartanimals_piglin_trades";

    private static final int OFFER_COUNT = 5;

    private final Map<String, TradeData[]> trades = new HashMap<>();

    public PiglinTradeData() {
    }

    public static PiglinTradeData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(
                PiglinTradeData::load,
                PiglinTradeData::new,
                DATA_NAME
        );
    }

    private static String createKey(UUID piglinUuid, UUID playerUuid) {
        return piglinUuid.toString() + "_" + playerUuid.toString();
    }

    @Override
    public CompoundTag save(CompoundTag tag) {

        CompoundTag tradesTag = new CompoundTag();

        for (Map.Entry<String, TradeData[]> entry : trades.entrySet()) {

            CompoundTag offerTag = new CompoundTag();

            TradeData[] list = entry.getValue();

            for (int i = 0; i < OFFER_COUNT; i++) {

                if (list[i] != null) {
                    offerTag.put(
                            "Offer" + i,
                            list[i].save()
                    );
                }
            }

            tradesTag.put(
                    entry.getKey(),
                    offerTag
            );
        }

        tag.put(
                "Trades",
                tradesTag
        );

        return tag;
    }

    public static PiglinTradeData load(CompoundTag tag) {

        PiglinTradeData data = new PiglinTradeData();

        if (!tag.contains("Trades")) {
            return data;
        }

        CompoundTag tradesTag = tag.getCompound("Trades");

        for (String key : tradesTag.getAllKeys()) {

            CompoundTag offerTag =
                    tradesTag.getCompound(key);

            TradeData[] list =
                    new TradeData[OFFER_COUNT];

            for (int i = 0; i < OFFER_COUNT; i++) {

                String offerKey =
                        "Offer" + i;

                if (offerTag.contains(offerKey)) {

                    list[i] =
                            TradeData.load(
                                    offerTag.getCompound(offerKey)
                            );
                }
            }

            data.trades.put(
                    key,
                    list
            );
        }

        return data;
    }

    public TradeData[] getTrades(
            UUID piglinUuid,
            UUID playerUuid
    ) {

        String key =
                createKey(
                        piglinUuid,
                        playerUuid
                );

        return trades.computeIfAbsent(
                key,
                ignored -> new TradeData[OFFER_COUNT]
        );
    }

    public TradeData getTrade(
            UUID piglinUuid,
            UUID playerUuid,
            int index
    ) {

        if (index < 0 || index >= OFFER_COUNT) {
            return null;
        }

        return getTrades(
                piglinUuid,
                playerUuid
        )[index];
    }

    public void setTrade(
            UUID piglinUuid,
            UUID playerUuid,
            int index,
            TradeData trade
    ) {

        if (index < 0 || index >= OFFER_COUNT) {
            return;
        }

        TradeData[] list =
                getTrades(
                        piglinUuid,
                        playerUuid
                );

        list[index] = trade;

        setDirty();
    }

    public static class TradeData {

        private String rewardId = "";

        private int price;
        private int amount;
        private int purchaseLimit;
        private int purchases;

        public TradeData() {
        }
        public TradeData(
                String rewardId,
                int price,
                int amount,
                int purchaseLimit
        ) {

            this.rewardId =
                    rewardId == null
                            ? ""
                            : rewardId;

            this.price =
                    Math.max(0, price);

            this.amount =
                    Math.max(0, amount);

            this.purchaseLimit =
                    Math.max(0, purchaseLimit);

            this.purchases = 0;
        }

        public String getRewardId() {
            return rewardId;
        }

        public int getPrice() {
            return price;
        }

        public int getAmount() {
            return amount;
        }

        public int getPurchaseLimit() {
            return purchaseLimit;
        }

        public int getPurchases() {
            return purchases;
        }

        public int getRemaining() {

            return Math.max(
                    0,
                    purchaseLimit - purchases
            );
        }

        public boolean canPurchase() {

            return purchases <
                    purchaseLimit;
        }

        public boolean addPurchase() {

            if (!canPurchase()) {
                return false;
            }

            purchases++;

            return true;
        }

        public CompoundTag save() {

            CompoundTag tag =
                    new CompoundTag();

            tag.putString(
                    "RewardId",
                    rewardId
            );

            tag.putInt(
                    "Price",
                    price
            );

            tag.putInt(
                    "Amount",
                    amount
            );

            tag.putInt(
                    "PurchaseLimit",
                    purchaseLimit
            );

            tag.putInt(
                    "Purchases",
                    purchases
            );

            return tag;
        }

        public static TradeData load(
                CompoundTag tag
        ) {

            TradeData data =
                    new TradeData();

            data.rewardId =
                    tag.getString(
                            "RewardId"
                    );

            data.price =
                    Math.max(
                            0,
                            tag.getInt("Price")
                    );

            data.amount =
                    Math.max(
                            0,
                            tag.getInt("Amount")
                    );

            data.purchaseLimit =
                    Math.max(
                            0,
                            tag.getInt("PurchaseLimit")
                    );

            data.purchases =
                    Math.max(
                            0,
                            tag.getInt("Purchases")
                    );

            return data;
        }
    }
}