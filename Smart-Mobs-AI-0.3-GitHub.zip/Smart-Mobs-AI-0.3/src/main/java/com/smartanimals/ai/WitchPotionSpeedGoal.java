package com.smartanimals.ai;

import net.minecraft.world.entity.ai.goal.RangedAttackGoal;
import net.minecraft.world.entity.monster.Witch;

public class WitchPotionSpeedGoal extends RangedAttackGoal {

    private final Witch witch;

    public WitchPotionSpeedGoal(
            Witch witch,
            double speed,
            int attackInterval,
            float attackRadius) {

        super(
                witch,
                speed,
                attackInterval,
                attackRadius
        );

        this.witch = witch;
    }

    @Override
    public boolean canUse() {

        if (!this.witch.isAlive()) {
            return false;
        }

        if (this.witch.getTarget() == null) {
            return false;
        }

        if (!this.witch.getTarget().isAlive()) {
            return false;
        }


        return super.canUse();
    }

    @Override
    public boolean canContinueToUse() {

        if (!this.witch.isAlive()) {
            return false;
        }

        if (this.witch.getTarget() == null) {
            return false;
        }

        if (!this.witch.getTarget().isAlive()) {
            return false;
        }


        return super.canContinueToUse();
    }
}