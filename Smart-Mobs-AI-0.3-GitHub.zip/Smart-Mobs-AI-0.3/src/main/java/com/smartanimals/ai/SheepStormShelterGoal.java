package com.smartanimals.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Sheep;

import java.util.EnumSet;

public class SheepStormShelterGoal extends Goal {

    private final Sheep sheep;
    private final double speed;

    private BlockPos shelterTarget;

    private static final double SEARCH_RADIUS = 12.0D;

    public SheepStormShelterGoal(Sheep sheep, double speed) {
        this.sheep = sheep;
        this.speed = speed;

        this.setFlags(EnumSet.of(Flag.MOVE));
    }

    @Override
    public boolean canUse() {

        if (!this.sheep.level().isThundering()) {
            return false;
        }


        if (isUnderLeaves()) {
            return false;
        }

        this.shelterTarget = findShelter();

        return this.shelterTarget != null;
    }

    @Override
    public boolean canContinueToUse() {

        if (!this.sheep.level().isThundering()) {
            return false;
        }

        if (isUnderLeaves()) {
            return false;
        }

        return this.shelterTarget != null;
    }

    @Override
    public void start() {
        moveToShelter();
    }

    @Override
    public void tick() {

        if (this.sheep.getNavigation().isDone()) {
            this.shelterTarget = findShelter();

            if (this.shelterTarget != null) {
                moveToShelter();
            }
        }
    }

    @Override
    public void stop() {
        this.shelterTarget = null;
        this.sheep.getNavigation().stop();
    }

    private void moveToShelter() {

        if (this.shelterTarget == null) {
            return;
        }

        this.sheep.getNavigation().moveTo(
                shelterTarget.getX() + 0.5D,
                shelterTarget.getY(),
                shelterTarget.getZ() + 0.5D,
                this.speed
        );
    }

    private boolean isUnderLeaves() {

        BlockPos.MutableBlockPos pos =
                new BlockPos.MutableBlockPos(
                        this.sheep.getBlockX(),
                        this.sheep.getBlockY() + 1,
                        this.sheep.getBlockZ()
                );


        for (int y = 0; y < 4; y++) {

            if (this.sheep.level()
                    .getBlockState(pos)
                    .is(BlockTags.LEAVES)) {

                return true;
            }

            pos.move(0, 1, 0);
        }

        return false;
    }

    private BlockPos findShelter() {

        int centerX = this.sheep.getBlockX();
        int centerY = this.sheep.getBlockY();
        int centerZ = this.sheep.getBlockZ();

        BlockPos best = null;
        double bestDistance = Double.MAX_VALUE;


        for (int x = -12; x <= 12; x++) {

            for (int z = -12; z <= 12; z++) {

                for (int y = -3; y <= 5; y++) {

                    if (x * x + z * z > SEARCH_RADIUS * SEARCH_RADIUS) {
                        continue;
                    }

                    BlockPos leavesPos =
                            new BlockPos(
                                    centerX + x,
                                    centerY + y,
                                    centerZ + z
                            );

                    if (!this.sheep.level()
                            .getBlockState(leavesPos)
                            .is(BlockTags.LEAVES)) {

                        continue;
                    }


                    BlockPos standPos =
                            leavesPos.below();
                    if (!this.sheep.level()
                            .getBlockState(standPos)
                            .isAir()) {

                        continue;
                    }

                    double distance =
                            this.sheep.distanceToSqr(
                                    standPos.getX() + 0.5D,
                                    standPos.getY(),
                                    standPos.getZ() + 0.5D
                            );

                    if (distance < bestDistance) {

                        bestDistance = distance;
                        best = standPos;
                    }
                }
            }
        }

        return best;
    }
}