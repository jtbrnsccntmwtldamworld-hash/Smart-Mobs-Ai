 package com.smartanimals.ai;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class PiglinBarterMenu extends AbstractContainerMenu {

    public static final int PAGE_COUNT = 5;



    public static final int GOLD_SLOT_1 = 0;
    public static final int GOLD_SLOT_2 = 1;
    public static final int REWARD_SLOT = 2;

    public static final int TRADE_SLOT_Y = 64;

    public static final int GOLD_SLOT_1_X = 52;
    public static final int GOLD_SLOT_2_X = 82;
    public static final int REWARD_SLOT_X = 148;

    public static final int INVENTORY_START_X = 29;
    public static final int INVENTORY_START_Y = 143;

    public static final int HOTBAR_Y = 201;

    public static final int SLOT_SIZE = 18;
    public static final int INVENTORY_COLUMNS = 9;
    public static final int INVENTORY_ROWS = 3;



    private static final int DATA_COUNT = 5;

    private static final int DATA_HAS_TRADE = 0;
    private static final int DATA_PRICE = 1;
    private static final int DATA_AMOUNT = 2;
    private static final int DATA_LIMIT = 3;
    private static final int DATA_PURCHASES = 4;



    private final Container barterContainer;
    private final Piglin piglin;
    private final Player player;
    private final ContainerData tradeData;

    private int currentPage;



    public PiglinBarterMenu(
            int containerId,
            Inventory playerInventory
    ) {
        this(
                containerId,
                playerInventory,
                new SimpleContainer(3),
                null
        );
    }



    public PiglinBarterMenu(
            int containerId,
            Inventory playerInventory,
            Piglin piglin
    ) {
        this(
                containerId,
                playerInventory,
                new SimpleContainer(3),
                piglin
        );
    }



    public PiglinBarterMenu(
            int containerId,
            Inventory playerInventory,
            Container barterContainer,
            Piglin piglin
    ) {

        super(
                PiglinBarterMenuType.PIGLIN_BARTER_MENU,
                containerId
        );

        this.barterContainer = barterContainer;
        this.piglin = piglin;
        this.player = playerInventory.player;
        this.currentPage = 0;


        this.tradeData = new ContainerData() {

            private final int[] values =
                    new int[DATA_COUNT];

            @Override
            public int get(int index) {

                if (index < 0 || index >= DATA_COUNT) {
                    return 0;
                }

                return values[index];
            }

            @Override
            public void set(
                    int index,
                    int value
            ) {

                if (index < 0 || index >= DATA_COUNT) {
                    return;
                }

                values[index] = value;
            }

            @Override
            public int getCount() {
                return DATA_COUNT;
            }
        };

        addDataSlots(tradeData);



        addSlot(
                new Slot(
                        barterContainer,
                        GOLD_SLOT_1,
                        GOLD_SLOT_1_X,
                        TRADE_SLOT_Y
                ) {

                    @Override
                    public boolean mayPlace(
                            ItemStack stack
                    ) {

                        return stack.is(
                                Items.GOLD_INGOT
                        );
                    }
                }
        );

        addSlot(
                new Slot(
                        barterContainer,
                        GOLD_SLOT_2,
                        GOLD_SLOT_2_X,
                        TRADE_SLOT_Y
                ) {

                    @Override
                    public boolean mayPlace(
                            ItemStack stack
                    ) {

                        return stack.is(
                                Items.GOLD_INGOT
                        );
                    }
                }
        );

        addSlot(
                new Slot(
                        barterContainer,
                        REWARD_SLOT,
                        REWARD_SLOT_X,
                        TRADE_SLOT_Y
                ) {

                    @Override
                    public boolean mayPlace(
                            ItemStack stack
                    ) {

                        return false;
                    }

                    @Override
                    public boolean mayPickup(
                            Player player
                    ) {

                        return false;
                    }
                }
        );



        addPlayerInventory(playerInventory);



        if (piglin != null) {

            PiglinTrading.start(
                    piglin,
                    player
            );

            refreshTradeData();
            updateResult();
        }
    }



    private void addPlayerInventory(
            Inventory inventory
    ) {



        for (int row = 0;
             row < INVENTORY_ROWS;
             row++) {

            for (int column = 0;
                 column < INVENTORY_COLUMNS;
                 column++) {

                addSlot(
                        new Slot(
                                inventory,
                                column + row * 9 + 9,
                                INVENTORY_START_X
                                        + column * SLOT_SIZE,
                                INVENTORY_START_Y
                                        + row * SLOT_SIZE
                        )
                );
            }
        }



        for (int column = 0;
             column < INVENTORY_COLUMNS;
             column++) {

            addSlot(
                    new Slot(
                            inventory,
                            column,
                            INVENTORY_START_X
                                    + column * SLOT_SIZE,
                            HOTBAR_Y
                    )
            );
        }
    }



    public int getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(
            int page
    ) {

        if (page < 0) {
            page = 0;
        }

        if (page >= PAGE_COUNT) {
            page = PAGE_COUNT - 1;
        }

        currentPage = page;

        if (piglin != null) {

            refreshTradeData();
            updateResult();
        }
    }



    @Override
    public boolean clickMenuButton(
            Player player,
            int id
    ) {

        if (id < 0 || id >= PAGE_COUNT) {
            return false;
        }

        currentPage = id;

        refreshTradeData();
        updateResult();

        return true;
    }



    private void refreshTradeData() {

        if (piglin == null) {
            clearTradeData();
            return;
        }

        PiglinTradeData.TradeData trade =
                PiglinTrading.getTrade(
                        piglin,
                        player,
                        currentPage
                );

        if (trade == null) {
            clearTradeData();
            return;
        }

        tradeData.set(
                DATA_HAS_TRADE,
                1
        );

        tradeData.set(
                DATA_PRICE,
                Math.max(
                        0,
                        trade.getPrice()
                )
        );

        tradeData.set(
                DATA_AMOUNT,
                Math.max(
                        0,
                        trade.getAmount()
                )
        );

        tradeData.set(
                DATA_LIMIT,
                Math.max(
                        0,
                        trade.getPurchaseLimit()
                )
        );

        tradeData.set(
                DATA_PURCHASES,
                Math.max(
                        0,
                        trade.getPurchases()
                )
        );
    }



    private void clearTradeData() {

        for (int i = 0;
             i < DATA_COUNT;
             i++) {

            tradeData.set(
                    i,
                    0
            );
        }

        barterContainer.setItem(
                REWARD_SLOT,
                ItemStack.EMPTY
        );
    }



    public boolean hasTrade() {

        return tradeData.get(
                DATA_HAS_TRADE
        ) != 0;
    }

    public int getPrice() {
        return tradeData.get(
                DATA_PRICE
        );
    }
    public int getPurchaseLimit() {

        return tradeData.get(
                DATA_LIMIT
        );
    }

    public int getPurchases() {

        return tradeData.get(
                DATA_PURCHASES
        );
    }

    public int getRemaining() {

        return Math.max(
                0,
                getPurchaseLimit()
                        - getPurchases()
        );
    }


    private int getGoldCount() {

        return getGoldCount(GOLD_SLOT_1)
                + getGoldCount(GOLD_SLOT_2);
    }

    private int getGoldCount(
            int slot
    ) {

        ItemStack stack =
                barterContainer.getItem(
                        slot
                );

        if (stack.isEmpty()
                || !stack.is(Items.GOLD_INGOT)) {

            return 0;
        }

        return stack.getCount();
    }



    public void updateResult() {

        if (piglin == null) {
            return;
        }

        PiglinTradeData.TradeData trade =
                PiglinTrading.getTrade(
                        piglin,
                        player,
                        currentPage
                );

        if (trade == null
                || !trade.canPurchase()) {

            barterContainer.setItem(
                    REWARD_SLOT,
                    ItemStack.EMPTY
            );

            refreshTradeData();
            return;
        }

        PiglinTradeReward reward =
                findReward(
                        trade.getRewardId()
                );

        if (reward == null) {

            barterContainer.setItem(
                    REWARD_SLOT,
                    ItemStack.EMPTY
            );

            refreshTradeData();
            return;
        }

        ItemStack result =
                PiglinTradeItemFactory.createReward(
                        reward,
                        trade.getAmount()
                );

        barterContainer.setItem(
                REWARD_SLOT,
                result
        );

        refreshTradeData();
    }



    private PiglinTradeReward findReward(
            String id
    ) {

        if (id == null || id.isEmpty()) {
            return null;
        }

        for (PiglinTradeReward reward :
                PiglinTradeRandomizer.getRewards()) {

            if (reward == null) {
                continue;
            }

            if (createRewardId(reward).equals(id)) {
                return reward;
            }
        }



        if (id.equals("silent_blade")) {

            for (PiglinTradeReward reward :
                    PiglinTradeRandomizer.getRewards()) {

                if (reward != null
                        && reward.isSilentBlade()) {

                    return reward;
                }
            }
        }

        return null;
    }

    private String createRewardId(
            PiglinTradeReward reward
    ) {

        if (reward == null) {
            return "";
        }

        if (reward.isSilentBlade()) {

            return "silent_blade|"
                    + reward.getType().name();
        }

        if (reward.getItem() == null) {
            return "";
        }


        return net.minecraft.core.registries.BuiltInRegistries.ITEM
                .getKey(reward.getItem())
                .toString()
                + "|"
                + reward.getType().name();
    }



    private void performTrade() {

        if (piglin == null) {
            return;
        }

        PiglinTradeData.TradeData trade =
                PiglinTrading.getTrade(
                        piglin,
                        player,
                        currentPage
                );

        if (trade == null
                || !trade.canPurchase()) {

            return;
        }

        int price =
                trade.getPrice();

        if (price <= 0) {
            return;
        }

        if (getGoldCount() < price) {
            return;
        }

        PiglinTradeReward reward =
                findReward(
                        trade.getRewardId()
                );

        if (reward == null) {
            return;
        }

        ItemStack result =
                PiglinTradeItemFactory.createReward(
                        reward,
                        trade.getAmount()
                );

        if (result.isEmpty()) {
            return;
        }

        if (!PiglinTrading.canPurchase(
                piglin,
                player,
                currentPage
        )) {

            return;
        }



        removeGold(price);



        boolean purchased =
                PiglinTrading.purchase(
                        piglin,
                        player,
                        currentPage
                );



        if (!purchased) {

            giveReward(
                    new ItemStack(
                            Items.GOLD_INGOT,
                            price
                    )
            );

            refreshTradeData();
            updateResult();

            return;
        }



        awardOhShiny();



        giveReward(result);

        refreshTradeData();
        updateResult();
    }



    private void awardOhShiny() {



        if (!(player instanceof ServerPlayer serverPlayer)) {
            return;
        }

        if (serverPlayer.getServer() == null) {
            return;
        }

        var advancement =
                serverPlayer
                        .getServer()
                        .getAdvancements()
                        .getAdvancement(
                                new ResourceLocation(
                                        "minecraft",
                                        "nether/distract_piglin"
                                )
                        );

        if (advancement == null) {
            return;
        }

        serverPlayer.getAdvancements().award(
                advancement,
                "distract_piglin_directly"
        );
    }



    private void removeGold(
            int amount
    ) {

        int remaining = amount;

        remaining =
                removeGoldFromSlot(
                        GOLD_SLOT_1,
                        remaining
                );

        if (remaining > 0) {
            removeGoldFromSlot(
                    GOLD_SLOT_2,
                    remaining
            );
        }
    }

    private int removeGoldFromSlot(
            int slot,
            int amount
    ) {

        if (amount <= 0) {
            return 0;
        }

        ItemStack stack =
                barterContainer.getItem(
                        slot
                );

        if (stack.isEmpty()
                || !stack.is(Items.GOLD_INGOT)) {

            return amount;
        }

        int removed =
                Math.min(
                        amount,
                        stack.getCount()
                );

        stack.shrink(removed);

        if (stack.isEmpty()) {

            barterContainer.setItem(
                    slot,
                    ItemStack.EMPTY
            );
        }

        return amount - removed;
    }



    private void giveReward(
            ItemStack stack
    ) {

        if (stack.isEmpty()) {
            return;
        }

        if (!player.getInventory().add(stack)) {

            player.drop(
                    stack,
                    false
            );
        }
    }



    @Override
    public void clicked(
            int slotId,
            int button,
            ClickType clickType,
            Player player
    ) {



        if (slotId == REWARD_SLOT) {

            if (clickType == ClickType.PICKUP
                    && button == 0) {

                performTrade();
            }

            if (clickType == ClickType.QUICK_MOVE) {

                performTrade();
            }

            return;
        }



        super.clicked(
                slotId,
                button,
                clickType,
                player
        );



        if (slotId == GOLD_SLOT_1
                || slotId == GOLD_SLOT_2) {

            updateResult();
        }
    }



    @Override
    public ItemStack quickMoveStack(
            Player player,
            int index
    ) {



        if (index == REWARD_SLOT) {

            performTrade();

            return ItemStack.EMPTY;
        }



        if (index == GOLD_SLOT_1
                || index == GOLD_SLOT_2) {

            ItemStack stack =
                    barterContainer.getItem(index);

            if (stack.isEmpty()) {
                return ItemStack.EMPTY;
            }

            ItemStack copy =
                    stack.copy();

            if (!player.getInventory().add(stack)) {
                return ItemStack.EMPTY;
            }

            barterContainer.setItem(
                    index,
                    ItemStack.EMPTY
            );

            updateResult();

            return copy;
        }



        if (index >= 3
                && index < slots.size()) {

            Slot slot =
                    slots.get(index);

            ItemStack source =
                    slot.getItem();

            if (source.isEmpty()
                    || !source.is(Items.GOLD_INGOT)) {

                return ItemStack.EMPTY;
            }

            ItemStack original =
                    source.copy();

            if (!moveGold(source)) {
                return ItemStack.EMPTY;
            }

            return original;
        }

        return ItemStack.EMPTY;
    }


    private boolean moveGold(
            ItemStack source
    ) {

        if (source.isEmpty()
                || !source.is(Items.GOLD_INGOT)) {

            return false;
        }



        if (moveGoldToSlot(
                source,
                GOLD_SLOT_1
        )) {

            updateResult();
            return true;
        }



        if (moveGoldToSlot(
                source,
                GOLD_SLOT_2
        )) {

            updateResult();
            return true;
        }

        return false;
    }

    private boolean moveGoldToSlot(
            ItemStack source,
            int slot
    ) {

        ItemStack target =
                barterContainer.getItem(slot);



        if (target.isEmpty()) {

            int amount =
                    Math.min(
                            source.getCount(),
                            source.getMaxStackSize()
                    );

            ItemStack moved =
                    source.split(amount);

            barterContainer.setItem(
                    slot,
                    moved
            );

            return !moved.isEmpty();
        }



        if (!target.is(Items.GOLD_INGOT)) {
            return false;
        }

        int space =
                target.getMaxStackSize()
                        - target.getCount();

        if (space <= 0) {
            return false;
        }

        int amount =
                Math.min(
                        source.getCount(),
                        space
                );

        target.grow(amount);
        source.shrink(amount);

        barterContainer.setItem(
                slot,
                target
        );

        return amount > 0;
    }



    @Override
    public void removed(
            Player player
    ) {

        super.removed(player);

        returnSlot(
                GOLD_SLOT_1,
                player
        );

        returnSlot(
                GOLD_SLOT_2,
                player
        );

        barterContainer.setItem(
                REWARD_SLOT,
                ItemStack.EMPTY
        );

        if (piglin != null) {

            PiglinTrading.stop(
                    piglin
            );
        }
    }



    private void returnSlot(
            int slot,
            Player player
    ) {

        ItemStack stack =
                barterContainer.getItem(slot);

        if (stack.isEmpty()) {
            return;
        }

        barterContainer.setItem(
                slot,
                ItemStack.EMPTY
        );

        if (!player.getInventory().add(stack)) {

            player.drop(
                    stack,
                    false
            );
        }
    }



    @Override
    public boolean stillValid(
            Player player
    ) {

        if (!player.isAlive()) {
            return false;
        }

        if (piglin == null) {
            return true;
        }

        if (!piglin.isAlive()) {
            return false;
        }

        return piglin.distanceToSqr(player) <= 64.0D;
    }
}
