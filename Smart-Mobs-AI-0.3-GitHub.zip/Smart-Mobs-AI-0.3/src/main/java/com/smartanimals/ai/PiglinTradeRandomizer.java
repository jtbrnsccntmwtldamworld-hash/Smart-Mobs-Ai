package com.smartanimals.ai;

import com.smartanimals.ai.PiglinTradeReward.RewardType;
import com.smartanimals.item.ModItems;

import net.minecraft.util.RandomSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public final class PiglinTradeRandomizer {



private static final List<PiglinTradeReward> REWARDS =
        new ArrayList<>();



private static final double TOTAL_WEIGHT;
private static final List<PiglinTradeReward> REWARDS_VIEW;



private static final double SILENT_BLADE_CHANCE = 0.015D;



static {



REWARDS.add(new PiglinTradeReward(
        Items.GRAVEL,
        30.0D,
        6,
        12,
        4,
        6,
        4
));



REWARDS.add(new PiglinTradeReward(
        Items.BLACKSTONE,
        28.0D,
        6,
        12,
        4,
        6,
        4
));



REWARDS.add(new PiglinTradeReward(
        Items.BASALT,
        28.0D,
        6,
        12,
        4,
        6,
        4
));



REWARDS.add(new PiglinTradeReward(
        Items.NETHER_BRICKS,
        25.0D,
        3,
        8,
        5,
        7,
        4
));



REWARDS.add(new PiglinTradeReward(
        Items.STRING,
        25.0D,
        3,
        9,
        5,
        8,
        4
));



REWARDS.add(new PiglinTradeReward(
        Items.LEATHER,
        22.0D,
        2,
        4,
        5,
        8,
        4
));



REWARDS.add(new PiglinTradeReward(
        Items.BONE,
        22.0D,
        3,
        5,
        4,
        7,
        4
));



REWARDS.add(new PiglinTradeReward(
        Items.SOUL_SAND,
        25.0D,
        3,
        8,
        6,
        9,
        4
));



REWARDS.add(new PiglinTradeReward(
        Items.SPECTRAL_ARROW,
        20.0D,
        4,
        8,
        6,
        9,
        4
));



REWARDS.add(new PiglinTradeReward(
        Items.IRON_NUGGET,
        25.0D,
        6,
        12,
        5,
        6,
        4
));



REWARDS.add(new PiglinTradeReward(
        Items.QUARTZ,
        20.0D,
        3,
        6,
        7,
        10,
        4
));



REWARDS.add(new PiglinTradeReward(
        Items.GLOWSTONE_DUST,
        22.0D,
        2,
        3,
        5,
        7,
        4
));


REWARDS.add(new PiglinTradeReward(
        Items.FIRE_CHARGE,
        18.0D,
        1,
        1,
        8,
        11,
        4
));



REWARDS.add(new PiglinTradeReward(
        Items.POTION,
        RewardType.NORMAL,
        15.0D,
        1,
        1,
        5,
        7,
        4
));



REWARDS.add(new PiglinTradeReward(
        Items.POTION,
        RewardType.FIRE_RESISTANCE,
        12.0D,
        1,
        1,
        13,
        17,
        4
));



REWARDS.add(new PiglinTradeReward(
        Items.SPLASH_POTION,
        RewardType.SPLASH_FIRE_RESISTANCE,
        10.0D,
        1,
        1,
        14,
        18,
        4
));



REWARDS.add(new PiglinTradeReward(
        Items.ENDER_PEARL,
        18.0D,
        1,
        2,
        14,
        17,
        4
));



REWARDS.add(new PiglinTradeReward(
        Items.OBSIDIAN,
        10.0D,
        1,
        1,
        10,
        13,
        4
));



REWARDS.add(new PiglinTradeReward(
        Items.CRYING_OBSIDIAN,
        12.0D,
        1,
        3,
        9,
        12,
        4
));



REWARDS.add(new PiglinTradeReward(
        Items.ENCHANTED_BOOK,
        RewardType.SOUL_SPEED_I,
        8.0D,
        1,
        1,
        19,
        23,
        1
));



REWARDS.add(new PiglinTradeReward(
        Items.ENCHANTED_BOOK,
        RewardType.SOUL_SPEED_II,
        6.0D,
        1,
        1,
        25,
        29,
        1
));



REWARDS.add(new PiglinTradeReward(
        Items.ENCHANTED_BOOK,
        RewardType.SOUL_SPEED_III,
        4.0D,
        1,
        1,
        31,
        36,
        1
));



REWARDS.add(new PiglinTradeReward(
        Items.GOLDEN_BOOTS,
        RewardType.SOUL_SPEED_BOOTS,
        8.0D,
        1,
        1,
        20,
        35,
        1
));



REWARDS.add(new PiglinTradeReward(
        ModItems.SILENT_BLADE,
        RewardType.SILENT_BLADE,
        1.5D,
        1,
        1,
        65,
        85,
        1
));


    double weight = 0.0D;
    for (PiglinTradeReward reward : REWARDS) {
        if (reward != null
                && !reward.isSilentBlade()
                && reward.getChance() > 0.0D) {
            weight += reward.getChance();
        }
    }
    TOTAL_WEIGHT = weight;
    REWARDS_VIEW = List.copyOf(REWARDS);
}



private PiglinTradeRandomizer() {
}



public static PiglinTradeReward getRandomReward(
        RandomSource random
) {

    if (random == null) {
        return null;
    }


    if (random.nextDouble() < SILENT_BLADE_CHANCE) {

        PiglinTradeReward silentBlade =
                getSilentBladeReward();

        if (silentBlade != null) {
            return silentBlade;
        }
    }



    double totalWeight = TOTAL_WEIGHT;

    if (totalWeight <= 0.0D) {
        return null;
    }



    double roll =
            random.nextDouble() * totalWeight;

    double currentWeight = 0.0D;

    for (PiglinTradeReward reward : REWARDS) {

        if (reward == null) {
            continue;
        }

        if (reward.isSilentBlade()) {
            continue;
        }

        if (reward.getChance() <= 0.0D) {
            continue;
        }

        currentWeight += reward.getChance();

        if (roll < currentWeight) {
            return reward;
        }
    }



    for (int i = REWARDS.size() - 1; i >= 0; i--) {

        PiglinTradeReward reward =
                REWARDS.get(i);

        if (reward != null
                && !reward.isSilentBlade()
                && reward.getChance() > 0.0D) {

            return reward;
        }
    }

    return null;
}



public static PiglinTradeReward getRandomReward(
        RandomSource random,
        Set<Item> excludedItems
) {

    if (random == null) {
        return null;
    }



    if (random.nextDouble() < SILENT_BLADE_CHANCE) {

        PiglinTradeReward silentBlade =
                getSilentBladeReward();

        if (silentBlade != null
                && !excludedItems.contains(
                        silentBlade.getItem())) {

            return silentBlade;
        }
    }



    double totalWeight = 0.0D;

    for (PiglinTradeReward reward : REWARDS) {

        if (reward != null
                && !reward.isSilentBlade()
                && !excludedItems.contains(
                        reward.getItem())
                && reward.getChance() > 0.0D) {

            totalWeight +=
                    reward.getChance();
        }
    }

    if (totalWeight <= 0.0D) {
        return null;
    }

    double roll =
            random.nextDouble() * totalWeight;

    double currentWeight = 0.0D;

    for (PiglinTradeReward reward : REWARDS) {

        if (reward == null) {
            continue;
        }

        if (reward.isSilentBlade()) {
            continue;
        }

        if (excludedItems.contains(
                reward.getItem())) {

            continue;
        }

        if (reward.getChance() <= 0.0D) {
            continue;
        }

        currentWeight += reward.getChance();

        if (roll < currentWeight) {
            return reward;
        }
    }



    for (int i = REWARDS.size() - 1; i >= 0; i--) {

        PiglinTradeReward reward =
                REWARDS.get(i);

        if (reward != null
                && !reward.isSilentBlade()
                && !excludedItems.contains(
                        reward.getItem())
                && reward.getChance() > 0.0D) {

            return reward;
        }
    }

    return null;
}



private static PiglinTradeReward getSilentBladeReward() {

    for (PiglinTradeReward reward : REWARDS) {

        if (reward != null
                && reward.isSilentBlade()) {

            return reward;
        }
    }

    return null;
}



public static int getRandomAmount(
        PiglinTradeReward reward,
        RandomSource random
) {

    if (reward == null || random == null) {
        return 0;
    }

    int min =
            reward.getMinAmount();

    int max =
            reward.getMaxAmount();



    if (max <= min) {
        return Math.max(0, min);
    }

    return random.nextInt(
            max - min + 1
    ) + min;
}



public static int getRandomPrice(
        PiglinTradeReward reward,
        RandomSource random
) {

    if (reward == null || random == null) {
        return 0;
    }

    int min =
            reward.getMinPrice();

    int max =
            reward.getMaxPrice();



    if (max <= min) {
        return Math.max(0, min);
    }

    return random.nextInt(
            max - min + 1
    ) + min;
}



public static List<PiglinTradeReward> getRewards() {

    return REWARDS_VIEW;
}
}