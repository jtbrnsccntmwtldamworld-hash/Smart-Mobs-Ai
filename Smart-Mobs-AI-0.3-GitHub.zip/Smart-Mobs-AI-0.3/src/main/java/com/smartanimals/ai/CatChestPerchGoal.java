package com.smartanimals.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Cat;
import net.minecraft.world.level.block.Blocks;

import java.util.EnumSet;
import java.util.Random;

public class CatChestPerchGoal extends Goal {

    private final Cat cat;
    private final double speed;

    private BlockPos chestTarget;

    private int perchTime;
    private int checkCooldown;

    private static final Random RANDOM = new Random();

    private static final int CHECK_INTERVAL = 600;

    private static final int CHANCE = 100;

    private static final int PERCH_TIME = 1200;

    private static final int SEARCH_RADIUS = 8;

    public CatChestPerchGoal(
            Cat cat,
            double speed) {

        this.cat = cat;
        this.speed = speed;

        this.checkCooldown = CHECK_INTERVAL;

        this.setFlags(
                EnumSet.of(Flag.MOVE)
        );
    }

    @Override
    public boolean canUse() {

        if (!this.cat.isTame()) {
            return false;
        }

        if (this.checkCooldown > 0) {
            this.checkCooldown--;
            return false;
        }

        this.checkCooldown = CHECK_INTERVAL;

        if (RANDOM.nextInt(CHANCE) != 0) {
            return false;
        }

        if (!this.cat.getNavigation().isDone()) {
            return false;
        }

        this.chestTarget = findChest();

        return this.chestTarget != null;
    }

    @Override
    public boolean canContinueToUse() {

        if (this.chestTarget == null) {
            return false;
        }

        if (!this.cat.isAlive()) {
            return false;
        }

        return this.perchTime > 0;
    }

    @Override
    public void start() {

        this.perchTime = PERCH_TIME;

        moveToChest();
    }

    @Override
    public void tick() {

        if (this.chestTarget == null) {
            return;
        }

        BlockPos perchPos =
                this.chestTarget.above();

        double distance =
                this.cat.distanceToSqr(
                        perchPos.getX() + 0.5D,
                        perchPos.getY(),
                        perchPos.getZ() + 0.5D
                );


        if (distance > 1.5D) {

            if (this.cat.getNavigation().isDone()) {
                moveToChest();
            }

            return;
        }


        this.cat.getNavigation().stop();


        this.cat.setPos(
                perchPos.getX() + 0.5D,
                perchPos.getY(),
                perchPos.getZ() + 0.5D
        );


        this.cat.setInSittingPose(true);


        this.perchTime--;
    }

    @Override
    public void stop() {

        this.chestTarget = null;
        this.perchTime = 0;


        this.cat.setInSittingPose(false);

        this.cat.getNavigation().stop();
    }

    private void moveToChest() {

        if (this.chestTarget == null) {
            return;
        }

        BlockPos perchPos =
                this.chestTarget.above();

        this.cat.getNavigation().moveTo(
                perchPos.getX() + 0.5D,
                perchPos.getY(),
                perchPos.getZ() + 0.5D,
                this.speed
        );
    }

    private BlockPos findChest() {

        BlockPos catPos =
                this.cat.blockPosition();

        BlockPos closestChest = null;

        double closestDistance =
                Double.MAX_VALUE;
        for (int x = -SEARCH_RADIUS;
             x <= SEARCH_RADIUS;
             x++) {

            for (int y = -2;
                 y <= 2;
                 y++) {

                for (int z = -SEARCH_RADIUS;
                     z <= SEARCH_RADIUS;
                     z++) {

                    if (x * x + z * z
                            > SEARCH_RADIUS * SEARCH_RADIUS) {
                        continue;
                    }

                    BlockPos pos =
                            catPos.offset(
                                    x,
                                    y,
                                    z
                            );


                    if (!this.cat.level()
                            .getBlockState(pos)
                            .is(Blocks.CHEST)) {
                        continue;
                    }


                    BlockPos perchPos =
                            pos.above();

                    if (!this.cat.level()
                            .getBlockState(perchPos)
                            .isAir()) {
                        continue;
                    }


                    if (!this.cat.level()
                            .getBlockState(perchPos.above())
                            .isAir()) {
                        continue;
                    }

                    double distance =
                            this.cat.distanceToSqr(
                                    perchPos.getX() + 0.5D,
                                    perchPos.getY(),
                                    perchPos.getZ() + 0.5D
                            );

                    if (distance < closestDistance) {

                        closestDistance = distance;
                        closestChest = pos;
                    }
                }
            }
        }

        return closestChest;
    }
}