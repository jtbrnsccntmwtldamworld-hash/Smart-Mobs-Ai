package com.smartanimals.ai;

import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.EnumSet;

public class PiglinAttackPlayerGoal extends Goal {

    private final Piglin piglin;

    private Player targetPlayer;

    private int checkTimer = 0;

    private static final double DETECTION_DISTANCE = 16.0D;

    private static final int CHECK_INTERVAL = 20;

    public PiglinAttackPlayerGoal(
            Piglin piglin) {

        this.piglin = piglin;

        setFlags(
                EnumSet.of(
                        Flag.TARGET
                )
        );
    }

    @Override
    public boolean canUse() {

        Player player =
                piglin.level().getNearestPlayer(
                        piglin,
                        DETECTION_DISTANCE
                );

        if (player == null) {
            return false;
        }

        if (!player.isAlive()) {
            return false;
        }


        if (hasGoldArmor(player)) {
            return false;
        }

        targetPlayer = player;

        checkTimer = CHECK_INTERVAL;

        return true;
    }

    @Override
    public boolean canContinueToUse() {

        if (targetPlayer == null) {
            return false;
        }

        if (!targetPlayer.isAlive()) {
            return false;
        }


        if (checkTimer > 0) {
            checkTimer--;
        }

        if (checkTimer <= 0) {

            checkTimer = CHECK_INTERVAL;

            if (hasGoldArmor(targetPlayer)) {

                if (piglin.getTarget()
                        == targetPlayer) {

                    piglin.setTarget(null);
                }

                return false;
            }
        }


        return piglin.distanceToSqr(
                targetPlayer
        ) <=
                DETECTION_DISTANCE
                * DETECTION_DISTANCE;
    }

    @Override
    public void start() {

        if (targetPlayer == null) {
            return;
        }

        piglin.setTarget(
                targetPlayer
        );

        piglin.getLookControl().setLookAt(
                targetPlayer,
                30.0F,
                30.0F
        );
    }

    @Override
    public void tick() {

        if (targetPlayer == null) {
            return;
        }

        piglin.getLookControl().setLookAt(
                targetPlayer,
                30.0F,
                30.0F
        );
    }

    @Override
    public void stop() {

        if (piglin.getTarget()
                == targetPlayer) {

            piglin.setTarget(null);
        }

        targetPlayer = null;

        checkTimer = 0;
    }



    private boolean hasGoldArmor(
            Player player) {

        for (ItemStack stack :
                player.getArmorSlots()) {

            if (stack.isEmpty()) {
                continue;
            }

            if (stack.is(Items.GOLDEN_HELMET)
                    || stack.is(Items.GOLDEN_CHESTPLATE)
                    || stack.is(Items.GOLDEN_LEGGINGS)
                    || stack.is(Items.GOLDEN_BOOTS)) {

                return true;
            }
        }

        return false;
    }
}