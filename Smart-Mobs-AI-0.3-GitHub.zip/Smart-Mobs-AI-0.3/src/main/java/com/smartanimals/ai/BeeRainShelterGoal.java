package com.smartanimals.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Bee;

import java.util.EnumSet;

public class BeeRainShelterGoal extends Goal {

    private final Bee bee;
    private final double speed;

    private BlockPos hivePos;

    public BeeRainShelterGoal(
            Bee bee,
            double speed) {

        this.bee = bee;
        this.speed = speed;

        this.setFlags(
                EnumSet.of(
                        Flag.MOVE,
                        Flag.LOOK
                )
        );
    }

    @Override
    public boolean canUse() {

        if (!bee.isAlive()) {
            return false;
        }


        if (!bee.level().isRaining()) {
            return false;
        }


        BlockPos pos = bee.getHivePos();

        if (pos == null) {
            return false;
        }

        hivePos = pos;

        return true;
    }

    @Override
    public boolean canContinueToUse() {

        if (!bee.isAlive()) {
            return false;
        }


        if (!bee.level().isRaining()) {
            return false;
        }

        return hivePos != null;
    }

    @Override
    public void start() {

        if (hivePos == null) {
            return;
        }

        moveToHive();
    }

    @Override
    public void tick() {

        if (hivePos == null) {
            return;
        }

        bee.getLookControl().setLookAt(
                hivePos.getX() + 0.5D,
                hivePos.getY() + 0.5D,
                hivePos.getZ() + 0.5D,
                30.0F,
                30.0F
        );


        if (bee.distanceToSqr(
                hivePos.getX() + 0.5D,
                hivePos.getY() + 0.5D,
                hivePos.getZ() + 0.5D
        ) <= 2.0D) {

            bee.getNavigation().stop();

            return;
        }


        if (bee.getNavigation().isDone()) {
            moveToHive();
        }
    }

    @Override
    public void stop() {

        hivePos = null;

        bee.getNavigation().stop();
    }

    private void moveToHive() {

        if (hivePos == null) {
            return;
        }

        bee.getNavigation().moveTo(
                hivePos.getX() + 0.5D,
                hivePos.getY() + 0.5D,
                hivePos.getZ() + 0.5D,
                speed
        );
    }
}