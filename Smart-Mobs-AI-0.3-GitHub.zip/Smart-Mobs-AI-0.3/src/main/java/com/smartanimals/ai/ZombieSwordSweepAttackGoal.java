package com.smartanimals.ai;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.phys.AABB;

import java.util.EnumSet;
import java.util.List;

public class ZombieSwordSweepAttackGoal extends Goal {

    private final Zombie zombie;

    private int attackCooldown = 0;

    private static final int ATTACK_COOLDOWN = 20;

    public ZombieSwordSweepAttackGoal(Zombie zombie) {

        this.zombie = zombie;

        setFlags(
                EnumSet.of(
                        Flag.MOVE,
                        Flag.LOOK
                )
        );
    }

    @Override
    public boolean canUse() {

        LivingEntity target =
                zombie.getTarget();

        if (target == null) {
            return false;
        }

        if (!target.isAlive()) {
            return false;
        }


        if (!(zombie
                .getMainHandItem()
                .getItem() instanceof SwordItem)) {

            return false;
        }


        if (attackCooldown > 0) {
            attackCooldown--;
            return false;
        }

        return zombie.distanceToSqr(target) <= 9.0D;
    }

    @Override
    public boolean canContinueToUse() {

        LivingEntity target =
                zombie.getTarget();

        if (target == null) {
            return false;
        }

        if (!target.isAlive()) {
            return false;
        }

        if (!(zombie
                .getMainHandItem()
                .getItem() instanceof SwordItem)) {

            return false;
        }

        return zombie.distanceToSqr(target) <= 16.0D;
    }

    @Override
    public void start() {

        attackCooldown = 0;
    }

    @Override
    public void stop() {


    }

    @Override
    public void tick() {

        LivingEntity target =
                zombie.getTarget();

        if (target == null) {
            return;
        }


        zombie.getLookControl().setLookAt(
                target,
                30.0F,
                30.0F
        );


        if (zombie.distanceToSqr(target) > 4.0D) {

            zombie.getNavigation().moveTo(
                    target,
                    1.0D
            );

            return;
        }


        if (attackCooldown > 0) {

            attackCooldown--;

            return;
        }


        performSwordAttack(target);

        attackCooldown =
                ATTACK_COOLDOWN;
    }

    private void performSwordAttack(
            LivingEntity target) {


        if (zombie.distanceToSqr(target) > 4.0D) {
            return;
        }


        zombie.getLookControl().setLookAt(
                target,
                30.0F,
                30.0F
        );


        boolean hit =
                zombie.doHurtTarget(target);

        if (!hit) {
            return;
        }


        zombie.swing(
                InteractionHand.MAIN_HAND
        );


        spawnSweepParticles();


        double attackDamage =
                zombie.getAttributeValue(
                        Attributes.ATTACK_DAMAGE
                );


        float sweepDamage =
                (float) Math.max(
                        1.0D,
                        attackDamage * 0.5D
                );

        AABB sweepBox =
                target
                        .getBoundingBox()
                        .inflate(
                                1.0D,
                                0.25D,
                                1.0D
                        );

        List<LivingEntity> nearbyEntities =
                zombie.level().getEntitiesOfClass(
                        LivingEntity.class,
                        sweepBox
                );


        for (LivingEntity nearby :
                nearbyEntities) {

            if (nearby == zombie) {
                continue;
            }

            if (nearby == target) {
                continue;
            }

            if (!nearby.isAlive()) {
                continue;
            }


            if (zombie.isAlliedTo(nearby)) {
                continue;
            }


            if (zombie.distanceToSqr(nearby) > 9.0D) {
                continue;
            }


            nearby.hurt(
                    zombie.damageSources().mobAttack(
                            zombie
                    ),
                    sweepDamage
            );


            double dx =
                    nearby.getX()
                            - zombie.getX();

            double dz =
                    nearby.getZ()
                            - zombie.getZ();

            nearby.knockback(
                    0.4D,
                    dx,
                    dz
            );
        }
    }


    private void spawnSweepParticles() {


        if (!(zombie.level()
                instanceof ServerLevel serverLevel)) {

            return;
        }


        double yaw =
                Math.toRadians(
                        zombie.getYRot()
                );


        double x =
                zombie.getX()
                        - Math.sin(yaw) * 0.8D;

        double y =
                zombie.getY() + 1.0D;

        double z =
                zombie.getZ()
                        + Math.cos(yaw) * 0.8D;


        serverLevel.sendParticles(
                ParticleTypes.SWEEP_ATTACK,
                x,
                y,
                z,
                1,
                0.0D,
                0.0D,
                0.0D,
                0.0D
        );
    }
}