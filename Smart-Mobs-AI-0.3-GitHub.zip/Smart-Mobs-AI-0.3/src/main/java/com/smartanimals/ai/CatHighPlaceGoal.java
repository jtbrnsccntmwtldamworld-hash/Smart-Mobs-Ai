package com.smartanimals.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Cat;
import net.minecraft.world.level.block.Blocks;

import java.util.EnumSet;
import java.util.Random;

public class CatHighPlaceGoal extends Goal {

    private final Cat cat;
    private final double speed;

    private BlockPos target;

    private int checkCooldown;
    private int sitTime;

    private static final Random RANDOM = new Random();


    private static final int CHECK_INTERVAL = 4800;


    private static final int CHANCE = 2;


    private static final int MIN_HEIGHT = 1;
    private static final int MAX_HEIGHT = 3;


    private static final int MIN_SIT_TIME = 1200;
    private static final int MAX_SIT_TIME = 3600;


    private static final int SEARCH_RADIUS = 8;

    public CatHighPlaceGoal(
            Cat cat,
            double speed) {

        this.cat = cat;
        this.speed = speed;


        this.checkCooldown =
                CHECK_INTERVAL;

        this.setFlags(
                EnumSet.of(Flag.MOVE)
        );
    }

    @Override
    public boolean canUse() {


        if (this.checkCooldown > 0) {

            this.checkCooldown--;

            return false;
        }


        this.checkCooldown =
                CHECK_INTERVAL;


        if (RANDOM.nextInt(100) >= CHANCE) {
            return false;
        }


        if (!this.cat.isTame()) {
            return false;
        }


        if (!this.cat.getNavigation().isDone()) {
            return false;
        }


        this.target =
                findHighPlace();

        return this.target != null;
    }

    @Override
    public boolean canContinueToUse() {


        if (!this.cat.isAlive()) {
            return false;
        }


        if (this.target == null) {
            return false;
        }


        if (!this.cat.getNavigation().isDone()) {
            return true;
        }


        return this.sitTime > 0;
    }

    @Override
    public void start() {


        this.sitTime =
                MIN_SIT_TIME
                        + RANDOM.nextInt(
                        MAX_SIT_TIME
                                - MIN_SIT_TIME
                                + 1
                );


        moveToTarget();
    }

    @Override
    public void tick() {


        if (!this.cat.getNavigation().isDone()) {
            return;
        }


        this.cat.getNavigation().stop();

        if (this.sitTime > 0) {
            this.sitTime--;
        }
    }

    @Override
    public void stop() {

        this.target = null;
        this.sitTime = 0;
    }


    private BlockPos findHighPlace() {

        BlockPos catPos =
                this.cat.blockPosition();

        BlockPos bestPlace = null;

        double bestDistance =
                Double.MAX_VALUE;

        for (int x = -SEARCH_RADIUS;
             x <= SEARCH_RADIUS;
             x++) {

            for (int y = MIN_HEIGHT;
                 y <= MAX_HEIGHT;
                 y++) {

                for (int z = -SEARCH_RADIUS;
                     z <= SEARCH_RADIUS;
                     z++) {


                    if (x * x + z * z
                            > SEARCH_RADIUS
                            * SEARCH_RADIUS) {

                        continue;
                    }

                    BlockPos pos =
                            catPos.offset(
                                    x,
                                    y,
                                    z
                            );


                    if (!isValidHighPlace(pos)) {
                        continue;
                    }

                    double distance =
                            this.cat.distanceToSqr(
                                    pos.getX() + 0.5D,
                                    pos.getY() + 1.0D,
                                    pos.getZ() + 0.5D
                            );


                    if (distance < bestDistance) {

                        bestDistance =
                                distance;

                        bestPlace =
                                pos;
                    }
                }
            }
        }

        return bestPlace;
    }


    private boolean isValidHighPlace(
            BlockPos pos) {


        if (this.cat.level()
                .getBlockState(pos)
                .isAir()) {

            return false;
        }


        if (!this.cat.level()
                .getBlockState(pos.above())
                .isAir()) {

            return false;
        }


        if (!this.cat.level()
                .getBlockState(pos.above(2))
                .isAir()) {

            return false;
        }


        if (this.cat.level()
                .getBlockState(pos)
                .is(Blocks.WATER)) {

            return false;
        }


        if (this.cat.level()
                .getBlockState(pos)
                .is(Blocks.LAVA)) {

            return false;
        }

        return true;
    }


    private void moveToTarget() {

        if (this.target == null) {
            return;
        }

        this.cat.getNavigation().moveTo(
                this.target.getX() + 0.5D,
                this.target.getY() + 1.0D,
                this.target.getZ() + 0.5D,
                this.speed
        );
    }
}