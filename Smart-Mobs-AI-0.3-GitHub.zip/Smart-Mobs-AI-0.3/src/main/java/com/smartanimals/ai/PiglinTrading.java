package com.smartanimals.ai;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

public final class PiglinTrading {

    private static final Map<Piglin, Player> ACTIVE_TRADES =
            new WeakHashMap<>();

    public static final int OFFER_COUNT = 5;

    private PiglinTrading() {
    }

    public static void start(Piglin piglin, Player player) {

        if (piglin == null || player == null) {
            return;
        }

        ACTIVE_TRADES.put(piglin, player);

        if (!(piglin.level() instanceof ServerLevel)) {
            return;
        }

        ServerLevel level =
                (ServerLevel) piglin.level();

        PiglinTradeData data =
                PiglinTradeData.get(level);

        PiglinTradeData.TradeData[] trades =
                data.getTrades(
                        piglin.getUUID(),
                        player.getUUID()
                );



    Set<Item> excludedItems =
            new HashSet<>();

    for (int i = 0; i < OFFER_COUNT; i++) {

        if (trades[i] != null) {

            String rewardId =
                    trades[i].getRewardId();

            for (PiglinTradeReward reward :
                    PiglinTradeRandomizer.getRewards()) {

                if (createRewardId(reward)
                        .equals(rewardId)) {

                    excludedItems.add(
                            reward.getItem()
                    );

                    break;
                }
            }
        }
    }

    for (int i = 0; i < OFFER_COUNT; i++) {

        if (trades[i] != null) {
            continue;
        }

        PiglinTradeReward reward =
                PiglinTradeRandomizer.getRandomReward(
                        piglin.getRandom(),
                        excludedItems
                );

        if (reward == null) {
            continue;
        }

        excludedItems.add(
                reward.getItem()
        );

        int price =
                PiglinTradeRandomizer.getRandomPrice(
                        reward,
                        piglin.getRandom()
                );

        int amount =
                PiglinTradeRandomizer.getRandomAmount(
                        reward,
                        piglin.getRandom()
                );

        TradeDataFix.createTrade(
                data,
                piglin,
                player,
                i,
                reward,
                price,
                amount
        );
    }

        piglin.getNavigation().stop();
    }

    public static PiglinTradeData.TradeData getTrade(
            Piglin piglin,
            Player player,
            int index
    ) {

        if (piglin == null || player == null) {
            return null;
        }

        if (index < 0 || index >= OFFER_COUNT) {
            return null;
        }

        if (!(piglin.level() instanceof ServerLevel)) {
            return null;
        }

        ServerLevel level =
                (ServerLevel) piglin.level();

        return PiglinTradeData.get(level)
                .getTrade(
                        piglin.getUUID(),
                        player.getUUID(),
                        index
                );
    }

    public static boolean purchase(
            Piglin piglin,
            Player player,
            int index
    ) {

        if (piglin == null || player == null) {
            return false;
        }

        if (index < 0 || index >= OFFER_COUNT) {
            return false;
        }

        if (!(piglin.level() instanceof ServerLevel)) {
            return false;
        }

        ServerLevel level =
                (ServerLevel) piglin.level();

        PiglinTradeData data =
                PiglinTradeData.get(level);
        PiglinTradeData.TradeData trade =
                data.getTrade(
                        piglin.getUUID(),
                        player.getUUID(),
                        index
                );

        if (trade == null) {
            return false;
        }

        if (!trade.canPurchase()) {
            return false;
        }

        if (!trade.addPurchase()) {
            return false;
        }

        data.setTrade(
                piglin.getUUID(),
                player.getUUID(),
                index,
                trade
        );

        return true;
    }

    public static boolean canPurchase(
            Piglin piglin,
            Player player,
            int index
    ) {

        PiglinTradeData.TradeData trade =
                getTrade(
                        piglin,
                        player,
                        index
                );

        return trade != null
                && trade.canPurchase();
    }

    public static boolean isTrading(Piglin piglin) {

        return piglin != null
                && ACTIVE_TRADES.containsKey(piglin);
    }

    public static void tick(Piglin piglin) {

        if (piglin == null) {
            return;
        }

        Player player =
                ACTIVE_TRADES.get(piglin);

        if (player == null) {
            return;
        }

        if (!player.isAlive()
                || player.isSpectator()) {

            stop(piglin);
            return;
        }

        if (!piglin.isAlive()) {
            stop(piglin);
            return;
        }

        piglin.getNavigation().stop();
    }

    public static void stop(Piglin piglin) {

        if (piglin == null) {
            return;
        }

        ACTIVE_TRADES.remove(piglin);

        piglin.getNavigation().stop();
    }



    private static final class TradeDataFix {

        private TradeDataFix() {
        }

        private static void createTrade(
                PiglinTradeData data,
                Piglin piglin,
                Player player,
                int index,
                PiglinTradeReward reward,
                int price,
                int amount
        ) {

            int purchaseLimit =
                    reward.getPurchaseLimit();



            if (purchaseLimit > 1) {



                purchaseLimit =
                        piglin.getRandom().nextInt(3) + 2;
            }

            PiglinTradeData.TradeData trade =
                    new PiglinTradeData.TradeData(
                            createRewardId(reward),
                            price,
                            amount,
                            purchaseLimit
                    );
            data.setTrade(
                    piglin.getUUID(),
                    player.getUUID(),
                    index,
                    trade
            );
        }
    }



    public static String createRewardId(
            PiglinTradeReward reward
    ) {

        if (reward == null) {
            return "";
        }



        if (reward.isSilentBlade()) {

            return "silent_blade|"
                    + reward.getType().name();
        }



        if (reward.getItem() == null) {
            return "";
        }



        ResourceLocation key =
                BuiltInRegistries.ITEM.getKey(
                        reward.getItem()
                );

        return key.toString()
                + "|"
                + reward.getType().name();
    }
}