package com.smartanimals.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.level.block.Blocks;

import java.util.EnumSet;

public class DogThunderCarpetGoal extends Goal {

    private final Wolf dog;
    private final double speed;

    private BlockPos carpetTarget;

    private static final int SEARCH_RADIUS = 8;

    public DogThunderCarpetGoal(
            Wolf dog,
            double speed) {

        this.dog = dog;
        this.speed = speed;

        this.setFlags(
                EnumSet.of(
                        Flag.MOVE
                )
        );
    }

    @Override
    public boolean canUse() {

        if (!this.dog.isAlive()) {
            return false;
        }


        if (!this.dog.isTame()) {
            return false;
        }


        if (!this.dog.level().isThundering()) {
            return false;
        }


        this.carpetTarget =
                findNearestCarpet();

        return this.carpetTarget != null;
    }

    @Override
    public boolean canContinueToUse() {

        if (!this.dog.isAlive()) {
            return false;
        }

        if (!this.dog.isTame()) {
            return false;
        }


        if (!this.dog.level().isThundering()) {
            return false;
        }

        return this.carpetTarget != null;
    }

    @Override
    public void start() {

        if (this.carpetTarget == null) {
            return;
        }

        moveToCarpet();
    }

    @Override
    public void tick() {

        if (this.carpetTarget == null) {
            return;
        }


        if (this.dog.distanceToSqr(
                this.carpetTarget.getX() + 0.5D,
                this.carpetTarget.getY() + 1.0D,
                this.carpetTarget.getZ() + 0.5D
        ) <= 2.0D) {

            this.dog.getNavigation()
                    .stop();

            return;
        }


        if (this.dog.getNavigation().isDone()) {
            moveToCarpet();
        }
    }

    @Override
    public void stop() {

        this.carpetTarget = null;


        this.dog.getNavigation()
                .stop();
    }

    private void moveToCarpet() {

        if (this.carpetTarget == null) {
            return;
        }

        this.dog.getNavigation().moveTo(
                this.carpetTarget.getX() + 0.5D,
                this.carpetTarget.getY() + 1.0D,
                this.carpetTarget.getZ() + 0.5D,
                this.speed
        );
    }

    private BlockPos findNearestCarpet() {

        BlockPos dogPos =
                this.dog.blockPosition();

        BlockPos closest =
                null;

        double closestDistance =
                Double.MAX_VALUE;

        for (int x = -SEARCH_RADIUS;
             x <= SEARCH_RADIUS;
             x++) {

            for (int y = -2;
                 y <= 2;
                 y++) {

                for (int z = -SEARCH_RADIUS;
                     z <= SEARCH_RADIUS;
                     z++) {

                    BlockPos pos =
                            dogPos.offset(
                                    x,
                                    y,
                                    z
                            );
                    if (!isCarpet(pos)) {
                        continue;
                    }

                    double distance =
                            this.dog.distanceToSqr(
                                    pos.getX() + 0.5D,
                                    pos.getY() + 1.0D,
                                    pos.getZ() + 0.5D
                            );

                    if (distance <
                            closestDistance) {

                        closestDistance =
                                distance;

                        closest =
                                pos;
                    }
                }
            }
        }

        return closest;
    }

    private boolean isCarpet(
            BlockPos pos) {

        return this.dog.level()
                .getBlockState(pos)
                .is(Blocks.WHITE_CARPET)

                || this.dog.level()
                .getBlockState(pos)
                .is(Blocks.ORANGE_CARPET)

                || this.dog.level()
                .getBlockState(pos)
                .is(Blocks.MAGENTA_CARPET)

                || this.dog.level()
                .getBlockState(pos)
                .is(Blocks.LIGHT_BLUE_CARPET)

                || this.dog.level()
                .getBlockState(pos)
                .is(Blocks.YELLOW_CARPET)

                || this.dog.level()
                .getBlockState(pos)
                .is(Blocks.LIME_CARPET)

                || this.dog.level()
                .getBlockState(pos)
                .is(Blocks.PINK_CARPET)

                || this.dog.level()
                .getBlockState(pos)
                .is(Blocks.GRAY_CARPET)

                || this.dog.level()
                .getBlockState(pos)
                .is(Blocks.LIGHT_GRAY_CARPET)

                || this.dog.level()
                .getBlockState(pos)
                .is(Blocks.CYAN_CARPET)

                || this.dog.level()
                .getBlockState(pos)
                .is(Blocks.PURPLE_CARPET)

                || this.dog.level()
                .getBlockState(pos)
                .is(Blocks.BLUE_CARPET)

                || this.dog.level()
                .getBlockState(pos)
                .is(Blocks.BROWN_CARPET)

                || this.dog.level()
                .getBlockState(pos)
                .is(Blocks.GREEN_CARPET)

                || this.dog.level()
                .getBlockState(pos)
                .is(Blocks.RED_CARPET)

                || this.dog.level()
                .getBlockState(pos)
                .is(Blocks.BLACK_CARPET);
    }
}