package com.smartanimals.ai;

import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.horse.Horse;
import net.minecraft.world.entity.monster.Enemy;

import java.util.EnumSet;

public class HorseReactionGoal extends Goal {

    private final Horse horse;
    private final double speed;

    private Horse herdHorse;

    private int reactionTime;
    private int checkCooldown;

    private static final int REACTION_TIME = 160;
    private static final int CHECK_COOLDOWN = 20;

    private static final double EVENT_RADIUS = 12.0D;
    private static final double HERD_SEARCH_RADIUS = 16.0D;

    public HorseReactionGoal(
            Horse horse,
            double speed) {

        this.horse = horse;
        this.speed = speed;

        this.setFlags(
                EnumSet.of(Flag.MOVE)
        );
    }

    @Override
    public boolean canUse() {

        if (this.horse.isVehicle()) {
            return false;
        }

        if (!hasNearbyEvent()) {
            return false;
        }

        this.herdHorse =
                findNearestHorse();

        return this.herdHorse != null;
    }

    @Override
    public boolean canContinueToUse() {

        if (this.horse.isVehicle()) {
            return false;
        }

        if (this.reactionTime <= 0) {
            return false;
        }

        if (hasNearbyEvent()) {
            return true;
        }

        return this.herdHorse != null
                && this.herdHorse.isAlive()
                && this.horse.distanceToSqr(
                        this.herdHorse
                ) > 36.0D;
    }

    @Override
    public void start() {

        this.reactionTime =
                REACTION_TIME;

        this.checkCooldown = 0;

        moveCloserToHerd();
    }

    @Override
    public void tick() {

        if (this.horse.isVehicle()) {
            return;
        }

        this.reactionTime--;

        if (this.checkCooldown > 0) {
            this.checkCooldown--;
        }

        if (this.checkCooldown <= 0) {

            this.herdHorse =
                    findNearestHorse();

            this.checkCooldown =
                    CHECK_COOLDOWN;
        }

        if (this.herdHorse == null) {
            return;
        }

        if (!this.herdHorse.isAlive()) {
            return;
        }

        if (this.horse.distanceToSqr(
                this.herdHorse
        ) <= 16.0D) {

            this.horse
                    .getNavigation()
                    .stop();

            return;
        }

        moveCloserToHerd();
    }

    @Override
    public void stop() {

        this.reactionTime = 0;
        this.checkCooldown = 0;

        this.herdHorse = null;

        this.horse
                .getNavigation()
                .stop();
    }

    private boolean hasNearbyEvent() {


        if (this.horse.level().isThundering()) {
            return true;
        }


        return !this.horse.level()
                .getEntities(
                        this.horse,
                        this.horse
                                .getBoundingBox()
                                .inflate(EVENT_RADIUS),
                        entity ->
                                entity instanceof Enemy
                                        && entity.isAlive()
                )
                .isEmpty();
    }

    private Horse findNearestHorse() {

        Horse nearest = null;

        double nearestDistance =
                Double.MAX_VALUE;

        for (Horse otherHorse :
                this.horse.level()
                        .getEntitiesOfClass(
                                Horse.class,
                                this.horse
                .getBoundingBox()
                                        .inflate(
                                                HERD_SEARCH_RADIUS
                                        ),
                                otherHorse ->
                                        otherHorse != this.horse
                                                && otherHorse.isAlive()
                        )) {

            double distance =
                    this.horse.distanceToSqr(
                            otherHorse
                    );

            if (distance < nearestDistance) {

                nearestDistance =
                        distance;

                nearest =
                        otherHorse;
            }
        }

        return nearest;
    }

    private void moveCloserToHerd() {

        if (this.herdHorse == null) {
            return;
        }

        this.horse
                .getNavigation()
                .moveTo(
                        this.herdHorse,
                        this.speed
                );
    }
}