package com.smartanimals.ai;

import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.player.Player;

import java.util.EnumSet;

public class CreeperBlindSpotGoal extends Goal {

    private final Creeper creeper;

    private Player target;

    private final boolean blindSpotCreeper;

    private static final double MAX_DISTANCE = 12.0D;

    private static final double NORMAL_SPEED = 1.0D;

    private static final double BOOST_SPEED = 1.35D;

    public CreeperBlindSpotGoal(Creeper creeper) {

        this.creeper = creeper;


        this.blindSpotCreeper =
                creeper.getRandom().nextFloat() < 0.03F;

        this.setFlags(
                EnumSet.of(
                        Flag.MOVE
                )
        );
    }

    @Override
    public boolean canUse() {


        if (!blindSpotCreeper) {
            return false;
        }

        if (!(creeper.getTarget()
                instanceof Player player)) {
            return false;
        }

        if (!player.isAlive()) {
            return false;
        }

        if (creeper.distanceToSqr(player)
                > MAX_DISTANCE * MAX_DISTANCE) {
            return false;
        }

        target = player;

        return true;
    }

    @Override
    public boolean canContinueToUse() {

        if (!blindSpotCreeper) {
            return false;
        }

        if (target == null) {
            return false;
        }

        if (!target.isAlive()) {
            return false;
        }

        return creeper.distanceToSqr(target)
                <= MAX_DISTANCE * MAX_DISTANCE;
    }

    @Override
    public void start() {
    }

    @Override
    public void tick() {

        if (target == null) {
            return;
        }


        boolean playerLooking =
                isPlayerLookingAtCreeper();

        if (!playerLooking) {


            creeper.getNavigation().moveTo(
                    target,
                    BOOST_SPEED
            );

        } else {


            creeper.getNavigation().moveTo(
                    target,
                    NORMAL_SPEED
            );
        }
    }

    private boolean isPlayerLookingAtCreeper() {

        if (target == null) {
            return false;
        }


        var look =
                target.getViewVector(1.0F)
                        .normalize();


        var toCreeper =
                creeper.position()
                        .subtract(target.position())
                        .normalize();


        double dot =
                look.dot(toCreeper);


        return dot > 0.55D;
    }

    @Override
    public void stop() {

        target = null;

        creeper.getNavigation().stop();
    }
}