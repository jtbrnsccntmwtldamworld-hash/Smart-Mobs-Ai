package com.smartanimals.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Sheep;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.EnumSet;
import java.util.Random;

public class SheepGrazingGoal extends Goal {

    private final Sheep sheep;
    private final double speed;

    private BlockPos target;

    private int timer;

    private static final Random RANDOM = new Random();

    public SheepGrazingGoal(Sheep sheep, double speed) {
        this.sheep = sheep;
        this.speed = speed;

        this.setFlags(
                EnumSet.of(Flag.MOVE)
        );
    }

    @Override
    public boolean canUse() {

        if (!isDay()) {
            return false;
        }

        if (sheep.level().isRaining()) {
            return false;
        }

        if (RANDOM.nextInt(100) != 0) {
            return false;
        }

        target = findGrass();

        return target != null;
    }

    @Override
    public boolean canContinueToUse() {

        if (!isDay()) {
            return false;
        }

        if (sheep.level().isRaining()) {
            return false;
        }

        return target != null && timer > 0;
    }

    @Override
    public void start() {

        timer = 60;

        moveToTarget();
    }

    @Override
    public void tick() {

        if (target == null) {
            return;
        }

        double x =
                sheep.getX()
                        - (target.getX() + 0.5D);

        double y =
                sheep.getY()
                        - target.getY();

        double z =
                sheep.getZ()
                        - (target.getZ() + 0.5D);

        double targetDistance =
                x * x + y * y + z * z;

        if (targetDistance > 3.0D) {

            if (sheep.getNavigation().isDone()) {
                moveToTarget();
            }

            return;
        }

        sheep.getNavigation().stop();

        timer--;

        if (timer <= 0) {
            graze();
        }
    }

    @Override
    public void stop() {

        target = null;
        timer = 0;

        sheep.getNavigation().stop();
    }

    private boolean isDay() {

        long time =
                sheep.level()
                        .getDayTime()
                        % 24000L;

        return time < 12000L;
    }

    private BlockPos findGrass() {

        BlockPos center =
                sheep.blockPosition();

        MutableBlockPos mutable =
                new MutableBlockPos();

        for (int attempt = 0; attempt < 30; attempt++) {

            int x =
                    center.getX()
                            + RANDOM.nextInt(21)
                            - 10;

            int z =
                    center.getZ()
                            + RANDOM.nextInt(21)
                            - 10;

            int y =
                    center.getY()
                            + RANDOM.nextInt(5)
                            - 2;

            mutable.set(x, y, z);

            BlockState state =
                    sheep.level()
                            .getBlockState(mutable);

            if (state.is(Blocks.TALL_GRASS)
                    || state.is(Blocks.GRASS_BLOCK)) {

                return new BlockPos(x, y, z);
            }
        }

        return null;
    }

    private void moveToTarget() {

        if (target == null) {
            return;
        }

        sheep.getNavigation().moveTo(
                target.getX() + 0.5D,
                target.getY(),
                target.getZ() + 0.5D,
                speed
        );
    }

    private void graze() {

        if (target == null) {
            return;
        }

        BlockState state =
                sheep.level()
                        .getBlockState(target);

        if (state.is(Blocks.TALL_GRASS)) {

            sheep.level().destroyBlock(
                    target,
                    false
            );

            return;
        }

        if (state.is(Blocks.GRASS_BLOCK)) {

            sheep.level().setBlock(
                    target,
                    Blocks.DIRT.defaultBlockState(),
                    3
            );
        }
    }
}