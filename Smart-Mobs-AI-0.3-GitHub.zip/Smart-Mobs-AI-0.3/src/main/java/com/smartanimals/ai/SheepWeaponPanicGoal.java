package com.smartanimals.ai;

import com.smartanimals.util.MessageHelper;

import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Sheep;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.player.Player;

import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;

public class SheepWeaponPanicGoal extends Goal {

    private final Sheep sheep;


    private static final double PANIC_SPEED = 1.7D;

    private Player player;
    private Wolf wolf;

    private double targetX;
    private double targetY;
    private double targetZ;

    private static final Random RANDOM = new Random();

    private int checkCooldown = 0;
    private int escapeCooldown = 0;

    private static final double DETECTION_RADIUS = 5.0D;
    private static final double ESCAPE_DISTANCE = 8.0D;

    private static final long ALARM_COOLDOWN = 40L;

    private long lastAlarmTime = -100L;

    private static final Map<Sheep, Integer> SCARED_SHEEP =
            new WeakHashMap<>();

    public SheepWeaponPanicGoal(
            Sheep sheep,
            double speed
    ) {

        this.sheep = sheep;

        this.setFlags(
                EnumSet.of(Flag.MOVE)
        );
    }

    @Override
    public boolean canUse() {

        Player nearbyPlayer =
                this.sheep.level().getNearestPlayer(
                        this.sheep,
                        DETECTION_RADIUS
                );


        if (nearbyPlayer != null
                && nearbyPlayer.isAlive()
                && !nearbyPlayer.isCreative()
                && WeaponPanicUtil.isHoldingWeapon(nearbyPlayer)
                && this.sheep.hasLineOfSight(nearbyPlayer)) {

            this.player = nearbyPlayer;
            this.wolf = null;

            this.checkCooldown = 10;
            this.escapeCooldown = 0;

            alarm();

            chooseEscapeFrom(
                    nearbyPlayer.getX(),
                    nearbyPlayer.getZ()
            );

            panicNearbySheep();

            return true;
        }


        List<Wolf> nearbyWolves =
                this.sheep.level().getEntitiesOfClass(
                        Wolf.class,
                        this.sheep.getBoundingBox()
                                .inflate(DETECTION_RADIUS)
                );

        if (!nearbyWolves.isEmpty()) {

            Wolf nearbyWolf =
                    nearbyWolves.get(0);

            if (!nearbyWolf.isAlive()) {
                return false;
            }

            this.wolf = nearbyWolf;
            this.player = null;

            this.checkCooldown = 10;
            this.escapeCooldown = 0;

            alarm();

            chooseEscapeFrom(
                    nearbyWolf.getX(),
                    nearbyWolf.getZ()
            );

            panicNearbySheep();

            return true;
        }

        return false;
    }

    @Override
    public boolean canContinueToUse() {

        if (this.player == null
                && this.wolf == null) {

            return false;
        }


        if (this.player != null) {

            if (!this.player.isAlive()) {
                return false;
            }

            if (this.player.isCreative()) {
                return false;
            }

            if (this.sheep.distanceToSqr(
                    this.player)
                    > DETECTION_RADIUS
                    * DETECTION_RADIUS) {

                return false;
            }

            if (!WeaponPanicUtil.isHoldingWeapon(this.player)) {
                return false;
            }

            if (!this.sheep.hasLineOfSight(
                    this.player)) {

                return false;
            }
        }


        if (this.wolf != null) {

            if (!this.wolf.isAlive()) {
                return false;
            }

            if (this.sheep.distanceToSqr(
                    this.wolf)
                    > DETECTION_RADIUS
                    * DETECTION_RADIUS) {

                return false;
            }
        }

        return true;
    }

    @Override
    public void start() {

        this.escapeCooldown = 0;

        runAway();
    }

    @Override
    public void tick() {


        if (this.player != null) {

            if (this.player.isCreative()) {
                this.sheep.getNavigation().stop();
                return;
            }

            if (this.checkCooldown > 0) {
                this.checkCooldown--;
            }

            if (this.checkCooldown <= 0) {

                this.checkCooldown = 10;

                if (!WeaponPanicUtil.isHoldingWeapon(
                        this.player)) {

                    this.sheep.getNavigation().stop();
                    return;
                }

                if (this.sheep.distanceToSqr(
                        this.player)
                        > DETECTION_RADIUS
                        * DETECTION_RADIUS) {

                    this.sheep.getNavigation().stop();
                    return;
                }

                if (!this.sheep.hasLineOfSight(
                        this.player)) {

                    this.sheep.getNavigation().stop();
                    return;
                }
            }
        }


        if (this.escapeCooldown > 0) {
            this.escapeCooldown--;
        }

        if (this.escapeCooldown <= 0
                || this.sheep.getNavigation().isDone()) {

            this.escapeCooldown = 5;

            if (this.player != null) {

                chooseEscapeFrom(
                        this.player.getX(),
                        this.player.getZ()
                );

            } else if (this.wolf != null) {

                chooseEscapeFrom(
                        this.wolf.getX(),
                        this.wolf.getZ()
                );
            }

            runAway();
        }
    }

    @Override
    public void stop() {

        this.player = null;
        this.wolf = null;

        this.checkCooldown = 0;
        this.escapeCooldown = 0;

        this.sheep.getNavigation().stop();
    }

    private void chooseEscapeFrom(
            double threatX,
            double threatZ
    ) {

        double dx =
                this.sheep.getX() - threatX;

        double dz =
                this.sheep.getZ() - threatZ;

        double distance =
                Math.sqrt(
                        dx * dx
                                + dz * dz
                );

        if (distance < 0.001D) {

            double angle =
                    RANDOM.nextDouble()
                            * Math.PI
                            * 2.0D;

            dx = Math.cos(angle);
            dz = Math.sin(angle);

        } else {

            dx /= distance;
            dz /= distance;
        }

        double escapeDistance =
                ESCAPE_DISTANCE
                        + RANDOM.nextDouble()
                        * 4.0D;

        this.targetX =
                this.sheep.getX()
                        + dx * escapeDistance;

        this.targetY =
                this.sheep.getY() + 1.0D;

        this.targetZ =
                this.sheep.getZ()
                        + dz * escapeDistance;
    }

    private void runAway() {

        if (this.player != null
                && this.player.isCreative()) {

            return;
        }
        this.sheep.getNavigation().moveTo(
                this.targetX,
                this.targetY,
                this.targetZ,
                PANIC_SPEED
        );
    }

    private void panicNearbySheep() {

        List<Sheep> nearbySheep =
                this.sheep.level().getEntitiesOfClass(
                        Sheep.class,
                        this.sheep.getBoundingBox()
                                .inflate(10.0D)
                );

        for (Sheep otherSheep : nearbySheep) {

            if (otherSheep == this.sheep) {
                continue;
            }

            double angle =
                    RANDOM.nextDouble()
                            * Math.PI
                            * 2.0D;

            double distance =
                    6.0D
                            + RANDOM.nextDouble()
                            * 6.0D;

            double targetX =
                    otherSheep.getX()
                            + Math.cos(angle)
                            * distance;

            double targetZ =
                    otherSheep.getZ()
                            + Math.sin(angle)
                            * distance;

            otherSheep.getNavigation().moveTo(
                    targetX,
                    otherSheep.getY() + 1.0D,
                    targetZ,
                    PANIC_SPEED
            );
        }
    }

    private void alarm() {

        long currentTime =
                this.sheep.level().getGameTime();

        if (currentTime - lastAlarmTime
                < ALARM_COOLDOWN) {

            return;
        }

        this.sheep.playSound(
                SoundEvents.SHEEP_AMBIENT,
                1.0F,
                1.0F
        );

        if (this.player != null
                && !this.player.isCreative()) {

            int scaredCount =
                    SCARED_SHEEP.getOrDefault(
                            this.sheep,
                            0
                    );

            int nearbySheepCount =
                    this.sheep.level()
                            .getEntitiesOfClass(
                                    Sheep.class,
                                    this.sheep
                                            .getBoundingBox()
                                            .inflate(10.0D)
                            )
                            .size();

            if (scaredCount == 0) {



                MessageHelper.sendActionBarIfEnabled(
                        this.player,
                        Component.translatable(
                                "message.smartmobs.sheep_scared"
                        )
                );

            } else {

                if (nearbySheepCount >= 5) {

                    MessageHelper.sendActionBarIfEnabled(
                            this.player,
                            Component.translatable(
                                    "message.smartmobs.sheep_still_afraid_plural"
                            )
                    );

                } else {

                    MessageHelper.sendActionBarIfEnabled(
                            this.player,
                            Component.translatable(
                                    "message.smartmobs.sheep_still_afraid_singular"
                            )
                    );
                }
            }

            SCARED_SHEEP.put(
                    this.sheep,
                    scaredCount + 1
            );
        }

        lastAlarmTime = currentTime;
    }
}
