package com.smartanimals.ai;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterials;
import net.minecraft.world.item.ItemStack;


public final class PiglinUtil {

    private PiglinUtil() {}

    public static boolean hasAnyGoldArmor(Player player) {
        return isGoldArmor(player.getItemBySlot(EquipmentSlot.HEAD))
                || isGoldArmor(player.getItemBySlot(EquipmentSlot.CHEST))
                || isGoldArmor(player.getItemBySlot(EquipmentSlot.LEGS))
                || isGoldArmor(player.getItemBySlot(EquipmentSlot.FEET));
    }

    public static boolean isGoldArmor(ItemStack stack) {
        if (!(stack.getItem() instanceof ArmorItem armor)) {
            return false;
        }

        return armor.getMaterial() == ArmorMaterials.GOLD;
    }
}
