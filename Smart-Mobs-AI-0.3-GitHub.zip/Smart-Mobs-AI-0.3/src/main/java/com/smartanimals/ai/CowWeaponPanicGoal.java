 package com.smartanimals.ai;

import com.smartanimals.util.MessageHelper;

import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Cow;
import net.minecraft.world.entity.player.Player;

import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;

public class CowWeaponPanicGoal extends Goal {

    private final Cow cow;


    private static final double PANIC_SPEED = 2.0D;

    private Player player;

    private double targetX;
    private double targetY;
    private double targetZ;

    private static final Random RANDOM = new Random();

    private int checkCooldown = 0;
    private int escapeCooldown = 0;

    private static final double DETECTION_RADIUS = 5.0D;
    private static final double ESCAPE_DISTANCE = 8.0D;

    private static final long ALARM_COOLDOWN = 40L;

    private long lastAlarmTime = -100L;


    private static final Map<Cow, Integer> SCARED_COWS =
            new WeakHashMap<>();

    public CowWeaponPanicGoal(Cow cow) {

        this.cow = cow;

        this.setFlags(
                EnumSet.of(Flag.MOVE)
        );
    }

    @Override
    public boolean canUse() {

        Player nearbyPlayer =
                this.cow.level().getNearestPlayer(
                        this.cow,
                        DETECTION_RADIUS
                );

        if (nearbyPlayer == null) {
            return false;
        }

        if (!nearbyPlayer.isAlive()) {
            return false;
        }

        if (nearbyPlayer.isCreative()) {
            return false;
        }

        if (!WeaponPanicUtil.isHoldingWeapon(nearbyPlayer)) {
            return false;
        }


        if (!this.cow.hasLineOfSight(nearbyPlayer)) {
            return false;
        }

        this.player = nearbyPlayer;
        this.escapeCooldown = 0;

        alarm();

        chooseEscapeFrom(
                nearbyPlayer.getX(),
                nearbyPlayer.getZ()
        );

        panicNearbyCows();

        return true;
    }

    @Override
    public boolean canContinueToUse() {

        if (this.player == null) {
            return false;
        }

        if (!this.player.isAlive()) {
            return false;
        }

        if (this.player.isCreative()) {
            return false;
        }


        if (this.cow.distanceToSqr(this.player)
                > DETECTION_RADIUS
                * DETECTION_RADIUS) {

            return false;
        }


        if (!WeaponPanicUtil.isHoldingWeapon(this.player)) {
            return false;
        }


        if (!this.cow.hasLineOfSight(this.player)) {
            return false;
        }

        return true;
    }

    @Override
    public void start() {

        this.escapeCooldown = 0;

        chooseEscapeFrom(
                this.player.getX(),
                this.player.getZ()
        );

        runAway();
    }

    @Override
    public void tick() {


        if (this.checkCooldown > 0) {
            this.checkCooldown--;
        }

        if (this.checkCooldown <= 0) {

            this.checkCooldown = 10;
            if (!WeaponPanicUtil.isHoldingWeapon(this.player)) {
                this.cow.getNavigation().stop();
                return;
            }

            if (this.cow.distanceToSqr(this.player)
                    > DETECTION_RADIUS
                    * DETECTION_RADIUS) {

                this.cow.getNavigation().stop();
                return;
            }

            if (!this.cow.hasLineOfSight(this.player)) {
                this.cow.getNavigation().stop();
                return;
            }
        }


        if (this.escapeCooldown > 0) {
            this.escapeCooldown--;
        }

        if (this.escapeCooldown <= 0
                || this.cow.getNavigation().isDone()) {

            this.escapeCooldown = 5;

            chooseEscapeFrom(
                    this.player.getX(),
                    this.player.getZ()
            );

            runAway();
        }
    }

    @Override
    public void stop() {

        this.player = null;

        this.checkCooldown = 0;
        this.escapeCooldown = 0;

        this.cow.getNavigation().stop();
    }

    private void chooseEscapeFrom(
            double threatX,
            double threatZ
    ) {

        double dx =
                this.cow.getX() - threatX;

        double dz =
                this.cow.getZ() - threatZ;

        double distance =
                Math.sqrt(
                        dx * dx
                                + dz * dz
                );

        if (distance < 0.001D) {

            double angle =
                    RANDOM.nextDouble()
                            * Math.PI
                            * 2.0D;

            dx = Math.cos(angle);
            dz = Math.sin(angle);

        } else {

            dx /= distance;
            dz /= distance;
        }


        double escapeDistance =
                ESCAPE_DISTANCE
                        + RANDOM.nextDouble()
                        * 4.0D;

        this.targetX =
                this.cow.getX()
                        + dx * escapeDistance;

        this.targetY =
                this.cow.getY() + 1.0D;

        this.targetZ =
                this.cow.getZ()
                        + dz * escapeDistance;
    }

    private void runAway() {

        this.cow.getNavigation().moveTo(
                this.targetX,
                this.targetY,
                this.targetZ,
                PANIC_SPEED
        );
    }

    private void panicNearbyCows() {

        List<Cow> nearbyCows =
                this.cow.level().getEntitiesOfClass(
                        Cow.class,
                        this.cow.getBoundingBox()
                                .inflate(10.0D)
                );

        for (Cow otherCow : nearbyCows) {

            if (otherCow == this.cow) {
                continue;
            }

            double angle =
                    RANDOM.nextDouble()
                            * Math.PI
                            * 2.0D;

            double distance =
                    6.0D
                            + RANDOM.nextDouble()
                            * 6.0D;

            double targetX =
                    otherCow.getX()
                            + Math.cos(angle)
                            * distance;

            double targetZ =
                    otherCow.getZ()
                            + Math.sin(angle)
                            * distance;

            otherCow.getNavigation().moveTo(
                    targetX,
                    otherCow.getY() + 1.0D,
                    targetZ,
                    PANIC_SPEED
            );
        }
    }

    private void alarm() {

        long currentTime =
                this.cow.level().getGameTime();

        if (currentTime - lastAlarmTime
                < ALARM_COOLDOWN) {

            return;
        }
        this.cow.playSound(
                SoundEvents.COW_AMBIENT,
                1.0F,
                1.0F
        );

        if (this.player != null) {

            int scaredCount =
                    SCARED_COWS.getOrDefault(
                            this.cow,
                            0
                    );

            int nearbyCowCount =
                    this.cow.level()
                            .getEntitiesOfClass(
                                    Cow.class,
                                    this.cow.getBoundingBox()
                                            .inflate(10.0D)
                            )
                            .size();

            if (scaredCount == 0) {

                if (nearbyCowCount >= 5) {

                    MessageHelper.sendActionBarIfEnabled(
                            this.player,
                            Component.translatable(
                                    "message.smartmobs.cows_scared"
                            )
                    );

                } else {

                    MessageHelper.sendActionBarIfEnabled(
                            this.player,
                            Component.translatable(
                                    "message.smartmobs.cow_scared"
                            )
                    );
                }

            } else {

                if (nearbyCowCount >= 5) {

                    MessageHelper.sendActionBarIfEnabled(
                            this.player,
                            Component.translatable(
                                    "message.smartmobs.cows_still_afraid"
                            )
                    );

                } else {

                    MessageHelper.sendActionBarIfEnabled(
                            this.player,
                            Component.translatable(
                                    "message.smartmobs.cow_still_afraid"
                            )
                    );
                }
            }

            SCARED_COWS.put(
                    this.cow,
                    scaredCount + 1
            );
        }

        lastAlarmTime = currentTime;
    }
}