 package com.smartanimals.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.monster.Skeleton;
import net.minecraft.world.entity.monster.Zombie;

import java.util.EnumSet;

public class UndeadSunShelterGoal extends Goal {

    private final Zombie zombie;
    private final Skeleton skeleton;

    private static final int SEARCH_RADIUS = 12;
    private static final int CHECK_INTERVAL = 80;

    private static final double SHELTER_SPEED = 1.0D;


    private static final double ZOMBIE_SHELTER_RADIUS = 3.0D;

    private BlockPos shelterPos;

    private int checkCooldown;

    private boolean insideShelter;

    public UndeadSunShelterGoal(Zombie zombie) {

        this.zombie = zombie;
        this.skeleton = null;

        this.setFlags(
                EnumSet.of(
                        Flag.MOVE
                )
        );
    }

    public UndeadSunShelterGoal(Skeleton skeleton) {

        this.zombie = null;
        this.skeleton = skeleton;

        this.setFlags(
                EnumSet.of(
                        Flag.MOVE
                )
        );
    }

    private Mob getMob() {

        if (this.zombie != null) {
            return this.zombie;
        }

        return this.skeleton;
    }

    private boolean isDay() {

        Mob mob = getMob();

        return mob.level().isDay();
    }


    private boolean hasHelmet() {

        Mob mob = getMob();

        return !mob.getItemBySlot(
                EquipmentSlot.HEAD
        ).isEmpty();
    }


    private boolean isSpaceFree(BlockPos pos) {

        Mob mob = getMob();


        if (!mob.level()
                .getBlockState(pos)
                .getCollisionShape(
                        mob.level(),
                        pos
                )
                .isEmpty()) {

            return false;
        }


        BlockPos head =
                pos.above();

        if (!mob.level()
                .getBlockState(head)
                .getCollisionShape(
                        mob.level(),
                        head
                )
                .isEmpty()) {

            return false;
        }


        BlockPos ground =
                pos.below();

        if (mob.level()
                .getBlockState(ground)
                .getCollisionShape(
                        mob.level(),
                        ground
                )
                .isEmpty()) {

            return false;
        }

        return true;
    }


    private boolean hasRoof(BlockPos pos) {

        Mob mob = getMob();


        BlockPos aboveHead =
                pos.above(2);

        if (mob.level()
                .getBlockState(aboveHead)
                .getCollisionShape(
                        mob.level(),
                        aboveHead
                )
                .isEmpty()) {

            return false;
        }


        BlockPos upper =
                pos.above(3);

        if (mob.level()
                .getBlockState(upper)
                .getCollisionShape(
                        mob.level(),
                        upper
                )
                .isEmpty()) {

            return false;
        }

        return true;
    }

    private boolean isSheltered(BlockPos pos) {

        if (!isSpaceFree(pos)) {
            return false;
        }

        if (!hasRoof(pos)) {
            return false;
        }

        Mob mob = getMob();


        if (mob.level().canSeeSky(pos)) {
            return false;
        }

        return true;
    }


    private boolean canReach(BlockPos pos) {

        Mob mob = getMob();

        var path =
                mob.getNavigation().createPath(
                        pos,
                        0
                );

        return path != null
                && path.canReach();
    }


    private BlockPos findNearestShelter() {

        Mob mob = getMob();

        BlockPos origin =
                mob.blockPosition();

        BlockPos best = null;

        double bestDistance = -1.0D;

        for (int x = -SEARCH_RADIUS;
             x <= SEARCH_RADIUS;
             x++) {

            for (int y = -2;
                 y <= 2;
                 y++) {

                for (int z = -SEARCH_RADIUS;
                     z <= SEARCH_RADIUS;
                     z++) {

                    BlockPos candidate =
                            origin.offset(
                                    x,
                                    y,
                                    z
                            );

                    double distance =
                            candidate.distSqr(
                                    origin
                            );


                    if (distance >
                            SEARCH_RADIUS
                                    * SEARCH_RADIUS) {

                        continue;
                    }


                    if (distance <= bestDistance) {
                        continue;
                    }


                    if (!isSpaceFree(candidate)) {
                        continue;
                    }

                    if (!hasRoof(candidate)) {
                        continue;
                    }

                    if (mob.level()
                            .canSeeSky(candidate)) {

                        continue;
                    }


                    if (!canReach(candidate)) {
                        continue;
                    }

                    best =
                            candidate;

                    bestDistance =
                            distance;
                }
            }
        }

        return best;
    }

    @Override
    public boolean canUse() {


        if (!isDay()) {
            return false;
        }


        if (hasHelmet()) {
            return false;
        }

        Mob mob = getMob();


        if (isSheltered(
                mob.blockPosition())) {

            this.shelterPos =
                    mob.blockPosition();

            this.insideShelter = true;


            this.setFlags(
                    EnumSet.noneOf(
                            Flag.class
                    )
            );

            return true;
        }

        this.shelterPos =
                findNearestShelter();

        if (this.shelterPos == null) {
            return false;
        }

        this.insideShelter = false;


        this.setFlags(
                EnumSet.of(
                        Flag.MOVE
                )
        );

        this.checkCooldown =
                CHECK_INTERVAL;

        return true;
    }

    @Override
    public boolean canContinueToUse() {

        if (!isDay()) {
            return false;
        }

        if (hasHelmet()) {
            return false;
        }

        Mob mob = getMob();


        if (this.skeleton != null) {

            if (isSheltered(
                    mob.blockPosition())) {

                return false;
            }

            return this.shelterPos != null;
        }


        if (this.zombie != null) {


            if (!this.insideShelter) {
                return this.shelterPos != null;
            }


            return true;
        }

        return false;
    }

    @Override
    public void start() {

        Mob mob = getMob();

        this.checkCooldown =
                CHECK_INTERVAL;


        if (isSheltered(
                mob.blockPosition())) {

            this.insideShelter = true;


            this.setFlags(
                    EnumSet.noneOf(
                            Flag.class
                    )
            );

            mob.getNavigation().stop();

            return;
        }

        this.insideShelter = false;


        this.setFlags(
                EnumSet.of(
                        Flag.MOVE
                )
        );

        moveToShelter();
    }

    @Override
    public void tick() {

        Mob mob = getMob();


        if (this.zombie != null) {


            if (!this.insideShelter
                    && isSheltered(
                            mob.blockPosition())) {

                this.insideShelter = true;


                this.setFlags(
                        EnumSet.noneOf(
                                Flag.class
                        )
                );

                mob.getNavigation().stop();

                return;
            }


            if (!this.insideShelter) {

                if (this.checkCooldown > 0) {
                    this.checkCooldown--;
                }

                if (this.checkCooldown <= 0) {

                    this.checkCooldown =
                            CHECK_INTERVAL;


                    if (this.shelterPos != null
                            && isSheltered(
                                    this.shelterPos)) {
            moveToShelter();

                    } else {


                        BlockPos newShelter =
                                findNearestShelter();

                        if (newShelter != null) {

                            this.shelterPos =
                                    newShelter;

                            moveToShelter();
                        }
                    }
                }

                if (mob.getNavigation().isDone()
                        && this.shelterPos != null) {

                    moveToShelter();
                }

                return;
            }


            if (this.shelterPos != null) {

                double distance =
                        mob.blockPosition()
                                .distSqr(
                                        this.shelterPos
                                );

                if (distance >
                        ZOMBIE_SHELTER_RADIUS
                                * ZOMBIE_SHELTER_RADIUS) {

                    this.insideShelter = false;

                    this.setFlags(
                            EnumSet.of(
                                    Flag.MOVE
                            )
                    );

                    moveToShelter();
                }
            }

            return;
        }


        if (this.skeleton != null) {

            if (isSheltered(
                    mob.blockPosition())) {

                mob.getNavigation().stop();

                return;
            }

            if (this.checkCooldown > 0) {
                this.checkCooldown--;
            }

            if (this.checkCooldown <= 0) {

                this.checkCooldown =
                        CHECK_INTERVAL;

                if (this.shelterPos != null
                        && isSheltered(
                                this.shelterPos)) {

                    moveToShelter();

                } else {

                    BlockPos newShelter =
                            findNearestShelter();

                    if (newShelter != null) {

                        this.shelterPos =
                                newShelter;

                        moveToShelter();
                    }
                }
            }

            if (mob.getNavigation().isDone()
                    && this.shelterPos != null) {

                moveToShelter();
            }
        }
    }

    private void moveToShelter() {

        if (this.shelterPos == null) {
            return;
        }

        Mob mob = getMob();

        mob.getNavigation().moveTo(
                this.shelterPos.getX() + 0.5D,
                this.shelterPos.getY(),
                this.shelterPos.getZ() + 0.5D,
                SHELTER_SPEED
        );
    }

    @Override
    public void stop() {

        Mob mob = getMob();

        mob.getNavigation().stop();

        this.shelterPos = null;

        this.checkCooldown = 0;

        this.insideShelter = false;


        this.setFlags(
                EnumSet.of(
                        Flag.MOVE
                )
        );
    }
}
