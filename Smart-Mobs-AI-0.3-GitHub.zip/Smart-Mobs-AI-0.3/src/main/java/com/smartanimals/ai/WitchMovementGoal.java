package com.smartanimals.ai;

import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.monster.Witch;
import net.minecraft.world.entity.player.Player;

import java.util.EnumSet;
import java.util.Random;

public class WitchMovementGoal extends Goal {

    private final Witch witch;
    private final Random random = new Random();

    private int moveCooldown;

    private double targetX;
    private double targetY;
    private double targetZ;

    public WitchMovementGoal(Witch witch) {

        this.witch = witch;

        this.setFlags(
                EnumSet.of(Flag.MOVE)
        );

        this.moveCooldown =
                20 + this.random.nextInt(40);
    }

    @Override
    public boolean canUse() {


        if (!(this.witch.getTarget() instanceof Player player)) {
            return false;
        }

        if (!player.isAlive()) {
            return false;
        }


        return this.moveCooldown <= 0;
    }

    @Override
    public boolean canContinueToUse() {


        return false;
    }

    @Override
    public void start() {

        this.moveCooldown =
                30 + this.random.nextInt(50);

        chooseNewPosition();
    }

    @Override
    public void tick() {


        this.witch.getNavigation().moveTo(
                this.targetX,
                this.targetY,
                this.targetZ,
                1.0D
        );
    }

    @Override
    public void stop() {


        this.witch.getNavigation().stop();
    }

    private void chooseNewPosition() {


        double offsetX =
                (this.random.nextDouble() - 0.5D) * 6.0D;

        double offsetZ =
                (this.random.nextDouble() - 0.5D) * 6.0D;


        double offsetY =
                (this.random.nextDouble() - 0.5D) * 2.0D;

        this.targetX =
                this.witch.getX() + offsetX;

        this.targetY =
                this.witch.getY() + offsetY;

        this.targetZ =
                this.witch.getZ() + offsetZ;
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }
}