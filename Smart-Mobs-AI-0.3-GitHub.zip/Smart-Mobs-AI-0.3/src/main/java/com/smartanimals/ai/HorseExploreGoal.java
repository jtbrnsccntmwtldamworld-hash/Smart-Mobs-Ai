package com.smartanimals.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.horse.Horse;

import java.util.EnumSet;
import java.util.Random;

public class HorseExploreGoal extends Goal {

    private final Horse horse;
    private final double speed;

    private BlockPos target;

    private int cooldown;
    private int exploreTime;

    private static final Random RANDOM = new Random();

    private static final int SEARCH_RADIUS = 12;
    private static final int MIN_DISTANCE = 5;

    private static final int MIN_EXPLORE_TIME = 80;
    private static final int MAX_EXPLORE_TIME = 160;

    private static final int MIN_COOLDOWN = 400;
    private static final int MAX_COOLDOWN = 800;

    public HorseExploreGoal(
            Horse horse,
            double speed) {

        this.horse = horse;
        this.speed = speed;

        this.setFlags(
                EnumSet.of(Flag.MOVE)
        );
    }

    @Override
    public boolean canUse() {


        if (!this.horse.isTamed()) {
            return false;
        }


        if (this.horse.isVehicle()) {
            return false;
        }


        if (!this.horse.onGround()) {
            return false;
        }


        if (this.cooldown > 0) {
            this.cooldown--;
            return false;
        }


        if (RANDOM.nextInt(100) >= 4) {
            return false;
        }


        this.target =
                findExplorationPosition();

        return this.target != null;
    }

    @Override
    public boolean canContinueToUse() {


        if (this.horse.isVehicle()) {
            return false;
        }

        if (!this.horse.isTamed()) {
            return false;
        }

        if (this.target == null) {
            return false;
        }

        if (this.exploreTime <= 0) {
            return false;
        }


        return !this.horse.getNavigation().isDone();
    }

    @Override
    public void start() {

        if (this.target == null) {
            return;
        }

        this.exploreTime =
                MIN_EXPLORE_TIME
                        + RANDOM.nextInt(
                                MAX_EXPLORE_TIME
                                        - MIN_EXPLORE_TIME
                        );

        moveToTarget();
    }

    @Override
    public void tick() {

        if (this.horse.isVehicle()) {
            return;
        }

        this.exploreTime--;


        if (this.horse.getNavigation().isDone()) {

            if (this.exploreTime <= 0) {
                return;
            }
        }
    }

    @Override
    public void stop() {

        this.target = null;
        this.exploreTime = 0;

        this.horse
                .getNavigation()
                .stop();


        this.cooldown =
                MIN_COOLDOWN
                        + RANDOM.nextInt(
                                MAX_COOLDOWN
                                        - MIN_COOLDOWN
                        );
    }

    private void moveToTarget() {

        if (this.target == null) {
            return;
        }
        this.horse
                .getNavigation()
                .moveTo(
                        this.target.getX() + 0.5D,
                        this.target.getY(),
                        this.target.getZ() + 0.5D,
                        this.speed
                );
    }

    private BlockPos findExplorationPosition() {

        BlockPos origin =
                this.horse.blockPosition();

        for (int attempt = 0;
             attempt < 20;
             attempt++) {

            int x =
                    origin.getX()
                            + RANDOM.nextInt(
                                    SEARCH_RADIUS * 2 + 1
                            )
                            - SEARCH_RADIUS;

            int z =
                    origin.getZ()
                            + RANDOM.nextInt(
                                    SEARCH_RADIUS * 2 + 1
                            )
                            - SEARCH_RADIUS;

            int dx =
                    x - origin.getX();

            int dz =
                    z - origin.getZ();


            if (dx * dx + dz * dz
                    < MIN_DISTANCE * MIN_DISTANCE) {

                continue;
            }

            for (int yOffset = -2;
                 yOffset <= 2;
                 yOffset++) {

                BlockPos position =
                        new BlockPos(
                                x,
                                origin.getY()
                                        + yOffset,
                                z
                        );

                BlockPos floor =
                        position.below();


                if (!this.horse.level()
                        .getBlockState(floor)
                        .isCollisionShapeFullBlock(
                                this.horse.level(),
                                floor
                        )) {

                    continue;
                }


                if (!this.horse.level()
                        .getBlockState(position)
                        .isAir()) {

                    continue;
                }


                if (!this.horse.level()
                        .getBlockState(
                                position.above()
                        )
                        .isAir()) {

                    continue;
                }

                return position;
            }
        }

        return null;
    }
}