 package com.smartanimals.ai;

import com.smartanimals.util.MessageHelper;

import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Pig;
import net.minecraft.world.entity.player.Player;

import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;

public class PigWeaponPanicGoal extends Goal {

    private final Pig pig;


    private static final double PANIC_SPEED = 1.6D;

    private Player player;

    private double targetX;
    private double targetY;
    private double targetZ;

    private static final Random RANDOM = new Random();

    private int checkCooldown = 0;
    private int escapeCooldown = 0;

    private static final double DETECTION_RADIUS = 5.0D;
    private static final double ESCAPE_DISTANCE = 8.0D;

    private static final long ALARM_COOLDOWN = 40L;

    private long lastAlarmTime = -100L;


    private static final Map<Pig, Integer> SCARED_PIGS =
            new WeakHashMap<>();

    public PigWeaponPanicGoal(Pig pig) {

        this.pig = pig;

        this.setFlags(
                EnumSet.of(Flag.MOVE)
        );
    }

    @Override
    public boolean canUse() {

        Player nearbyPlayer =
                this.pig.level().getNearestPlayer(
                        this.pig,
                        DETECTION_RADIUS
                );


        if (nearbyPlayer != null
                && nearbyPlayer.isAlive()
                && !nearbyPlayer.isCreative()
                && WeaponPanicUtil.isHoldingWeapon(nearbyPlayer)
                && this.pig.hasLineOfSight(nearbyPlayer)) {

            this.player = nearbyPlayer;

            this.checkCooldown = 10;
            this.escapeCooldown = 0;

            alarm();

            chooseEscapeFrom(
                    nearbyPlayer.getX(),
                    nearbyPlayer.getZ()
            );

            panicNearbyPigs();

            return true;
        }

        return false;
    }

    @Override
    public boolean canContinueToUse() {

        if (this.player == null) {
            return false;
        }

        if (!this.player.isAlive()) {
            return false;
        }

        if (this.player.isCreative()) {
            return false;
        }


        if (this.pig.distanceToSqr(
                this.player)
                > DETECTION_RADIUS
                * DETECTION_RADIUS) {

            return false;
        }


        if (!WeaponPanicUtil.isHoldingWeapon(this.player)) {
            return false;
        }


        if (!this.pig.hasLineOfSight(
                this.player)) {

            return false;
        }

        return true;
    }

    @Override
    public void start() {

        this.checkCooldown = 10;
        this.escapeCooldown = 0;

        runAway();
    }

    @Override
    public void tick() {


        if (this.checkCooldown > 0) {
            this.checkCooldown--;
        }

        if (this.checkCooldown <= 0) {

            this.checkCooldown = 10;

            if (!this.player.isAlive()) {
                this.pig.getNavigation().stop();
                return;
            }

            if (this.player.isCreative()) {
                this.pig.getNavigation().stop();
                return;
            }
            if (!WeaponPanicUtil.isHoldingWeapon(
                    this.player)) {

                this.pig.getNavigation().stop();
                return;
            }

            if (this.pig.distanceToSqr(
                    this.player)
                    > DETECTION_RADIUS
                    * DETECTION_RADIUS) {

                this.pig.getNavigation().stop();
                return;
            }

            if (!this.pig.hasLineOfSight(
                    this.player)) {

                this.pig.getNavigation().stop();
                return;
            }
        }


        if (this.escapeCooldown > 0) {
            this.escapeCooldown--;
        }

        if (this.escapeCooldown <= 0
                || this.pig.getNavigation().isDone()) {

            this.escapeCooldown = 5;

            if (this.player != null) {

                chooseEscapeFrom(
                        this.player.getX(),
                        this.player.getZ()
                );
            }

            runAway();
        }
    }

    @Override
    public void stop() {

        this.player = null;

        this.checkCooldown = 0;
        this.escapeCooldown = 0;

        this.pig.getNavigation().stop();
    }

    private void chooseEscapeFrom(
            double threatX,
            double threatZ
    ) {

        double dx =
                this.pig.getX()
                        - threatX;

        double dz =
                this.pig.getZ()
                        - threatZ;

        double distance =
                Math.sqrt(
                        dx * dx
                                + dz * dz
                );

        if (distance < 0.001D) {

            double angle =
                    RANDOM.nextDouble()
                            * Math.PI
                            * 2.0D;

            dx = Math.cos(angle);
            dz = Math.sin(angle);

        } else {

            dx /= distance;
            dz /= distance;
        }

        double escapeDistance =
                ESCAPE_DISTANCE
                        + RANDOM.nextDouble()
                        * 4.0D;

        this.targetX =
                this.pig.getX()
                        + dx * escapeDistance;

        this.targetY =
                this.pig.getY() + 1.0D;

        this.targetZ =
                this.pig.getZ()
                        + dz * escapeDistance;
    }

    private void runAway() {

        if (this.player != null
                && this.player.isCreative()) {

            return;
        }

        this.pig.getNavigation().moveTo(
                this.targetX,
                this.targetY,
                this.targetZ,
                PANIC_SPEED
        );
    }

    private void panicNearbyPigs() {

        List<Pig> nearbyPigs =
                this.pig.level().getEntitiesOfClass(
                        Pig.class,
                        this.pig.getBoundingBox()
                                .inflate(10.0D)
                );

        for (Pig otherPig : nearbyPigs) {

            if (otherPig == this.pig) {
                continue;
            }

            double angle =
                    RANDOM.nextDouble()
                            * Math.PI
                            * 2.0D;

            double distance =
                    6.0D
                            + RANDOM.nextDouble()
                            * 6.0D;

            double targetX =
                    otherPig.getX()
                            + Math.cos(angle)
                            * distance;

            double targetZ =
                    otherPig.getZ()
                            + Math.sin(angle)
                            * distance;

            otherPig.getNavigation().moveTo(
                    targetX,
                    otherPig.getY() + 1.0D,
                    targetZ,
                    PANIC_SPEED
            );
        }
    }

    private void alarm() {

        long currentTime =
                this.pig.level().getGameTime();
        if (currentTime - lastAlarmTime
                < ALARM_COOLDOWN) {

            return;
        }

        this.pig.playSound(
                SoundEvents.PIG_AMBIENT,
                1.0F,
                1.0F
        );

        if (this.player != null) {

            int scaredCount =
                    SCARED_PIGS.getOrDefault(
                            this.pig,
                            0
                    );

            int nearbyPigCount =
                    this.pig.level()
                            .getEntitiesOfClass(
                                    Pig.class,
                                    this.pig.getBoundingBox()
                                            .inflate(10.0D)
                            )
                            .size();


            if (scaredCount == 0) {

                if (nearbyPigCount >= 5) {

                    MessageHelper.sendActionBarIfEnabled(
                            this.player,
                            Component.translatable(
                                    "message.smartmobs.pigs_scared"
                            )
                    );

                } else {

                    MessageHelper.sendActionBarIfEnabled(
                            this.player,
                            Component.translatable(
                                    "message.smartmobs.pig_scared"
                            )
                    );
                }
            }


            else {

                if (nearbyPigCount >= 5) {

                    MessageHelper.sendActionBarIfEnabled(
                            this.player,
                            Component.translatable(
                                    "message.smartmobs.pigs_still_afraid"
                            )
                    );

                } else {

                    MessageHelper.sendActionBarIfEnabled(
                            this.player,
                            Component.translatable(
                                    "message.smartmobs.pig_still_afraid"
                            )
                    );
                }
            }


            SCARED_PIGS.put(
                    this.pig,
                    scaredCount + 1
            );
        }

        lastAlarmTime = currentTime;
    }
}