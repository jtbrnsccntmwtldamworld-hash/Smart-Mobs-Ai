package com.smartanimals.ai;

import com.smartanimals.item.ModItems;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;


public final class WeaponPanicUtil {

    private WeaponPanicUtil() {
    }


    public static boolean isWeapon(
            ItemStack item) {

        return !item.is(ModItems.SILENT_BLADE)
                && (item.getItem() instanceof SwordItem
                    || item.getItem() instanceof AxeItem);
    }


    public static boolean isHoldingWeapon(
            Player player) {

        boolean mainHand = isWeapon(
                player.getMainHandItem()
        );
        boolean offhand = isWeapon(
                player.getOffhandItem()
        );

        boolean result = mainHand || offhand;

        return result;
    }


    public static boolean isWeaponIncludingSilentBlade(
            ItemStack item) {

        return item.getItem() instanceof SwordItem
                || item.getItem() instanceof AxeItem;
    }


    public static boolean isHoldingWeaponIncludingSilentBlade(
            Player player) {

        return isWeaponIncludingSilentBlade(
                player.getMainHandItem()
        ) || isWeaponIncludingSilentBlade(
                player.getOffhandItem()
        );
    }
}
