 package com.smartanimals.ai;

import net.minecraft.world.item.Item;


public class PiglinTradeReward {



    public enum RewardType {


        NORMAL,


        FIRE_RESISTANCE,


        SPLASH_FIRE_RESISTANCE,


        SOUL_SPEED_I,


        SOUL_SPEED_II,


        SOUL_SPEED_III,


        SOUL_SPEED_BOOTS,


        SILENT_BLADE
    }



    private final Item item;



    private final RewardType type;



    private final double chance;



    private final int minAmount;
    private final int maxAmount;



    private final int minPrice;
    private final int maxPrice;



    private final int purchaseLimit;



    public PiglinTradeReward(
            Item item,
            double chance,
            int minAmount,
            int maxAmount,
            int minPrice,
            int maxPrice,
            int purchaseLimit
    ) {

        this(
                item,
                RewardType.NORMAL,
                chance,
                minAmount,
                maxAmount,
                minPrice,
                maxPrice,
                purchaseLimit
        );
    }



    public PiglinTradeReward(
            Item item,
            RewardType type,
            double chance,
            int minAmount,
            int maxAmount,
            int minPrice,
            int maxPrice,
            int purchaseLimit
    ) {

        this.item = item;
        this.type = type;
 this.chance = chance;

        this.minAmount = minAmount;
        this.maxAmount = maxAmount;

        this.minPrice = minPrice;
        this.maxPrice = maxPrice;

        this.purchaseLimit = purchaseLimit;
    }



    public Item getItem() {

        return item;
    }



    public RewardType getType() {

        return type;
    }



    public double getChance() {

        return chance;
    }



    public int getMinAmount() {

        return minAmount;
    }



    public int getMaxAmount() {

        return maxAmount;
    }



    public int getMinPrice() {

        return minPrice;
    }



    public int getMaxPrice() {

        return maxPrice;
    }



    public int getPurchaseLimit() {

        return purchaseLimit;
    }



    public boolean isSpecial() {

        return type != RewardType.NORMAL;
    }



    public boolean isSilentBlade() {

        return type == RewardType.SILENT_BLADE;
    }
}