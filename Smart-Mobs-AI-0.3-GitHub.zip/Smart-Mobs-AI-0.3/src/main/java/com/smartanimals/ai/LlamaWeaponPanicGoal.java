package com.smartanimals.ai;

import com.smartanimals.util.MessageHelper;

import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.horse.Llama;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.LlamaSpit;

import java.util.EnumSet;
import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;

public class LlamaWeaponPanicGoal extends Goal {

    private final Llama llama;

    private final double speed = 1.2D;

    private Player player;

    private double targetX;
    private double targetY;
    private double targetZ;

    private static final Random RANDOM = new Random();

    private int checkCooldown = 0;

    private static final double DETECTION_RADIUS = 8.0D;

    private static final long ALARM_COOLDOWN = 40L;

    private long lastAlarmTime = -100L;


    private static final Map<Llama, Integer> SCARED_LLAMAS =
            new WeakHashMap<>();

    public LlamaWeaponPanicGoal(Llama llama) {

        this.llama = llama;

        this.setFlags(
                EnumSet.of(
                        Flag.MOVE,
                        Flag.LOOK
                )
        );
    }

    @Override
    public boolean canUse() {

        Player nearbyPlayer =
                this.llama.level().getNearestPlayer(
                        this.llama,
                        DETECTION_RADIUS
                );


        if (nearbyPlayer != null
                && !nearbyPlayer.isCreative()
                && nearbyPlayer.isAlive()
                && WeaponPanicUtil.isHoldingWeaponIncludingSilentBlade(nearbyPlayer)) {

            this.player = nearbyPlayer;

            this.checkCooldown = 20;

            alarm();

            chooseEscapeFrom(
                    nearbyPlayer.getX(),
                    nearbyPlayer.getZ()
            );

            return true;
        }

        return false;
    }

    @Override
    public boolean canContinueToUse() {

        if (this.player == null) {
            return false;
        }

        if (!this.player.isAlive()) {
            return false;
        }


        if (this.player.isCreative()) {
            return false;
        }

        if (!WeaponPanicUtil.isHoldingWeaponIncludingSilentBlade(this.player)) {
            return false;
        }

        if (this.llama.distanceToSqr(
                this.player
        ) > DETECTION_RADIUS * DETECTION_RADIUS) {

            return false;
        }

        if (this.checkCooldown > 0) {
            this.checkCooldown--;
        }

        if (this.checkCooldown <= 0) {

            this.checkCooldown = 20;

            if (this.player.isCreative()) {
                return false;
            }

            if (!WeaponPanicUtil.isHoldingWeaponIncludingSilentBlade(this.player)) {
                return false;
            }

            if (this.llama.distanceToSqr(
                    this.player
            ) > DETECTION_RADIUS * DETECTION_RADIUS) {

                return false;
            }
        }

        return true;
    }

    @Override
    public void start() {

        runAway();
    }

    @Override
    public void tick() {


        if (this.player.isCreative()) {
            return;
        }


        this.llama.getLookControl().setLookAt(
                this.player,
                30.0F,
                30.0F
        );


        if (this.llama.getNavigation().isDone()
                && RANDOM.nextInt(10) == 0) {

            chooseEscapeFrom(
                    this.player.getX(),
                    this.player.getZ()
            );

            runAway();
        }


        if (RANDOM.nextInt(40) == 0) {

            shootLlamaSpit();

            alarmSpit();
        }
    }

    @Override
    public void stop() {

        this.player = null;

        this.checkCooldown = 0;

        this.llama.getNavigation().stop();
    }

    private void chooseEscapeFrom(
            double threatX,
            double threatZ
    ) {

        double dx =
                this.llama.getX()
                        - threatX;

        double dz =
                this.llama.getZ()
                        - threatZ;

        double distance =
                Math.sqrt(
                        dx * dx
                                + dz * dz
                );

        if (distance < 0.001D) {

            double angle =
                    RANDOM.nextDouble()
                            * Math.PI
                            * 2.0D;

            dx = Math.cos(angle);
            dz = Math.sin(angle);

        } else {

            dx /= distance;
            dz /= distance;
        }

        double escapeDistance =
                6.0D
                        + RANDOM.nextDouble()
                        * 5.0D;

        this.targetX =
                this.llama.getX()
                        + dx * escapeDistance;

        this.targetY =
                this.llama.getY() + 1.0D;

        this.targetZ =
                this.llama.getZ()
                        + dz * escapeDistance;
    }

    private void runAway() {

        this.llama.getNavigation().moveTo(
                this.targetX,
                this.targetY,
                this.targetZ,
                this.speed
        );
    }



    private void shootLlamaSpit() {

        if (this.llama.level().isClientSide()) {
            return;
        }

        if (this.player.isCreative()) {
            return;
        }

        if (!WeaponPanicUtil.isHoldingWeaponIncludingSilentBlade(this.player)) {
            return;
        }

        LlamaSpit spit =
                new LlamaSpit(
                        this.llama.level(),
                        this.llama
                );

        spit.setPos(
                this.llama.getX(),
                this.llama.getY()
                        + this.llama.getEyeHeight()
                        - 0.1D,
                this.llama.getZ()
        );

        spit.shoot(
                this.player.getX()
                        - this.llama.getX(),

                this.player.getY()
                        + this.player.getEyeHeight()
                        - 1.1D
                        - spit.getY(),

                this.player.getZ()
                        - this.llama.getZ(),

                1.5F,
                10.0F
        );

        this.llama.level().addFreshEntity(spit);

        this.llama.playSound(
                SoundEvents.LLAMA_SPIT,
                1.0F,
                1.0F
        );
    }



    private void alarm() {

        long currentTime =
                this.llama.level().getGameTime();

        if (currentTime - lastAlarmTime
                < ALARM_COOLDOWN) {

            return;
        }

        this.llama.playSound(
                SoundEvents.LLAMA_ANGRY,
                1.0F,
                1.0F
        );

        if (!this.player.isCreative()) {

            int scaredCount =
                    SCARED_LLAMAS.getOrDefault(
                            this.llama,
                            0
                    );



            if (scaredCount == 0) {

                MessageHelper.sendActionBarIfEnabled(
                        this.player,
                        Component.translatable(
                                "message.smartmobs.llama_scared"
                        )
                );

            }

            else {

                MessageHelper.sendActionBarIfEnabled(
                        this.player,
                        Component.translatable(
                                "message.smartmobs.llama_still_angry"
                        )
                );
            }

            SCARED_LLAMAS.put(
                    this.llama,
                    scaredCount + 1
            );
        }

        lastAlarmTime = currentTime;
    }

    private void alarmSpit() {

        if (this.player.isCreative()) {
            return;
        }

        MessageHelper.sendActionBarIfEnabled(
                this.player,
                Component.translatable(
                        "message.smartmobs.llama_really_scared"
                )
        );
    }

}
