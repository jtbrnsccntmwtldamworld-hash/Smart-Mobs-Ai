package com.smartanimals.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Chicken;

import java.util.EnumSet;

public class ChickenHighGroundGoal extends Goal {

    private final Chicken chicken;
    private final double speed;

    private BlockPos target;

    private static final int SEARCH_RADIUS = 10;
    private static final int MAX_HEIGHT = 5;

    public ChickenHighGroundGoal(
            Chicken chicken,
            double speed) {

        this.chicken = chicken;
        this.speed = speed;

        this.setFlags(
                EnumSet.of(Flag.MOVE)
        );
    }

    @Override
    public boolean canUse() {


        if (!this.chicken.level().isRaining()) {
            return false;
        }


        this.target = findHighGround();

        return this.target != null;
    }

    @Override
    public boolean canContinueToUse() {

        if (!this.chicken.level().isRaining()) {
            return false;
        }

        if (this.target == null) {
            return false;
        }


        double distance =
                this.chicken.distanceToSqr(
                        this.target.getX() + 0.5D,
                        this.target.getY(),
                        this.target.getZ() + 0.5D
                );

        return distance > 2.0D;
    }

    @Override
    public void start() {
        moveToHighGround();
    }

    @Override
    public void tick() {

        if (this.target == null) {
            return;
        }

        if (this.chicken.getNavigation().isDone()) {

            this.target = findHighGround();

            if (this.target != null) {
                moveToHighGround();
            }
        }
    }

    @Override
    public void stop() {

        this.target = null;

        this.chicken
                .getNavigation()
                .stop();
    }

    private void moveToHighGround() {

        if (this.target == null) {
            return;
        }

        this.chicken
                .getNavigation()
                .moveTo(
                        this.target.getX() + 0.5D,
                        this.target.getY(),
                        this.target.getZ() + 0.5D,
                        this.speed
                );
    }

    private BlockPos findHighGround() {

        BlockPos chickenPos =
                this.chicken.blockPosition();

        BlockPos bestPosition = null;

        double bestScore =
                Double.MAX_VALUE;


        for (int x = -SEARCH_RADIUS;
             x <= SEARCH_RADIUS;
             x++) {

            for (int z = -SEARCH_RADIUS;
                 z <= SEARCH_RADIUS;
                 z++) {


                if (x * x + z * z >
                        SEARCH_RADIUS * SEARCH_RADIUS) {
                    continue;
                }

                for (int y = 1;
                     y <= MAX_HEIGHT;
                     y++) {

                    BlockPos groundPos =
                            chickenPos.offset(
                                    x,
                                    y,
                                    z
                            );


                    BlockPos floorPos =
                            groundPos.below();


                    if (!this.chicken.level()
                            .getBlockState(floorPos)
                            .isCollisionShapeFullBlock(
                                    this.chicken.level(),
                                    floorPos
                            )) {
                        continue;
                    }

                    if (!this.chicken.level()
                            .getBlockState(groundPos)
                            .isAir()) {
                        continue;
                    }


                    BlockPos headPos =
                            groundPos.above();

                    if (!this.chicken.level()
                            .getBlockState(headPos)
                            .isAir()) {
                        continue;
                    }


                    if (groundPos.getY()
                            <= chickenPos.getY()) {
                        continue;
                    }

                    double distance =
                            this.chicken.distanceToSqr(
                                    groundPos.getX() + 0.5D,
                                    groundPos.getY(),
                                    groundPos.getZ() + 0.5D
                            );


                    double heightBonus =
                            (groundPos.getY()
                                    - chickenPos.getY())
                                    * 0.25D;

                    double score =
                            distance
                                    - heightBonus;

                    if (score < bestScore) {

                        bestScore = score;
                        bestPosition = groundPos;
                    }
                }
            }
        }

        return bestPosition;
    }
}