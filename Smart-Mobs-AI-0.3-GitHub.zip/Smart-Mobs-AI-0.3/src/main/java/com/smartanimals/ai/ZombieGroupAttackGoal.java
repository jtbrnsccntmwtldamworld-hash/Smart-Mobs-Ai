package com.smartanimals.ai;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.monster.Zombie;

import java.util.EnumSet;
import java.util.List;

public class ZombieGroupAttackGoal extends Goal {

    private final Zombie zombie;

    private static final double GROUP_RADIUS = 20.0D;

    private int cooldown = 0;

    public ZombieGroupAttackGoal(
            Zombie zombie) {

        this.zombie = zombie;

        setFlags(
                EnumSet.of(
                        Flag.LOOK
                )
        );
    }

    @Override
    public boolean canUse() {

        LivingEntity target =
                zombie.getTarget();

        if (target == null) {
            return false;
        }

        if (!target.isAlive()) {
            return false;
        }

        return true;
    }

    @Override
    public boolean canContinueToUse() {

        LivingEntity target =
                zombie.getTarget();

        return target != null
                && target.isAlive();
    }

    @Override
    public void tick() {

        LivingEntity target =
                zombie.getTarget();

        if (target == null) {
            return;
        }

        if (!target.isAlive()) {
            return;
        }

        if (cooldown > 0) {
            cooldown--;
            return;
        }

        cooldown = 10;


        List<Zombie> nearbyZombies =
                zombie.level().getEntitiesOfClass(
                        Zombie.class,
                        zombie.getBoundingBox()
                                .inflate(GROUP_RADIUS)
                );

        for (Zombie nearbyZombie :
                nearbyZombies) {


            if (nearbyZombie == zombie) {
                continue;
            }


            LivingEntity nearbyTarget =
                    nearbyZombie.getTarget();

            if (nearbyTarget != null
                    && nearbyTarget.isAlive()) {
                continue;
            }


            nearbyZombie.setTarget(
                    target
            );
        }
    }
}