package com.smartanimals.ai;

import com.smartanimals.item.ModItems;

import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraft.world.item.alchemy.Potions;

public final class PiglinTradeItemFactory {

    private PiglinTradeItemFactory() {
    }



    public static ItemStack createReward(
            PiglinTradeReward reward,
            int amount
    ) {

        if (reward == null) {
            return ItemStack.EMPTY;
        }

        if (amount <= 0) {
            return ItemStack.EMPTY;
        }



        if (reward.getType()
                == PiglinTradeReward.RewardType.FIRE_RESISTANCE) {

            ItemStack stack =
                    PotionUtils.setPotion(
                            new ItemStack(Items.POTION),
                            Potions.FIRE_RESISTANCE
                    );

            stack.setCount(amount);

            return stack;
        }



        if (reward.getType()
                == PiglinTradeReward.RewardType.SPLASH_FIRE_RESISTANCE) {

            ItemStack stack =
                    PotionUtils.setPotion(
                            new ItemStack(Items.SPLASH_POTION),
                            Potions.FIRE_RESISTANCE
                    );

            stack.setCount(amount);

            return stack;
        }



        if (reward.getType()
                == PiglinTradeReward.RewardType.SOUL_SPEED_I) {

            return createEnchantedBook(
                    Enchantments.SOUL_SPEED,
                    1,
                    amount
            );
        }



        if (reward.getType()
                == PiglinTradeReward.RewardType.SOUL_SPEED_II) {

            return createEnchantedBook(
                    Enchantments.SOUL_SPEED,
                    2,
                    amount
            );
        }



        if (reward.getType()
                == PiglinTradeReward.RewardType.SOUL_SPEED_III) {

            return createEnchantedBook(
                    Enchantments.SOUL_SPEED,
                    3,
                    amount
            );
        }



        if (reward.getType()
                == PiglinTradeReward.RewardType.SOUL_SPEED_BOOTS) {

            ItemStack stack =
                    new ItemStack(
                            Items.GOLDEN_BOOTS,
                            amount
                    );

            addEnchantment(
                    stack,
                    Enchantments.SOUL_SPEED,
                    3
            );

            return stack;
        }



        if (reward.getType()
                == PiglinTradeReward.RewardType.SILENT_BLADE) {

            return new ItemStack(
                    ModItems.SILENT_BLADE,
                    amount
            );
        }



        if (reward.getItem() == null) {
            return ItemStack.EMPTY;
        }

        return new ItemStack(
                reward.getItem(),
                amount
        );
    }



    private static ItemStack createEnchantedBook(
            Enchantment enchantment,
            int level,
            int amount
    ) {

        ItemStack stack =
                new ItemStack(
                        Items.ENCHANTED_BOOK
                );



        EnchantedBookItem.addEnchantment(
                stack,
                new EnchantmentInstance(
                        enchantment,
                        level
                )
        );

        stack.setCount(amount);

        return stack;
    }



    private static void addEnchantment(
            ItemStack stack,
            Enchantment enchantment,
            int level
    ) {

        if (stack.isEmpty()) {
            return;
        }

        stack.enchant(
                enchantment,
                level
        );
    }
}