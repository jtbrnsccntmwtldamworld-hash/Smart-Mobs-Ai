package com.smartanimals.ai;

import com.smartanimals.util.MessageHelper;

import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Chicken;
import net.minecraft.world.entity.player.Player;

import java.util.EnumSet;
import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;

public class ChickenWeaponPanicGoal extends Goal {

    private final Chicken chicken;
    private final double speed;

    private Player threateningPlayer;

    private int checkCooldown = 0;
    private int escapeCooldown = 0;

    private static final double DETECTION_RADIUS = 5.0D;
    private static final double ESCAPE_DISTANCE = 8.0D;
    private static final long ALARM_COOLDOWN = 40L;

    private long lastAlarmTime = -100L;

    private static final Map<Chicken, Integer> SCARED_CHICKENS =
            new WeakHashMap<>();

    private static final Random RANDOM = new Random();

    public ChickenWeaponPanicGoal(
            Chicken chicken,
            double speed) {

        this.chicken = chicken;
        this.speed = speed;

        this.setFlags(
                EnumSet.of(Flag.MOVE)
        );
    }

    @Override
    public boolean canUse() {

        Player player =
                this.chicken.level().getNearestPlayer(
                        this.chicken,
                        DETECTION_RADIUS
                );

        if (player == null) {
            return false;
        }

        if (!player.isAlive()) {
            return false;
        }

        if (player.isCreative()) {
            return false;
        }

        if (!WeaponPanicUtil.isHoldingWeapon(player)) {
            return false;
        }


        if (!this.chicken.hasLineOfSight(player)) {
            return false;
        }

        this.threateningPlayer = player;
        this.checkCooldown = 10;
        this.escapeCooldown = 0;

        alarm();

        return true;
    }

    @Override
    public boolean canContinueToUse() {

        if (this.threateningPlayer == null) {
            return false;
        }

        if (!this.threateningPlayer.isAlive()) {
            return false;
        }

        if (this.threateningPlayer.isCreative()) {
            return false;
        }


        if (this.chicken.distanceToSqr(
                this.threateningPlayer)
                > DETECTION_RADIUS
                * DETECTION_RADIUS) {

            return false;
        }


        if (!WeaponPanicUtil.isHoldingWeapon(
                this.threateningPlayer)) {

            return false;
        }


        if (!this.chicken.hasLineOfSight(
                this.threateningPlayer)) {

            return false;
        }

        return true;
    }

    @Override
    public void start() {

        this.escapeCooldown = 0;

        runAway();
    }

    @Override
    public void tick() {

        if (this.threateningPlayer.isCreative()) {
            return;
        }


        if (this.checkCooldown > 0) {
            this.checkCooldown--;
        }

        if (this.checkCooldown <= 0) {

            this.checkCooldown = 10;

            if (!WeaponPanicUtil.isHoldingWeapon(
                    this.threateningPlayer)) {

                this.chicken.getNavigation().stop();
                return;
            }
            if (this.chicken.distanceToSqr(
                    this.threateningPlayer)
                    > DETECTION_RADIUS
                    * DETECTION_RADIUS) {

                this.chicken.getNavigation().stop();
                return;
            }

            if (!this.chicken.hasLineOfSight(
                    this.threateningPlayer)) {

                this.chicken.getNavigation().stop();
                return;
            }
        }


        if (this.escapeCooldown > 0) {
            this.escapeCooldown--;
        }

        if (this.escapeCooldown <= 0
                || this.chicken.getNavigation().isDone()) {

            this.escapeCooldown = 5;

            runAway();
        }
    }

    @Override
    public void stop() {

        this.threateningPlayer = null;
        this.checkCooldown = 0;
        this.escapeCooldown = 0;

        this.chicken.getNavigation().stop();
    }

    private void runAway() {

        double dx =
                this.chicken.getX()
                        - this.threateningPlayer.getX();

        double dz =
                this.chicken.getZ()
                        - this.threateningPlayer.getZ();

        double distance =
                Math.sqrt(
                        dx * dx
                                + dz * dz
                );


        if (distance < 0.001D) {

            double angle =
                    RANDOM.nextDouble()
                            * Math.PI
                            * 2.0D;

            dx = Math.cos(angle);
            dz = Math.sin(angle);

        } else {

            dx /= distance;
            dz /= distance;
        }

        double targetX =
                this.chicken.getX()
                        + dx * ESCAPE_DISTANCE;

        double targetY =
                this.chicken.getY() + 1.0D;

        double targetZ =
                this.chicken.getZ()
                        + dz * ESCAPE_DISTANCE;

        this.chicken.getNavigation().moveTo(
                targetX,
                targetY,
                targetZ,
                this.speed
        );
    }

    private void alarm() {

        long currentTime =
                this.chicken.level().getGameTime();

        if (currentTime - lastAlarmTime
                < ALARM_COOLDOWN) {

            return;
        }

        this.chicken.playSound(
                SoundEvents.CHICKEN_AMBIENT,
                1.0F,
                1.0F
        );

        if (this.threateningPlayer == null
                || this.threateningPlayer.isCreative()) {

            return;
        }

        int scaredCount =
                SCARED_CHICKENS.getOrDefault(
                        this.chicken,
                        0
                );

        int nearbyChickenCount =
                this.chicken.level()
                        .getEntitiesOfClass(
                                Chicken.class,
                                this.chicken
                                        .getBoundingBox()
                                        .inflate(10.0D)
                        )
                        .size();

        if (scaredCount == 0) {

            if (nearbyChickenCount >= 5) {

                MessageHelper.sendActionBarIfEnabled(
                        this.threateningPlayer,
                        Component.translatable(
                                "message.smartmobs.chickens_scared"
                        )
                );

            } else {

                MessageHelper.sendActionBarIfEnabled(
                        this.threateningPlayer,
                        Component.translatable(
                                "message.smartmobs.chicken_scared"
                        )
                );
            }

        } else {

            if (nearbyChickenCount >= 5) {

                MessageHelper.sendActionBarIfEnabled(
                        this.threateningPlayer,
                        Component.translatable(
                                "message.smartmobs.chickens_still_afraid"
                        )
                );

            } else {

                MessageHelper.sendActionBarIfEnabled(
                        this.threateningPlayer,
                        Component.translatable(
                                "message.smartmobs.chicken_still_afraid"
                        )
                );
            }
        }

        SCARED_CHICKENS.put(
                this.chicken,
                scaredCount + 1
        );

        lastAlarmTime = currentTime;
    }
}
