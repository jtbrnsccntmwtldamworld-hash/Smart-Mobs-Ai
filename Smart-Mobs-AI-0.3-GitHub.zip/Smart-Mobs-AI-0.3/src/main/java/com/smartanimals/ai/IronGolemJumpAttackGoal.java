package com.smartanimals.ai;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.IronGolem;

import java.util.EnumSet;

public class IronGolemJumpAttackGoal extends Goal {

    private final IronGolem golem;

    private int attackCooldown = 0;
    private int jumpTicks = 0;

    private boolean jumping = false;
    private boolean attackDone = false;

    private int attackCount = 0;



    private boolean knockbackPending = false;

    private int knockbackRetryTicks = 0;

    private int knockbackAttempts = 0;


    private boolean forcedKnockbackJump = false;



    private static final int ATTACK_COOLDOWN = 35;


    private static final int KNOCKBACK_RETRY_DELAY = 40;


    private static final int MAX_KNOCKBACK_ATTEMPTS = 2;


    private static final double KNOCKBACK_DISTANCE = 3.0D;

    private static final double START_DISTANCE = 3.0D;

    private static final double ATTACK_DISTANCE = 2.7D;

    private static final double JUMP_SPEED = 0.35D;

    private static final double JUMP_POWER = 0.6D;

    private static final double VERTICAL_JUMP_POWER = 0.69D;

    private static final double MAX_HEIGHT_DIFFERENCE = 3.0D;

    public IronGolemJumpAttackGoal(
            IronGolem golem) {

        this.golem = golem;

        setFlags(
                EnumSet.of(
                        Flag.MOVE,
                        Flag.LOOK
                )
        );
    }

    @Override
    public boolean canUse() {

        LivingEntity target =
                golem.getTarget();

        if (target == null) {
            return false;
        }

        if (!target.isAlive()) {
            return false;
        }

        if (golem.isInWater()) {
            return false;
        }


        if (attackCooldown > 0) {
            attackCooldown--;
            return false;
        }

        return true;
    }

    @Override
    public boolean canContinueToUse() {

        LivingEntity target =
                golem.getTarget();

        if (target == null) {
            return false;
        }

        if (!target.isAlive()) {
            return false;
        }

        return true;
    }

    @Override
    public void start() {

        jumpTicks = 0;

        jumping = false;

        attackDone = false;

        attackCooldown = 0;

        knockbackPending = false;

        knockbackRetryTicks = 0;

        knockbackAttempts = 0;

        forcedKnockbackJump = false;
    }

    @Override
    public void stop() {

        jumping = false;

        attackDone = false;

        jumpTicks = 0;

        knockbackPending = false;

        knockbackRetryTicks = 0;

        knockbackAttempts = 0;

        forcedKnockbackJump = false;

        golem.getNavigation().stop();
    }

    @Override
    public void tick() {

        LivingEntity target =
                golem.getTarget();

        if (target == null) {
            return;
        }

        if (!target.isAlive()) {
            return;
        }



        if (knockbackPending) {

            if (knockbackRetryTicks > 0) {
                knockbackRetryTicks--;
            }


            if (knockbackRetryTicks <= 0) {

                knockbackPending = false;


                if (knockbackAttempts
                        < MAX_KNOCKBACK_ATTEMPTS) {

                    forcedKnockbackJump = true;

                    attackCooldown = 0;
                }
            }
        }



        if (attackCooldown > 0) {
            attackCooldown--;
        }



        golem.getLookControl().setLookAt(
                target,
                30.0F,
                30.0F
        );



        if (!jumping) {


            if (!golem.onGround()) {
                return;
            }



            if (forcedKnockbackJump) {

                forcedKnockbackJump = false;

                golem.getNavigation().stop();

                jumping = true;

                jumpTicks = 0;

                attackDone = false;

                jumpTowardsTarget(target);

                return;
            }



            if (attackCooldown > 0) {

                golem.getNavigation().moveTo(
                        target,
                        1.0D
                );

                return;
            }



            double golemY =
                    golem.getBoundingBox()
                            .getCenter()
                            .y;

            double targetY =
                    target.getBoundingBox()
                            .getCenter()
                            .y;

            double heightDifference =
                    targetY - golemY;

            if (heightDifference
                    > MAX_HEIGHT_DIFFERENCE) {

                golem.getNavigation().moveTo(
                        target,
                        1.0D
                );

                return;
            }



            double dx =
                    target.getX()
                            - golem.getX();

            double dz =
                    target.getZ()
                            - golem.getZ();

            double horizontalDistance =
                    Math.sqrt(
                            dx * dx
                                    + dz * dz
                    );

            if (horizontalDistance
                    > START_DISTANCE) {

                golem.getNavigation().moveTo(
                        target,
                        1.0D
                );

                return;
            }



            golem.getNavigation().stop();

            jumping = true;

            jumpTicks = 0;

            attackDone = false;

            jumpTowardsTarget(target);

            return;
        }


        jumpTicks++;



        if (!attackDone
                && !golem.onGround()
                && golem.getDeltaMovement().y
                < -0.05D) {

            double distance =
                    golem.distanceToSqr(target);

            if (distance
                    <= ATTACK_DISTANCE
                    * ATTACK_DISTANCE) {

                performAttack(target);

                attackDone = true;
            }
        }



        if (golem.onGround()) {


            if (!attackDone) {

                double distance =
                        golem.distanceToSqr(target);

                if (distance
                        <= ATTACK_DISTANCE
                        * ATTACK_DISTANCE) {

                    performAttack(target);

                    attackDone = true;
                }
            }

            jumping = false;

            jumpTicks = 0;

            attackDone = false;


            if (!knockbackPending
                    && !forcedKnockbackJump) {

                attackCooldown =
                        ATTACK_COOLDOWN;
            }

            golem.getNavigation().stop();

            return;
        }



        if (jumpTicks > 30) {

            jumping = false;

            jumpTicks = 0;

            attackDone = false;


            if (knockbackPending) {

                attackCooldown = 0;

            } else {

                attackCooldown = 20;
            }

            golem.getNavigation().stop();
        }
    }



    private void jumpTowardsTarget(
            LivingEntity target) {

        double dx =
                target.getX()
                        - golem.getX();

        double dz =
                target.getZ()
                        - golem.getZ();

        double distance =
                Math.sqrt(
                        dx * dx
                                + dz * dz
                );

        double vertical =
                target.getBoundingBox()
                        .getCenter()
                        .y
                - golem.getBoundingBox()
                        .getCenter()
                        .y;

        double jumpPower =
                vertical >= 2.0D
                        ? VERTICAL_JUMP_POWER
                        : JUMP_POWER;

        if (distance < 0.01D) {

            if (vertical > 0.0D) {

                golem.setDeltaMovement(
                        0.0D,
                        jumpPower,
                        0.0D
                );

                golem.hasImpulse = true;
            }

            return;
        }

        double directionX =
                dx / distance;

        double directionZ =
                dz / distance;

        golem.setDeltaMovement(
                directionX * JUMP_SPEED,
                jumpPower,
                directionZ * JUMP_SPEED
        );

        golem.hasImpulse = true;
    }



    private void performAttack(
            LivingEntity target) {

        if (golem.distanceToSqr(target)
                > ATTACK_DISTANCE
                * ATTACK_DISTANCE) {

            return;
        }

        golem.getLookControl().setLookAt(
                target,
                30.0F,
                30.0F
        );


        attackCount++;


        boolean powerfulAttack =
                attackCount >= 3;
        if (powerfulAttack) {
            attackCount = 0;
        }


        boolean hit =
                golem.doHurtTarget(target);

        if (!hit) {
            return;
        }



        if (powerfulAttack) {


            if (golem.distanceToSqr(target)
                    <= KNOCKBACK_DISTANCE
                    * KNOCKBACK_DISTANCE) {


                knockbackAttempts = 0;

                knockbackPending = false;

                forcedKnockbackJump = false;



                tryKnockback(target);



                if (knockbackAttempts
                        < MAX_KNOCKBACK_ATTEMPTS) {

                    knockbackPending = true;

                    knockbackRetryTicks =
                            KNOCKBACK_RETRY_DELAY;

                    attackCooldown = 0;
                }
            }
        }
    }



    private void tryKnockback(
            LivingEntity target) {


        if (golem.distanceToSqr(target)
                > KNOCKBACK_DISTANCE
                * KNOCKBACK_DISTANCE) {

            return;
        }

        if (knockbackAttempts
                >= MAX_KNOCKBACK_ATTEMPTS) {

            return;
        }

        knockbackAttempts++;


        double dx =
                target.getX()
                        - golem.getX();

        double dz =
                target.getZ()
                        - golem.getZ();

        double distance =
                Math.sqrt(
                        dx * dx
                                + dz * dz
                );

        if (distance < 0.01D) {
            return;
        }

        dx /= distance;

        dz /= distance;



        target.push(
                dx * 1.2D,
                0.35D,
                dz * 1.2D
        );

        target.hasImpulse = true;
    }
}
