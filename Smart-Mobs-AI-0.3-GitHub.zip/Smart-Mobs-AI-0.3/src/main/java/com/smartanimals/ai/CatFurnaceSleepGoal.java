package com.smartanimals.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Cat;
import net.minecraft.world.level.block.Blocks;

import java.util.EnumSet;

public class CatFurnaceSleepGoal extends Goal {

    private final Cat cat;
    private final double speed;

    private BlockPos furnacePos;

    private int sleepTime;

    private boolean checkedThisNight = false;

    private static final int SEARCH_RADIUS = 6;

    private static final int MIN_SLEEP_TIME = 1200;
    private static final int MAX_SLEEP_TIME = 3600;

    public CatFurnaceSleepGoal(
            Cat cat,
            double speed) {

        this.cat = cat;
        this.speed = speed;

        this.setFlags(
                EnumSet.of(
                        Flag.MOVE,
                        Flag.LOOK
                )
        );
    }

    @Override
    public boolean canUse() {


        if (cat.level().isDay()) {

            checkedThisNight = false;

            return false;
        }


        if (checkedThisNight) {
            return false;
        }


        checkedThisNight = true;


        if (cat.getRandom().nextInt(100) >= 10) {
            return false;
        }


        if (cat.isLying()) {
            return false;
        }


        furnacePos = findNearestFurnace();

        return furnacePos != null;
    }

    @Override
    public boolean canContinueToUse() {

        if (!cat.isAlive()) {
            return false;
        }


        if (cat.level().isDay()) {
            return false;
        }

        return furnacePos != null;
    }

    @Override
    public void start() {


        sleepTime =
                MIN_SLEEP_TIME
                        + cat.getRandom().nextInt(
                        MAX_SLEEP_TIME
                                - MIN_SLEEP_TIME
                );

        moveToFurnace();
    }

    @Override
    public void tick() {

        if (furnacePos == null) {
            return;
        }

        double distance =
                cat.distanceToSqr(
                        furnacePos.getX() + 0.5D,
                        furnacePos.getY() + 1.0D,
                        furnacePos.getZ() + 0.5D
                );


        if (distance <= 2.5D) {

            cat.getNavigation().stop();


            cat.setLying(true);

            sleepTime--;


            if (sleepTime <= 0) {
                stop();
            }

            return;
        }


        if (cat.getNavigation().isDone()) {
            moveToFurnace();
        }
    }

    @Override
    public void stop() {


        cat.setLying(false);

        cat.getNavigation().stop();

        furnacePos = null;
    }

    private void moveToFurnace() {

        if (furnacePos == null) {
            return;
        }

        cat.getNavigation().moveTo(
                furnacePos.getX() + 0.5D,
                furnacePos.getY() + 1.0D,
                furnacePos.getZ() + 0.5D,
                speed
        );
    }

    private BlockPos findNearestFurnace() {

        BlockPos catPos =
                cat.blockPosition();

        BlockPos closest = null;
        double closestDistance =
                Double.MAX_VALUE;

        for (int x = -SEARCH_RADIUS;
             x <= SEARCH_RADIUS;
             x++) {

            for (int y = -2;
                 y <= 2;
                 y++) {

                for (int z = -SEARCH_RADIUS;
                     z <= SEARCH_RADIUS;
                     z++) {

                    BlockPos pos =
                            catPos.offset(
                                    x,
                                    y,
                                    z
                            );

                    if (!isFurnace(pos)) {
                        continue;
                    }

                    double distance =
                            cat.distanceToSqr(
                                    pos.getX() + 0.5D,
                                    pos.getY() + 1.0D,
                                    pos.getZ() + 0.5D
                            );

                    if (distance <
                            closestDistance) {

                        closestDistance =
                                distance;

                        closest = pos;
                    }
                }
            }
        }

        return closest;
    }

    private boolean isFurnace(
            BlockPos pos) {

        return cat.level()
                .getBlockState(pos)
                .is(Blocks.FURNACE)

                || cat.level()
                .getBlockState(pos)
                .is(Blocks.BLAST_FURNACE)

                || cat.level()
                .getBlockState(pos)
                .is(Blocks.SMOKER);
    }
}