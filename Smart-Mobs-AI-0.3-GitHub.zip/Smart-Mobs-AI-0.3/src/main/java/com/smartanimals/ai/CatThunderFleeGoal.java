package com.smartanimals.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Cat;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.state.BlockState;

import java.util.EnumSet;

public class CatThunderFleeGoal extends Goal {

    private final Cat cat;
    private final double speed;
    private BlockPos targetBed;

    private static final int CHECK_COOLDOWN = 10;
    private int checkTimer;

    public CatThunderFleeGoal(Cat cat, double speed) {
        this.cat = cat;
        this.speed = speed;

        this.setFlags(EnumSet.of(Flag.MOVE));
    }

    @Override
    public boolean canUse() {

        if (this.cat.isOrderedToSit()) {
            return false;
        }

        if (!this.cat.level().isThundering()) {
            return false;
        }

        if (!this.cat.isTame()) {
            return false;
        }


        if (this.checkTimer > 0) {
            this.checkTimer--;
            return false;
        }

        this.checkTimer = CHECK_COOLDOWN;

        this.targetBed = findNearbyBed();

        return this.targetBed != null;
    }

    @Override
    public boolean canContinueToUse() {

        if (this.cat.isOrderedToSit()) {
            stop();
            return false;
        }

        if (!this.cat.level().isThundering()) {
            stop();
            return false;
        }

        if (!this.cat.isTame()) {
            stop();
            return false;
        }

        if (this.targetBed == null) {
            return false;
        }

        return this.cat.distanceToSqr(
                this.targetBed.getX() + 0.5,
                this.targetBed.getY(),
                this.targetBed.getZ() + 0.5
        ) > 6.25;
    }

    @Override
    public void start() {
        moveToBed();
    }

    @Override
    public void tick() {

        if (this.cat.isOrderedToSit()) {
            stop();
            return;
        }

        if (!this.cat.level().isThundering()) {
            stop();
            return;
        }

        moveToBed();
    }

    @Override
    public void stop() {

        this.targetBed = null;
        this.checkTimer = 0;

        this.cat.getNavigation().stop();
    }

    private void moveToBed() {

        if (this.targetBed == null) {
            return;
        }

        double x = this.targetBed.getX() + 1.5;
        double y = this.targetBed.getY();
        double z = this.targetBed.getZ() + 0.5;

        this.cat.getNavigation().moveTo(
                x,
                y,
                z,
                this.speed
        );
    }

    private BlockPos findNearbyBed() {

        BlockPos catPos = this.cat.blockPosition();

        for (BlockPos pos : BlockPos.betweenClosed(
                catPos.offset(-12, -4, -12),
                catPos.offset(12, 4, 12)
        )) {

            BlockState state = this.cat.level().getBlockState(pos);

            if (state.getBlock() instanceof BedBlock) {
                return pos.immutable();
            }
        }

        return null;
    }
}