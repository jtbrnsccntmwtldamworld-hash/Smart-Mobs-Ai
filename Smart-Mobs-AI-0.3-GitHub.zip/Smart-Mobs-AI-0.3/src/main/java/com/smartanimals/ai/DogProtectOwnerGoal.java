package com.smartanimals.ai;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;

import java.util.EnumSet;
import java.util.List;

public class DogProtectOwnerGoal extends Goal {

    private final Wolf dog;
    private final double speed;

    private LivingEntity target;


    private static final double PROTECTION_RADIUS = 3.0D;

    private static final int CHECK_COOLDOWN = 10;
    private int checkTimer;

    public DogProtectOwnerGoal(
            Wolf dog,
            double speed) {

        this.dog = dog;
        this.speed = speed;

        this.setFlags(
                EnumSet.of(
                        Flag.MOVE,
                        Flag.LOOK
                )
        );
    }

    @Override
    public boolean canUse() {


        if (this.checkTimer > 0) {
            this.checkTimer--;
            return false;
        }


        this.checkTimer = CHECK_COOLDOWN;


        if (!this.dog.isTame()) {
            return false;
        }


        LivingEntity owner =
                this.dog.getOwner();

        if (owner == null) {
            return false;
        }


        this.target =
                findThreatNearOwner(owner);

        return this.target != null;
    }

    @Override
    public boolean canContinueToUse() {

        if (!this.dog.isAlive()) {
            return false;
        }

        if (!this.dog.isTame()) {
            return false;
        }

        LivingEntity owner =
                this.dog.getOwner();

        if (owner == null) {
            return false;
        }

        if (this.target == null) {
            return false;
        }

        if (!this.target.isAlive()) {
            return false;
        }


        double distance =
                this.target.distanceToSqr(owner);

        return distance <=
                PROTECTION_RADIUS
                        * PROTECTION_RADIUS;
    }

    @Override
    public void start() {

        if (this.target == null) {
            return;
        }


        this.dog.getLookControl()
                .setLookAt(
                        this.target,
                        30.0F,
                        30.0F
                );


        this.dog.getNavigation()
                .moveTo(
                        this.target,
                        this.speed
                );
    }

    @Override
    public void tick() {

        if (this.target == null) {
            return;
        }

        LivingEntity owner =
                this.dog.getOwner();

        if (owner == null) {
            return;
        }


        double distance =
                this.target.distanceToSqr(owner);

        if (distance >
                PROTECTION_RADIUS
                        * PROTECTION_RADIUS) {

            this.target = null;

            this.dog.getNavigation()
                    .stop();

            return;
        }


        this.dog.getLookControl()
                .setLookAt(
                        this.target,
                        30.0F,
                        30.0F
                );


        if (this.dog.distanceToSqr(
                this.target
        ) > 4.0D) {

            if (this.dog.getNavigation()
                    .isDone()) {
                this.dog.getNavigation()
                        .moveTo(
                                this.target,
                                this.speed
                        );
            }

            return;
        }


        this.dog.getNavigation()
                .stop();

        this.dog.doHurtTarget(
                this.target
        );
    }

    @Override
    public void stop() {

        this.target = null;
        this.checkTimer = 0;

        this.dog.getNavigation()
                .stop();
    }

    private LivingEntity findThreatNearOwner(
            LivingEntity owner) {


        List<LivingEntity> entities =
                this.dog.level()
                        .getEntitiesOfClass(
                                LivingEntity.class,
                                owner.getBoundingBox()
                                        .inflate(
                                                PROTECTION_RADIUS
                                        )
                        );

        LivingEntity closest =
                null;

        double closestDistance =
                Double.MAX_VALUE;

        for (LivingEntity entity :
                entities) {


            if (entity == owner) {
                continue;
            }


            if (entity == this.dog) {
                continue;
            }


            if (entity instanceof Player) {
                continue;
            }


            if (!(entity instanceof Enemy)) {
                continue;
            }


            if (!entity.isAlive()) {
                continue;
            }


            double distance =
                    entity.distanceToSqr(owner);

            if (distance <
                    closestDistance) {

                closestDistance =
                        distance;

                closest =
                        entity;
            }
        }

        return closest;
    }
}