package com.smartanimals.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Cat;
import net.minecraft.world.level.block.Blocks;

import java.util.EnumSet;

public class CatWaterAvoidGoal extends Goal {

    private final Cat cat;
    private final double speed;

    private BlockPos waterPos;
    private BlockPos targetPos;

    private static final int WATER_RADIUS = 4;
    private static final int SEARCH_RADIUS = 8;

    public CatWaterAvoidGoal(
            Cat cat,
            double speed) {

        this.cat = cat;
        this.speed = speed;

        this.setFlags(
                EnumSet.of(Flag.MOVE)
        );
    }

    @Override
    public boolean canUse() {


        if (this.cat.isInWater()) {

            this.waterPos = findNearestWater();

            if (this.waterPos == null) {
                return false;
            }

            this.targetPos = findEscapePoint();

            return this.targetPos != null;
        }


        this.waterPos = findNearestWater();

        if (this.waterPos == null) {
            return false;
        }


        if (this.cat.distanceToSqr(
                this.waterPos.getX() + 0.5D,
                this.waterPos.getY(),
                this.waterPos.getZ() + 0.5D
        ) > 16.0D) {

            return false;
        }


        this.targetPos = findEscapePoint();

        return this.targetPos != null;
    }

    @Override
    public boolean canContinueToUse() {

        if (!this.cat.isAlive()) {
            return false;
        }

        if (this.targetPos == null) {
            return false;
        }


        this.waterPos = findNearestWater();

        if (this.waterPos == null) {
            return false;
        }

        double distance =
                this.cat.distanceToSqr(
                        this.waterPos.getX() + 0.5D,
                        this.waterPos.getY(),
                        this.waterPos.getZ() + 0.5D
                );


        if (distance > 25.0D) {
            return false;
        }


        if (this.cat.getNavigation().isDone()) {

            this.targetPos = findEscapePoint();

            if (this.targetPos == null) {
                return false;
            }
        }

        return true;
    }

    @Override
    public void start() {

        moveToTarget();
    }

    @Override
    public void tick() {


        this.waterPos = findNearestWater();

        if (this.waterPos == null) {
            return;
        }


        if (this.cat.getNavigation().isDone()) {

            this.targetPos = findEscapePoint();

            if (this.targetPos != null) {
                moveToTarget();
            }
        }
    }

    @Override
    public void stop() {


        this.waterPos = null;
        this.targetPos = null;
    }

    private BlockPos findNearestWater() {

        BlockPos catPos =
                this.cat.blockPosition();

        BlockPos closestWater = null;

        double closestDistance =
                Double.MAX_VALUE;
        for (int x = -WATER_RADIUS;
             x <= WATER_RADIUS;
             x++) {

            for (int y = -1;
                 y <= 1;
                 y++) {

                for (int z = -WATER_RADIUS;
                     z <= WATER_RADIUS;
                     z++) {

                    BlockPos pos =
                            catPos.offset(
                                    x,
                                    y,
                                    z
                            );

                    if (!isWater(pos)) {
                        continue;
                    }

                    double distance =
                            this.cat.distanceToSqr(
                                    pos.getX() + 0.5D,
                                    pos.getY(),
                                    pos.getZ() + 0.5D
                            );

                    if (distance < closestDistance) {

                        closestDistance =
                                distance;

                        closestWater =
                                pos;
                    }
                }
            }
        }

        return closestWater;
    }

    private BlockPos findEscapePoint() {

        if (this.waterPos == null) {
            return null;
        }


        double dx =
                this.cat.getX()
                        - (this.waterPos.getX() + 0.5D);

        double dz =
                this.cat.getZ()
                        - (this.waterPos.getZ() + 0.5D);

        double distance =
                Math.sqrt(
                        dx * dx
                                + dz * dz
                );


        if (distance < 0.001D) {

            dx = 1.0D;
            dz = 0.0D;

        } else {

            dx /= distance;
            dz /= distance;
        }


        for (int distanceStep = 4;
             distanceStep <= SEARCH_RADIUS;
             distanceStep++) {

            double targetX =
                    this.cat.getX()
                            + dx * distanceStep;

            double targetZ =
                    this.cat.getZ()
                            + dz * distanceStep;

            BlockPos candidate =
                    BlockPos.containing(
                            targetX,
                            this.cat.getY(),
                            targetZ
                    );


            for (int y = -2;
                 y <= 2;
                 y++) {

                BlockPos check =
                        candidate.offset(
                                0,
                                y,
                                0
                        );

                if (isSafeDryPosition(check)) {

                    return check;
                }
            }
        }


        return findAnyDryPosition();
    }

    private BlockPos findAnyDryPosition() {

        BlockPos catPos =
                this.cat.blockPosition();

        BlockPos bestPosition = null;

        double bestDistance =
                Double.MAX_VALUE;

        for (int x = -SEARCH_RADIUS;
             x <= SEARCH_RADIUS;
             x++) {

            for (int y = -2;
                 y <= 2;
                 y++) {

                for (int z = -SEARCH_RADIUS;
                     z <= SEARCH_RADIUS;
                     z++) {

                    BlockPos pos =
                            catPos.offset(
                                    x,
                                    y,
                                    z
                            );

                    if (!isSafeDryPosition(pos)) {
                        continue;
                    }

                    double distance =
                            this.cat.distanceToSqr(
                                    pos.getX() + 0.5D,
                                    pos.getY() + 1.0D,
                                    pos.getZ() + 0.5D
                            );

                    if (distance < bestDistance) {

                        bestDistance =
                                distance;

                        bestPosition =
                                pos;
                    }
                }
            }
        }

        return bestPosition;
    }

    private boolean isSafeDryPosition(
            BlockPos pos) {


        if (isWater(pos)) {
            return false;
        }


        if (!this.cat.level()
                .getBlockState(pos.above())
                .isAir()) {

            return false;
        }


        if (this.cat.level()
                .getBlockState(pos)
                .isAir()) {

            return false;
        }


        if (isWater(pos.below())) {
            return false;
        }

        return true;
    }

    private boolean isWater(
            BlockPos pos) {

        return this.cat.level()
                .getBlockState(pos)
                .is(Blocks.WATER);
    }

    private void moveToTarget() {

        if (this.targetPos == null) {
            return;
        }

        this.cat.getNavigation().moveTo(
                this.targetPos.getX() + 0.5D,
                this.targetPos.getY() + 1.0D,
                this.targetPos.getZ() + 0.5D,
                this.speed
        );
    }
}