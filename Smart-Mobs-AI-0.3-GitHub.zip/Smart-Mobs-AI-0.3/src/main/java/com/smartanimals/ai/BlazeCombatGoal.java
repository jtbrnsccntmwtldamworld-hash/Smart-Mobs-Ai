package com.smartanimals.ai;

import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.monster.Blaze;
import net.minecraft.world.entity.player.Player;

import java.util.EnumSet;

public class BlazeCombatGoal extends Goal {

    private final Blaze blaze;

    private static final double MIN_DISTANCE = 8.0D;
    private static final double ESCAPE_DISTANCE = 8.0D;

    private int cooldown;

    public BlazeCombatGoal(Blaze blaze) {

        this.blaze = blaze;

        this.setFlags(
                EnumSet.of(Flag.MOVE)
        );
    }

    @Override
    public boolean canUse() {

        if (!(this.blaze.getTarget() instanceof Player player)) {
            return false;
        }

        if (!player.isAlive()) {
            return false;
        }

        return this.blaze.distanceTo(player)
                < MIN_DISTANCE;
    }

    @Override
    public boolean canContinueToUse() {

        if (!(this.blaze.getTarget() instanceof Player player)) {
            return false;
        }

        if (!player.isAlive()) {
            return false;
        }


        return this.blaze.distanceTo(player)
                < MIN_DISTANCE;
    }

    @Override
    public void start() {

        this.cooldown = 0;
    }

    @Override
    public void stop() {


        this.blaze.getMoveControl()
                .setWantedPosition(
                        this.blaze.getX(),
                        this.blaze.getY(),
                        this.blaze.getZ(),
                        0.0D
                );
    }

    @Override
    public void tick() {

        if (!(this.blaze.getTarget() instanceof Player player)) {
            return;
        }

        if (!player.isAlive()) {
            return;
        }

        if (this.cooldown > 0) {
            this.cooldown--;
            return;
        }


        this.cooldown = 5;


        double x =
                this.blaze.getX()
                        - player.getX();

        double z =
                this.blaze.getZ()
                        - player.getZ();

        double horizontalDistance =
                Math.sqrt(
                        x * x
                                + z * z
                );

        if (horizontalDistance < 0.001D) {
            return;
        }


        x /= horizontalDistance;
        z /= horizontalDistance;


        double targetX =
                this.blaze.getX()
                        + x * ESCAPE_DISTANCE;

        double targetZ =
                this.blaze.getZ()
                        + z * ESCAPE_DISTANCE;


        double targetY =
                this.blaze.getY();


        this.blaze.getMoveControl()
                .setWantedPosition(
                        targetX,
                        targetY,
                        targetZ,
                        1.2D
                );
    }
}