package com.smartanimals.ai;

import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Chicken;
import net.minecraft.world.entity.animal.Fox;

import java.util.EnumSet;
import java.util.List;
import java.util.Random;

public class ChickenFoxPanicGoal extends Goal {

    private final Chicken chicken;
    private final double speed;

    private Fox fox;

    private double targetX;
    private double targetY;
    private double targetZ;

    private static final Random RANDOM = new Random();

    private static final double DETECTION_RADIUS = 8.0D;

    public ChickenFoxPanicGoal(
            Chicken chicken,
            double speed) {

        this.chicken = chicken;
        this.speed = speed;

        this.setFlags(
                EnumSet.of(Flag.MOVE)
        );
    }

    @Override
    public boolean canUse() {

        List<Fox> nearbyFoxes =
                this.chicken.level().getEntitiesOfClass(
                        Fox.class,
                        this.chicken
                                .getBoundingBox()
                                .inflate(DETECTION_RADIUS)
                );

        if (nearbyFoxes.isEmpty()) {
            return false;
        }

        Fox nearestFox = null;

        double nearestDistance =
                Double.MAX_VALUE;

        for (Fox nearbyFox : nearbyFoxes) {

            if (!nearbyFox.isAlive()) {
                continue;
            }


            if (!this.chicken.hasLineOfSight(nearbyFox)) {
                continue;
            }

            double distance =
                    this.chicken.distanceToSqr(
                            nearbyFox
                    );

            if (distance < nearestDistance) {

                nearestDistance = distance;
                nearestFox = nearbyFox;
            }
        }

        if (nearestFox == null) {
            return false;
        }

        this.fox = nearestFox;

        chooseEscapePoint();

        return true;
    }

    @Override
    public boolean canContinueToUse() {

        if (this.fox == null) {
            return false;
        }

        if (!this.fox.isAlive()) {
            return false;
        }

        return this.chicken.distanceToSqr(
                this.fox
        ) <= DETECTION_RADIUS * DETECTION_RADIUS;
    }

    @Override
    public void start() {
        runAway();
    }

    @Override
    public void tick() {

        if (this.fox == null) {
            return;
        }

        if (this.chicken.getNavigation().isDone()
                || RANDOM.nextInt(20) == 0) {

            chooseEscapePoint();
            runAway();
        }
    }

    @Override
    public void stop() {

        this.fox = null;

        this.chicken
                .getNavigation()
                .stop();
    }

    private void chooseEscapePoint() {

        if (this.fox == null) {
            return;
        }

        double dx =
                this.chicken.getX()
                        - this.fox.getX();

        double dz =
                this.chicken.getZ()
                        - this.fox.getZ();

        double distance =
                Math.sqrt(
                        dx * dx
                                + dz * dz
                );

        if (distance < 0.001D) {

            double angle =
                    RANDOM.nextDouble()
                            * Math.PI
                            * 2.0D;

            dx = Math.cos(angle);
            dz = Math.sin(angle);

        } else {

            dx /= distance;
            dz /= distance;
        }

        double escapeDistance =
                8.0D
                        + RANDOM.nextDouble()
                        * 4.0D;

        this.targetX =
                this.chicken.getX()
                        + dx * escapeDistance;


        this.targetY =
                this.chicken.getY() + 1.0D;

        this.targetZ =
                this.chicken.getZ()
                        + dz * escapeDistance;
    }

    private void runAway() {
        this.chicken
                .getNavigation()
                .moveTo(
                        this.targetX,
                        this.targetY,
                        this.targetZ,
                        this.speed
                );
    }
}