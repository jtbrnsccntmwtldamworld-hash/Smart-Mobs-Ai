package com.smartanimals.ai;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.horse.Horse;
import net.minecraft.world.entity.monster.Monster;

import java.util.EnumSet;
import java.util.List;

public class HorseHerdPanicGoal extends Goal {

    private final Horse horse;
    private final double speed;

    private LivingEntity threat;

    private static final int SEARCH_RADIUS = 10;
    private static final double ESCAPE_DISTANCE = 8.0D;
    private static final int CHECK_COOLDOWN = 5;

    private int checkTimer;

    public HorseHerdPanicGoal(
            Horse horse,
            double speed) {

        this.horse = horse;
        this.speed = speed;

        this.setFlags(
                EnumSet.of(Flag.MOVE)
        );
    }

    @Override
    public boolean canUse() {


        if (this.checkTimer > 0) {
            this.checkTimer--;
            return false;
        }


        this.threat = findThreat();


        this.checkTimer = CHECK_COOLDOWN;

        return this.threat != null;
    }

    @Override
    public boolean canContinueToUse() {


        if (this.threat == null) {
            return false;
        }

        if (!this.threat.isAlive()) {
            return false;
        }


        return this.horse.distanceToSqr(
                this.threat
        ) <= SEARCH_RADIUS * SEARCH_RADIUS;
    }

    @Override
    public void start() {

        runAwayFromThreat();
    }

    @Override
    public void tick() {


        if (this.threat == null
                || !this.threat.isAlive()) {

            this.threat =
                    findThreat();

            if (this.threat == null) {
                return;
            }
        }


        if (this.horse.getNavigation().isDone()) {

            runAwayFromThreat();
        }
    }

    @Override
    public void stop() {

        this.threat = null;

        this.horse
                .getNavigation()
                .stop();
    }

    private void runAwayFromThreat() {

        if (this.threat == null) {
            return;
        }

        double dx =
                this.horse.getX()
                        - this.threat.getX();

        double dz =
                this.horse.getZ()
                        - this.threat.getZ();

        double length =
                Math.sqrt(
                        dx * dx
                                + dz * dz
                );


        if (length < 0.001D) {

            dx = 1.0D;
            dz = 0.0D;

            length = 1.0D;
        }


        dx /= length;
        dz /= length;


        double targetX =
                this.horse.getX()
                        + dx * ESCAPE_DISTANCE;

        double targetZ =
                this.horse.getZ()
                        + dz * ESCAPE_DISTANCE;

        this.horse
                .getNavigation()
                .moveTo(
                        targetX,
                        this.horse.getY(),
                        targetZ,
                        this.speed
                );
    }

    private LivingEntity findThreat() {


        List<Monster> monsters =
                this.horse.level()
 .getEntitiesOfClass(
                                Monster.class,
                                this.horse
                                        .getBoundingBox()
                                        .inflate(
                                                SEARCH_RADIUS
                                        ),
                                monster ->
                                        monster.isAlive()
                        );

        if (monsters.isEmpty()) {
            return null;
        }


        Monster nearest = null;
        double nearestDist = Double.MAX_VALUE;

        for (Monster monster : monsters) {

            double dist =
                    this.horse
                            .distanceToSqr(
                                    monster
                            );

            if (dist < nearestDist) {
                nearestDist = dist;
                nearest = monster;
            }
        }

        return nearest;
    }
}