package com.smartanimals.ai;

import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Sheep;

import java.util.EnumSet;
import java.util.List;
import java.util.Random;

public class SheepGrazingGroupGoal extends Goal {

    private final Sheep sheep;
    private final double speed;

    private Sheep groupLeader;

    private double targetX;
    private double targetY;
    private double targetZ;

    private int grazingTime;

    private static final Random RANDOM = new Random();


    private static final int GRAZING_COOLDOWN = 6000;


    private static final double SEARCH_RADIUS = 10.0D;


    private static final double MIN_GROUP_DISTANCE = 6.0D;


    private static final double MAX_GROUP_DISTANCE = 10.0D;


    private int cooldown;

    public SheepGrazingGroupGoal(
            Sheep sheep,
            double speed) {

        this.sheep = sheep;
        this.speed = speed;

        this.setFlags(
                EnumSet.of(Flag.MOVE)
        );


        this.cooldown =
                RANDOM.nextInt(
                        GRAZING_COOLDOWN
                );
    }

    @Override
    public boolean canUse() {


        if (!isDay()) {
            return false;
        }


        if (this.sheep.level().isRaining()) {
            return false;
        }


        if (this.cooldown > 0) {

            this.cooldown--;

            return false;
        }


        this.groupLeader = findGroupLeader();

        if (this.groupLeader == null) {
            return false;
        }


        chooseGrazingPoint();

        return true;
    }

    @Override
    public boolean canContinueToUse() {


        if (!isDay()) {
            return false;
        }


        if (this.sheep.level().isRaining()) {
            return false;
        }


        if (this.groupLeader == null) {
            return false;
        }

        if (!this.groupLeader.isAlive()) {
            return false;
        }


        return this.grazingTime > 0;
    }

    @Override
    public void start() {


        this.grazingTime =
                100
                        + RANDOM.nextInt(200);

        moveToGrazingPoint();
    }

    @Override
    public void tick() {

        if (this.groupLeader == null) {
            return;
        }


        double distance =
                this.sheep.distanceToSqr(
                        this.targetX,
                        this.targetY,
                        this.targetZ
                );

        if (distance > 3.0D) {

            if (this.sheep
                    .getNavigation()
                    .isDone()) {
                chooseGrazingPoint();
                moveToGrazingPoint();
            }

            return;
        }


        this.sheep
                .getNavigation()
                .stop();

        this.grazingTime--;


        if (this.grazingTime > 0
                && RANDOM.nextInt(40) == 0) {

            chooseGrazingPoint();
            moveToGrazingPoint();
        }
    }

    @Override
    public void stop() {

        this.groupLeader = null;

        this.grazingTime = 0;

        this.sheep
                .getNavigation()
                .stop();


        this.cooldown =
                GRAZING_COOLDOWN
                        + RANDOM.nextInt(200);
    }

    private boolean isDay() {

        long time =
                this.sheep.level()
                        .getDayTime()
                        % 24000L;

        return time >= 0L
                && time < 12000L;
    }

    private Sheep findGroupLeader() {

        List<Sheep> nearbySheep =
                this.sheep.level()
                        .getEntitiesOfClass(
                                Sheep.class,
                                this.sheep
                                        .getBoundingBox()
                                        .inflate(
                                                SEARCH_RADIUS
                                        )
                        );

        Sheep closestSheep = null;

        double closestDistance =
                Double.MAX_VALUE;

        for (Sheep otherSheep :
                nearbySheep) {

            if (otherSheep == this.sheep) {
                continue;
            }

            if (!otherSheep.isAlive()) {
                continue;
            }

            double distance =
                    this.sheep.distanceToSqr(
                            otherSheep
                    );

            if (distance < closestDistance) {

                closestDistance = distance;
                closestSheep = otherSheep;
            }
        }

        return closestSheep;
    }

    private void chooseGrazingPoint() {

        if (this.groupLeader == null) {
            return;
        }


        double angle =
                RANDOM.nextDouble()
                        * Math.PI
                        * 2.0D;


        double distance =
                MIN_GROUP_DISTANCE
                        + RANDOM.nextDouble()
                        * (
                                MAX_GROUP_DISTANCE
                                        - MIN_GROUP_DISTANCE
                        );

        this.targetX =
                this.groupLeader.getX()
                        + Math.cos(angle)
                        * distance;

        this.targetY =
                this.groupLeader.getY();

        this.targetZ =
                this.groupLeader.getZ()
                        + Math.sin(angle)
                        * distance;
    }

    private void moveToGrazingPoint() {

        this.sheep
                .getNavigation()
                .moveTo(
                        this.targetX,
                        this.targetY,
                        this.targetZ,
                        this.speed
                );
    }
}