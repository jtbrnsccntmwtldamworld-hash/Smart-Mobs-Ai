package com.smartanimals.ai;

import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.inventory.MenuType;

public class PiglinBarterMenuType {

    public static final MenuType<PiglinBarterMenu> PIGLIN_BARTER_MENU =
            new MenuType<>(
                    PiglinBarterMenu::new,
                    FeatureFlags.DEFAULT_FLAGS
            );

    private PiglinBarterMenuType() {
    }
}