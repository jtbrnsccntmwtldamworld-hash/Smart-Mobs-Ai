package com.smartanimals.ai;

import com.smartanimals.util.MessageHelper;

import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Cat;
import net.minecraft.world.entity.player.Player;

import java.util.EnumSet;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.WeakHashMap;

public class CatWeaponFleeGoal extends Goal {

    private final Cat cat;
    private final double speed;

    private Player threateningPlayer;

    private double targetX;
    private double targetY;
    private double targetZ;

    private int checkCooldown = 0;

    private static final Random RANDOM = new Random();

    private static final double DETECTION_RADIUS = 5.0D;

    private static final long ALARM_COOLDOWN = 40L;

    private long lastAlarmTime = -100L;


    private static final Map<Cat, Integer> SCARED_CATS =
            new WeakHashMap<>();

    public CatWeaponFleeGoal(
            Cat cat,
            double speed
    ) {

        this.cat = cat;
        this.speed = speed;

        this.setFlags(
                EnumSet.of(Flag.MOVE)
        );
    }

    @Override
    public boolean canUse() {


        if (this.cat.isOrderedToSit()) {
            return false;
        }

        Player nearbyPlayer =
                findThreateningPlayer();

        if (nearbyPlayer == null) {
            return false;
        }

        this.threateningPlayer =
                nearbyPlayer;

        this.checkCooldown = 20;

        alarm();

        chooseEscapeFrom(
                nearbyPlayer.getX(),
                nearbyPlayer.getZ()
        );

        return true;
    }

    @Override
    public boolean canContinueToUse() {


        if (this.cat.isOrderedToSit()) {
            return false;
        }

        if (this.threateningPlayer == null) {
            return false;
        }

        if (!this.threateningPlayer.isAlive()) {
            return false;
        }

        if (this.threateningPlayer.isCreative()) {
            return false;
        }

        if (this.checkCooldown > 0) {
            this.checkCooldown--;
        }

        if (this.checkCooldown <= 0) {

            this.checkCooldown = 20;


            if (!WeaponPanicUtil.isHoldingWeapon(
                    this.threateningPlayer
            )) {
                return false;
            }


            if (this.cat.distanceToSqr(
                    this.threateningPlayer
            ) > DETECTION_RADIUS
                    * DETECTION_RADIUS) {

                return false;
            }


            if (isOwner(
                    this.threateningPlayer
            )) {
                return false;
            }
        }

        return true;
    }

    @Override
    public void start() {

        runAway();
    }

    @Override
    public void tick() {


        if (this.cat.getNavigation().isDone()
                && RANDOM.nextInt(20) == 0) {

            if (this.threateningPlayer != null) {

                chooseEscapeFrom(
                        this.threateningPlayer.getX(),
                        this.threateningPlayer.getZ()
                );
            }

            runAway();
        }
    }

    @Override
    public void stop() {

        this.threateningPlayer = null;

        this.checkCooldown = 0;

        this.cat.getNavigation().stop();
    }


    private Player findThreateningPlayer() {

        for (Player player :
                this.cat.level().players()) {


            if (!player.isAlive()) {
                continue;
            }


            if (player.isCreative()) {
                continue;
            }


            if (isOwner(player)) {
                continue;
            }


            if (this.cat.distanceToSqr(player)
                    > DETECTION_RADIUS
                    * DETECTION_RADIUS) {

                continue;
            }


            if (!WeaponPanicUtil.isHoldingWeapon(player)) {
                continue;
            }

            return player;
        }

        return null;
    }


    private void chooseEscapeFrom(
            double threatX,
            double threatZ
    ) {

        double dx =
                this.cat.getX() - threatX;

        double dz =
                this.cat.getZ() - threatZ;

        double distance =
                Math.sqrt(
                        dx * dx
                                + dz * dz
                );


        if (distance < 0.001D) {

            double angle =
                    RANDOM.nextDouble()
                            * Math.PI
                            * 2.0D;

            dx = Math.cos(angle);
            dz = Math.sin(angle);

        } else {


            dx /= distance;
            dz /= distance;
        }


        double escapeDistance =
                8.0D
                        + RANDOM.nextDouble()
                        * 4.0D;

        this.targetX =
                this.cat.getX()
                        + dx * escapeDistance;

        this.targetY =
                this.cat.getY() + 1.0D;

        this.targetZ =
                this.cat.getZ()
                        + dz * escapeDistance;
    }

    private void runAway() {

        this.cat.getNavigation().moveTo(
                this.targetX,
                this.targetY,
                this.targetZ,
                this.speed
        );
    }

    private boolean isOwner(
            Player player
    ) {

        if (!this.cat.isTame()) {
            return false;
        }

        UUID ownerUUID =
                this.cat.getOwnerUUID();

        if (ownerUUID == null) {
            return false;
        }

        return ownerUUID.equals(
                player.getUUID()
        );
    }


    private void alarm() {

        long currentTime =
                this.cat.level().getGameTime();


        if (currentTime - lastAlarmTime
                < ALARM_COOLDOWN) {

            return;
        }

        int scaredCount =
                SCARED_CATS.getOrDefault(
                        this.cat,
                        0
                );

        Component message;

        if (scaredCount == 0) {

            message =
                    Component.translatable(
                            "message.smartmobs.cat_scared"
                    );

        } else if (scaredCount == 1) {

            message =
                    Component.translatable(
                            "message.smartmobs.cat_still_afraid"
                    );

        } else {

            message =
                    Component.translatable(
                            "message.smartmobs.cat_really_scared"
                    );
        }

        MessageHelper.sendActionBarIfEnabled(
                this.threateningPlayer,
                message
        );


        SCARED_CATS.put(
                this.cat,
                scaredCount + 1
        );

        lastAlarmTime = currentTime;
    }
}
