package com.smartanimals.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Chicken;
import net.minecraft.world.level.block.FenceBlock;

import java.util.EnumSet;
import java.util.Random;

public class ChickenFencePerchGoal extends Goal {

    private final Chicken chicken;
    private final double speed;

    private BlockPos fenceTarget;

    private int perchTime;

    private static final Random RANDOM = new Random();

    private static final int SEARCH_RADIUS = 8;

    private static final int MIN_PERCH_TIME = 100;
    private static final int MAX_PERCH_TIME = 240;

    public ChickenFencePerchGoal(
            Chicken chicken,
            double speed) {

        this.chicken = chicken;
        this.speed = speed;

        this.setFlags(
                EnumSet.of(Flag.MOVE)
        );
    }

    @Override
    public boolean canUse() {


        if (RANDOM.nextInt(100) >= 4) {
            return false;
        }


        if (!this.chicken.getNavigation().isDone()) {
            return false;
        }

        this.fenceTarget = findFence();

        return this.fenceTarget != null;
    }

    @Override
    public boolean canContinueToUse() {

        if (this.fenceTarget == null) {
            return false;
        }

        if (!this.chicken.isAlive()) {
            return false;
        }

        return this.perchTime > 0;
    }

    @Override
    public void start() {

        this.perchTime =
                MIN_PERCH_TIME
                        + RANDOM.nextInt(
                        MAX_PERCH_TIME
                                - MIN_PERCH_TIME
                );

        moveToFence();
    }

    @Override
    public void tick() {

        if (this.fenceTarget == null) {
            return;
        }

        BlockPos perchPos =
                this.fenceTarget.above();

        double distance =
                this.chicken.distanceToSqr(
                        perchPos.getX() + 0.5D,
                        perchPos.getY(),
                        perchPos.getZ() + 0.5D
                );


        if (distance > 1.5D) {

            if (this.chicken
                    .getNavigation()
                    .isDone()) {

                moveToFence();
            }

            return;
        }


        this.chicken
                .getNavigation()
                .stop();

        this.chicken.setPos(
                perchPos.getX() + 0.5D,
                perchPos.getY(),
                perchPos.getZ() + 0.5D
        );

        this.perchTime--;


        if (RANDOM.nextInt(20) == 0) {

            this.chicken.getLookControl().setLookAt(
                    this.chicken.getX()
                            + RANDOM.nextDouble() * 2.0D - 1.0D,
                    this.chicken.getY(),
                    this.chicken.getZ()
                            + RANDOM.nextDouble() * 2.0D - 1.0D
            );
        }
    }

    @Override
    public void stop() {

        this.fenceTarget = null;
        this.perchTime = 0;

        this.chicken
                .getNavigation()
                .stop();
    }

    private void moveToFence() {

        if (this.fenceTarget == null) {
            return;
        }

        BlockPos perchPos =
                this.fenceTarget.above();

        this.chicken
                .getNavigation()
                .moveTo(
                        perchPos.getX() + 0.5D,
                        perchPos.getY(),
                        perchPos.getZ() + 0.5D,
                        this.speed
                );
    }

    private BlockPos findFence() {

        BlockPos chickenPos =
                this.chicken.blockPosition();

        BlockPos bestFence = null;

        double bestDistance =
                Double.MAX_VALUE;

        for (int x = -SEARCH_RADIUS;
             x <= SEARCH_RADIUS;
             x++) {

            for (int y = -2;
                 y <= 2;
                 y++) {

                for (int z = -SEARCH_RADIUS;
                     z <= SEARCH_RADIUS;
                     z++) {

                    if (x * x + z * z
                            > SEARCH_RADIUS * SEARCH_RADIUS) {
                        continue;
                    }

                    BlockPos pos =
                            chickenPos.offset(
                                    x,
                                    y,
                                    z
                            );


                    if (!(this.chicken.level()
                            .getBlockState(pos)
                            .getBlock()
                            instanceof FenceBlock)) {
                        continue;
                    }


                    BlockPos perchPos =
                            pos.above();

                    if (!this.chicken.level()
                            .getBlockState(perchPos)
                            .isAir()) {
                        continue;
                    }


                    if (!this.chicken.level()
                            .getBlockState(perchPos.above())
                            .isAir()) {
                        continue;
                    }

                    double distance =
                            this.chicken.distanceToSqr(
                                    perchPos.getX() + 0.5D,
                                    perchPos.getY(),
                                    perchPos.getZ() + 0.5D
                            );

                    if (distance < bestDistance) {

                        bestDistance = distance;
                        bestFence = pos;
                    }
                }
            }
        }

        return bestFence;
    }
}