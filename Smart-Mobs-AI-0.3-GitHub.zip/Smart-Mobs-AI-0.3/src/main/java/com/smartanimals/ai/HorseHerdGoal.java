package com.smartanimals.ai;

import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.horse.Horse;

import java.util.EnumSet;
import java.util.List;

public class HorseHerdGoal extends Goal {

    private final Horse horse;
    private final double speed;

    private Horse targetHorse;

    private static final int SEARCH_RADIUS = 12;
    private static final double MIN_DISTANCE = 4.0D;
    private static final int CHECK_COOLDOWN = 10;

    private int checkTimer;

    public HorseHerdGoal(
            Horse horse,
            double speed) {

        this.horse = horse;
        this.speed = speed;

        this.setFlags(
                EnumSet.of(Flag.MOVE)
        );
    }

    @Override
    public boolean canUse() {


        if (this.checkTimer > 0) {
            this.checkTimer--;
            return false;
        }


        List<Horse> nearbyHorses =
                this.horse.level().getEntitiesOfClass(
                        Horse.class,
                        this.horse.getBoundingBox()
                                .inflate(SEARCH_RADIUS),
                        other -> other != this.horse
                                && other.isAlive()
                );

        if (nearbyHorses.isEmpty()) {
            this.checkTimer = CHECK_COOLDOWN;
            return false;
        }


        this.targetHorse = findNearestIn(nearbyHorses);


        this.checkTimer = CHECK_COOLDOWN;


        if (this.targetHorse == null) {
            return false;
        }

        double distance =
                this.horse.distanceToSqr(
                        this.targetHorse
                );

        return distance >
                MIN_DISTANCE * MIN_DISTANCE;
    }

    private Horse findNearestIn(List<Horse> candidates) {

        Horse nearest = null;
        double nearestDist = Double.MAX_VALUE;

        for (Horse candidate : candidates) {

            double dist =
                    this.horse.distanceToSqr(
                            candidate
                    );

            if (dist < nearestDist) {
                nearestDist = dist;
                nearest = candidate;
            }
        }

        return nearest;
    }

    @Override
    public boolean canContinueToUse() {

        if (this.targetHorse == null) {
            return false;
        }

        if (!this.targetHorse.isAlive()) {
            return false;
        }


        double distance =
                this.horse.distanceToSqr(
                        this.targetHorse
                );

        return distance >
                MIN_DISTANCE * MIN_DISTANCE;
    }

    @Override
    public void start() {

        moveToHerd();
    }

    @Override
    public void tick() {

        if (this.targetHorse == null) {
            return;
        }


        if (this.horse.getNavigation().isDone()) {

            this.targetHorse =
                    findNearestHorse();

            if (this.targetHorse != null) {
                moveToHerd();
            }
        }
    }

    @Override
    public void stop() {

        this.targetHorse = null;
        this.checkTimer = 0;

        this.horse
                .getNavigation()
                .stop();
    }

    private void moveToHerd() {

        if (this.targetHorse == null) {
            return;
        }

        this.horse
                .getNavigation()
                .moveTo(
                        this.targetHorse,
                        this.speed
                );
    }

    private Horse findNearestHorse() {

        List<Horse> nearbyHorses =
                this.horse.level().getEntitiesOfClass(
                        Horse.class,
                        this.horse.getBoundingBox()
                                .inflate(SEARCH_RADIUS),
                        other -> other != this.horse
                                && other.isAlive()
                );

        if (nearbyHorses.isEmpty()) {
            return null;
        }


        return findNearestIn(nearbyHorses);
    }
}