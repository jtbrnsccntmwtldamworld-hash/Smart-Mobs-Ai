package com.smartanimals.util;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;


public final class MessageHelper {

    private MessageHelper() {
    }


    private static final String PREFIX = "[SMARTMOBS] ";


    public static final int GOLD_COLOR = 0xFFD700;


    private static int sanitizeColor(int color) {
        return color & 0x00FFFFFF;
    }


    private static Component withPrefix(
            Component message) {

        if (!message.getString()
                .startsWith("[SMARTMOBS]")) {

            return Component.literal(
                    PREFIX + message.getString()
            ).withStyle(message.getStyle());
        }

        return message;
    }


    public static void sendMessageIfEnabled(
            Player player,
            Component message) {

        if (player instanceof ServerPlayer serverPlayer
                && SmartMobsMessages.isEnabled(serverPlayer)) {

            int color =
                    sanitizeColor(
                            SmartMobsMessages.getMessageColor(serverPlayer));

            player.sendSystemMessage(
                    withPrefix(message)
                            .copy()
                            .withStyle(
                                    Style.EMPTY.withColor(color)
                            )
            );
        }
    }


    public static void sendActionBarIfEnabled(
            Player player,
            Component message) {

        if (player instanceof ServerPlayer serverPlayer
                && SmartMobsMessages.isEnabled(serverPlayer)) {

            int color =
                    sanitizeColor(
                            SmartMobsMessages.getMessageColor(serverPlayer)
                    );

            player.displayClientMessage(
                    withPrefix(message)
                            .copy()
                            .withStyle(
                                    Style.EMPTY.withColor(color)
                            ),
                    true
            );
        }
    }


    public static boolean areMessagesEnabled(
            Player player) {

        if (player instanceof ServerPlayer serverPlayer) {
            return SmartMobsMessages.isEnabled(serverPlayer);
        }

        return true;
    }


    public static void sendMessageWithColorForce(
            Player player,
            Component message,
            int color) {

        if (player instanceof ServerPlayer) {

            player.sendSystemMessage(
                    withPrefix(message)
                            .copy()
                            .withStyle(
                                    Style.EMPTY.withColor(sanitizeColor(color))
                            )
            );
        }
    }
}
