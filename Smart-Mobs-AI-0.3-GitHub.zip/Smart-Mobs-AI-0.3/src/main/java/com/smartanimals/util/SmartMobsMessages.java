package com.smartanimals.util;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;


public class SmartMobsMessages extends SavedData {

    public static final String DATA_NAME =
            "smartmobs_messages";

    private static final String PLAYERS_TAG =
            "Players";

    private static final String WELCOME_TAG =
            "WelcomeMessages";

    private static final String KEY_ENABLED =
            "Enabled";
    private static final String KEY_COLOR =
            "Color";
    private static final String KEY_COLOR_INDEX =
            "ColorIndex";
    private static final String KEY_CUSTOM_COLOR =
            "CustomColor";
    private static final String KEY_FONT_INDEX =
            "FontIndex";
    private static final String KEY_OPACITY =
            "Opacity";
    private static final String KEY_BACKGROUND =
            "BackgroundIndex";


    private static final int MAX_COLOR_INDEX = 52;
    private static final int MAX_FONT_INDEX = 21;
    private static final int MAX_BACKGROUND_INDEX = 1;

    static final boolean DEFAULT_ENABLED = true;
    static final int DEFAULT_COLOR_INDEX = 0;
    static final int DEFAULT_CUSTOM_COLOR = -1;
    static final int DEFAULT_FONT_INDEX = 0;
    static final int DEFAULT_OPACITY = 100;
    static final int DEFAULT_BACKGROUND_INDEX = 0;

    static final int DEFAULT_COLOR_RGB = 0xDC143C;

    private final Map<UUID, PlayerData> settings =
            new HashMap<>();

    private final Map<UUID, Boolean> welcomeMessages =
            new HashMap<>();

    public SmartMobsMessages() {
    }


    public static SmartMobsMessages load(
            CompoundTag tag
    ) {

        SmartMobsMessages data =
                new SmartMobsMessages();


        CompoundTag playersTag =
                tag.contains(PLAYERS_TAG, Tag.TAG_COMPOUND)
                        ? tag.getCompound(PLAYERS_TAG)
                        : new CompoundTag();

        java.util.Set<String> playerKeys = playersTag.getAllKeys();
        for (String uuidString : playerKeys) {


            if (!playersTag.contains(uuidString, Tag.TAG_COMPOUND)) {
                continue;
            }

            try {
                UUID uuid = UUID.fromString(uuidString);
                data.settings.put(
                        uuid,
                        new PlayerData(playersTag.getCompound(uuidString))
                );
            } catch (IllegalArgumentException ignored) {
            }
        }


        CompoundTag welcomeTag =
                tag.contains(WELCOME_TAG, Tag.TAG_COMPOUND)
                        ? tag.getCompound(WELCOME_TAG)
                        : new CompoundTag();

        java.util.Set<String> welcomeKeys = welcomeTag.getAllKeys();
        for (String uuidString : welcomeKeys) {

            try {
                UUID uuid = UUID.fromString(uuidString);
                if (welcomeTag.contains(uuidString, Tag.TAG_BYTE)) {
                    data.welcomeMessages.put(uuid, welcomeTag.getBoolean(uuidString));
                }
            } catch (IllegalArgumentException ignored) {
            }
        }

        return data;
    }

    @Override
    public CompoundTag save(
            CompoundTag tag
    ) {


        CompoundTag playersTag =
                new CompoundTag();

        for (
                Map.Entry<UUID, PlayerData> entry :
                settings.entrySet()
        ) {

            CompoundTag playerTag =
                    new CompoundTag();

            entry.getValue().save(playerTag);

            playersTag.put(
                    entry.getKey().toString(),
                    playerTag
            );
        }

        tag.put(
                PLAYERS_TAG,
                playersTag
        );


        CompoundTag welcomeTag =
                new CompoundTag();

        for (
                Map.Entry<UUID, Boolean> entry :
                welcomeMessages.entrySet()
        ) {

            welcomeTag.putBoolean(
                    entry.getKey().toString(),
                    entry.getValue()
            );
        }

        tag.put(
                WELCOME_TAG,
                welcomeTag
        );

        return tag;
    }


    public static SmartMobsMessages get(
            ServerLevel level
    ) {

        ServerLevel overworld =
                level.getServer().overworld();

        return overworld
                .getDataStorage()
                .computeIfAbsent(
                        SmartMobsMessages::load,
                        SmartMobsMessages::new,
                        DATA_NAME
                );
    }

    private static SmartMobsMessages get(
            ServerPlayer player
    ) {
        return get(player.serverLevel());
    }

    private static PlayerData getOrCreate(
            SmartMobsMessages data,
            UUID uuid
    ) {
        return data.settings.computeIfAbsent(
                uuid,
                k -> new PlayerData()
        );
    }

    private static PlayerData get(
            SmartMobsMessages data,
            UUID uuid
    ) {
        return data.settings.get(uuid);
    }

    private static int clamp(
            int value,
            int min,
            int max
    ) {
        return Math.max(min, Math.min(max, value));
    }


    public static boolean isEnabled(
            ServerPlayer player
    ) {

        PlayerData pd = get(
                get(player),
                player.getUUID()
        );

        return pd == null
                ? DEFAULT_ENABLED
                : pd.enabled;
    }

    public static void setEnabled(
            ServerPlayer player,
            boolean enabled
    ) {

        SmartMobsMessages data = get(player);
        PlayerData pd = getOrCreate(data, player.getUUID());

        if (pd.enabled == enabled) {
            return;
        }

        pd.enabled = enabled;
        data.setDirty();
    }

    public static boolean toggle(
            ServerPlayer player
    ) {

        SmartMobsMessages data = get(player);
        PlayerData pd = getOrCreate(data, player.getUUID());

        pd.enabled = !pd.enabled;
        data.setDirty();

        return pd.enabled;
    }


    public static boolean hasSeenWelcomeMessage(
            ServerPlayer player
    ) {

        SmartMobsMessages data = get(player);

        Boolean seen =
                data.welcomeMessages.get(player.getUUID());

        return seen != null
                && seen;
    }

    public static void markWelcomeMessageSeen(
            ServerPlayer player
    ) {

        SmartMobsMessages data = get(player);
        UUID uuid = player.getUUID();

        Boolean oldState =
                data.welcomeMessages.get(uuid);

        if (oldState != null
                && oldState) {
            return;
        }

        data.welcomeMessages.put(uuid, true);
        data.setDirty();
    }


    public static int getMessageColor(
            ServerPlayer player
    ) {

        PlayerData pd = get(
                get(player),
                player.getUUID()
        );

        return pd == null
                ? DEFAULT_COLOR_RGB
                : pd.color;
    }


    public static void setMessageColor(
            ServerPlayer player,
            int color
    ) {

        SmartMobsMessages data = get(player);
        PlayerData pd = getOrCreate(data, player.getUUID());

        int rgb = color & 0x00FFFFFF;

        if (pd.color == rgb
                && pd.customColor == rgb
                && pd.colorIndex == DEFAULT_COLOR_INDEX) {
            return;
        }

        pd.color = rgb;
        pd.customColor = rgb;
        pd.colorIndex = DEFAULT_COLOR_INDEX;

        data.setDirty();
    }


    public static int getColorIndex(
            ServerPlayer player
    ) {

        PlayerData pd = get(
                get(player),
                player.getUUID()
        );

        return pd == null
                ? DEFAULT_COLOR_INDEX
                : pd.colorIndex;
    }

    public static void setColorIndex(
            ServerPlayer player,
            int colorIndex
    ) {

        SmartMobsMessages data = get(player);
        PlayerData pd = getOrCreate(data, player.getUUID());

        int clamped = clamp(
                colorIndex,
                0,
                MAX_COLOR_INDEX
        );

        if (pd.colorIndex == clamped) {
            return;
        }

        pd.colorIndex = clamped;
        data.setDirty();
    }

    public static int getCustomColor(
            ServerPlayer player
    ) {

        PlayerData pd = get(
                get(player),
                player.getUUID()
        );

        return pd == null
                ? DEFAULT_CUSTOM_COLOR
                : pd.customColor;
    }

    public static void setCustomColor(
            ServerPlayer player,
            int customColor
    ) {

        SmartMobsMessages data = get(player);
        PlayerData pd = getOrCreate(data, player.getUUID());

        int value = customColor < 0
                ? -1
                : (customColor & 0x00FFFFFF);

        if (pd.customColor == value) {
            return;
        }

        pd.customColor = value;
        data.setDirty();
    }


    public static int getFontIndex(
            ServerPlayer player
    ) {

        PlayerData pd = get(
                get(player),
                player.getUUID()
        );

        return pd == null
                ? DEFAULT_FONT_INDEX
                : pd.fontIndex;
    }

    public static void setFontIndex(
            ServerPlayer player,
            int fontIndex
    ) {

        SmartMobsMessages data = get(player);
        PlayerData pd = getOrCreate(data, player.getUUID());

        int clamped = clamp(
                fontIndex,
                0,
                MAX_FONT_INDEX
        );

        if (pd.fontIndex == clamped) {
            return;
        }

        pd.fontIndex = clamped;
        data.setDirty();
    }


    public static int getOpacity(
            ServerPlayer player
    ) {

        PlayerData pd = get(
                get(player),
                player.getUUID()
        );

        return pd == null
                ? DEFAULT_OPACITY
                : pd.opacity;
    }

    public static void setOpacity(
            ServerPlayer player,
            int opacity
    ) {

        SmartMobsMessages data = get(player);
        PlayerData pd = getOrCreate(data, player.getUUID());

        int clamped = clamp(
                opacity,
                0,
                100
        );

        if (pd.opacity == clamped) {
            return;
        }

        pd.opacity = clamped;
        data.setDirty();
    }


    public static int getBackgroundIndex(
            ServerPlayer player
    ) {

        PlayerData pd = get(
                get(player),
                player.getUUID()
        );

        return pd == null
                ? DEFAULT_BACKGROUND_INDEX
                : pd.backgroundIndex;
    }

    public static void setBackgroundIndex(
            ServerPlayer player,
            int backgroundIndex
    ) {

        SmartMobsMessages data = get(player);
        PlayerData pd = getOrCreate(data, player.getUUID());

        int clamped = clamp(
                backgroundIndex,
                0,
                MAX_BACKGROUND_INDEX
        );

        if (pd.backgroundIndex == clamped) {
            return;
        }

        pd.backgroundIndex = clamped;
        data.setDirty();
    }


    public static void setSettings(
            ServerPlayer player,
            boolean enabled,
            int color,
            int colorIndex,
            int customColor,
            int fontIndex,
            int opacity,
            int backgroundIndex
    ) {

        setSettings(
                player.serverLevel(),
                player.getUUID(),
                enabled,
                color,
                colorIndex,
                customColor,
                fontIndex,
                opacity,
                backgroundIndex
        );
    }


    public static void setSettings(
            ServerLevel level,
            UUID playerId,
            boolean enabled,
            int color,
            int colorIndex,
            int customColor,
            int fontIndex,
            int opacity,
            int backgroundIndex
    ) {

        SmartMobsMessages data = get(level);
        PlayerData pd = getOrCreate(data, playerId);

        pd.enabled = enabled;
        pd.color = color & 0x00FFFFFF;
        pd.colorIndex = clamp(colorIndex, 0, MAX_COLOR_INDEX);
        pd.customColor = customColor < 0
                ? -1
                : (customColor & 0x00FFFFFF);
        pd.fontIndex = clamp(fontIndex, 0, MAX_FONT_INDEX);
        pd.opacity = clamp(opacity, 0, 100);
        pd.backgroundIndex = clamp(backgroundIndex, 0, MAX_BACKGROUND_INDEX);

        data.setDirty();
    }



    public static final class SettingsView {
        public final boolean enabled;
        public final int color;
        public final int colorIndex;
        public final int customColor;
        public final int fontIndex;
        public final int opacity;
        public final int backgroundIndex;

        public SettingsView(
                boolean enabled,
                int color,
                int colorIndex,
                int customColor,
                int fontIndex,
                int opacity,
                int backgroundIndex
        ) {
            this.enabled = enabled;
            this.color = color & 0x00FFFFFF;
            this.colorIndex = colorIndex;
            this.customColor = customColor;
            this.fontIndex = fontIndex;
            this.opacity = opacity;
            this.backgroundIndex = backgroundIndex;
        }
    }


    public static SettingsView getSettings(
            ServerLevel level,
            UUID playerId
    ) {
        PlayerData pd = get(
                get(level),
                playerId
        );

        if (pd == null) {
            return new SettingsView(
                    DEFAULT_ENABLED,
                    DEFAULT_COLOR_RGB,
                    DEFAULT_COLOR_INDEX,
                    DEFAULT_CUSTOM_COLOR,
                    DEFAULT_FONT_INDEX,
                    DEFAULT_OPACITY,
                    DEFAULT_BACKGROUND_INDEX
            );
        }

        return new SettingsView(
                pd.enabled,
                pd.color,
                pd.colorIndex,
                pd.customColor,
                pd.fontIndex,
                pd.opacity,
                pd.backgroundIndex
        );
    }


    private static final class PlayerData {

        boolean enabled;
        int color;
        int colorIndex;
        int customColor;
        int fontIndex;
        int opacity;
        int backgroundIndex;

        PlayerData() {
            this.enabled = DEFAULT_ENABLED;
            this.color = DEFAULT_COLOR_RGB;
            this.colorIndex = DEFAULT_COLOR_INDEX;
            this.customColor = DEFAULT_CUSTOM_COLOR;
            this.fontIndex = DEFAULT_FONT_INDEX;
            this.opacity = DEFAULT_OPACITY;
            this.backgroundIndex = DEFAULT_BACKGROUND_INDEX;
        }


        PlayerData(CompoundTag tag) {
            this();

            if (tag.contains(KEY_ENABLED, Tag.TAG_BYTE)) {
                this.enabled = tag.getBoolean(KEY_ENABLED);
            }
            if (tag.contains(KEY_COLOR, Tag.TAG_INT)) {
                this.color = tag.getInt(KEY_COLOR) & 0x00FFFFFF;
            }
            if (tag.contains(KEY_COLOR_INDEX, Tag.TAG_INT)) {
                this.colorIndex = clamp(
                        tag.getInt(KEY_COLOR_INDEX),
                        0,
                        MAX_COLOR_INDEX
                );
            }
            if (tag.contains(KEY_CUSTOM_COLOR, Tag.TAG_INT)) {
                int stored = tag.getInt(KEY_CUSTOM_COLOR);
                this.customColor = stored < 0
                        ? -1
                        : (stored & 0x00FFFFFF);
            }
            if (tag.contains(KEY_FONT_INDEX, Tag.TAG_INT)) {
                this.fontIndex = clamp(
                        tag.getInt(KEY_FONT_INDEX),
                        0,
                        MAX_FONT_INDEX
                );
            }
            if (tag.contains(KEY_OPACITY, Tag.TAG_INT)) {
                this.opacity = clamp(
                        tag.getInt(KEY_OPACITY),
                        0,
                        100
                );
            }
            if (tag.contains(KEY_BACKGROUND, Tag.TAG_INT)) {
                this.backgroundIndex = clamp(
                        tag.getInt(KEY_BACKGROUND),
                        0,
                        MAX_BACKGROUND_INDEX
                );
            }
        }

        void save(CompoundTag tag) {
            tag.putBoolean(KEY_ENABLED, enabled);
            tag.putInt(KEY_COLOR, color & 0x00FFFFFF);
            tag.putInt(KEY_COLOR_INDEX, colorIndex);
            tag.putInt(KEY_CUSTOM_COLOR, customColor);
            tag.putInt(KEY_FONT_INDEX, fontIndex);
            tag.putInt(KEY_OPACITY, opacity);
            tag.putInt(KEY_BACKGROUND, backgroundIndex);
        }
    }
}