package com.smartanimals.util;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;


public class CowMilkData extends SavedData {

    public static final String DATA_NAME =
            "smartmobs_cow_milk";

    static final int MILK_LIMIT = 20;

    private static final Logger LOGGER =
            LogManager.getLogger();

    private static final String MILKS_TAG =
            "Milks";

    private static final String COUNT_TAG =
            "Count";

    private static final String DAY_TAG =
            "Day";

    // cow UUID -> {count, savedDay}.
    // ONE shared counter per cow for ALL players; reset per cow by game day.
    private final Map<UUID, MilkEntry> milks =
            new HashMap<>();


    // Minecraft game day number (24000 ticks per day). NOT system time.
    public static int dayOf(
            long gameTime
    ) {
        return (int) (gameTime / 24000L);
    }

    static String id(
            UUID uuid
    ) {
        return Long.toHexString(
                uuid.getLeastSignificantBits()
        );
    }

    public CowMilkData() {
    }


    public static CowMilkData load(
            CompoundTag tag
    ) {

        CowMilkData data =
                new CowMilkData();

        CompoundTag milksTag =
                tag.contains(MILKS_TAG, Tag.TAG_COMPOUND)
                        ? tag.getCompound(MILKS_TAG)
                        : new CompoundTag();

        for (String key : milksTag.getAllKeys()) {

            UUID uuid;

            try {
                uuid = UUID.fromString(key);
            } catch (IllegalArgumentException ignored) {
                continue;
            }

            if (milksTag.contains(key, Tag.TAG_COMPOUND)) {

                CompoundTag entryTag =
                        milksTag.getCompound(key);

                MilkEntry entry = new MilkEntry();

                entry.count =
                        entryTag.contains(COUNT_TAG, Tag.TAG_INT)
                                ? entryTag.getInt(COUNT_TAG)
                                : 0;

                entry.savedDay =
                        entryTag.contains(DAY_TAG, Tag.TAG_INT)
                                ? entryTag.getInt(DAY_TAG)
                                : -1;

                data.milks.put(uuid, entry);

            } else if (milksTag.contains(key, Tag.TAG_INT)) {

                // legacy: old per-cow lifetime "int" (Count without Day).
                // no day tracking -> lifetime counter. a lifetime count must NOT
                // be honored by the new daily system, and the old UUID may have
                // been used under different semantics -> drop silently.
            }
        }

        // legacy root "LastDay" (old global day) is intentionally ignored;
        // reset is now per-cow lazy by cow UUID + game time day.

        return data;
    }


    @Override
    public CompoundTag save(
            CompoundTag tag
    ) {

        CompoundTag milksTag =
                new CompoundTag();

        for (
                Map.Entry<UUID, MilkEntry> entry :
                milks.entrySet()
        ) {

            CompoundTag entryTag =
                    new CompoundTag();

            entryTag.putInt(
                    COUNT_TAG,
                    entry.getValue().count
            );

            entryTag.putInt(
                    DAY_TAG,
                    entry.getValue().savedDay
            );

            milksTag.put(
                    entry.getKey().toString(),
                    entryTag
            );
        }

        tag.put(
                MILKS_TAG,
                milksTag
        );

        return tag;
    }


    public static CowMilkData get(
            ServerLevel level
    ) {

        ServerLevel overworld =
                level.getServer().overworld();

        return overworld
                .getDataStorage()
                .computeIfAbsent(
                        CowMilkData::load,
                        CowMilkData::new,
                        DATA_NAME
                );
    }


    // lazy, per-cow daily reset executed at the moment of interaction:
    // if this cow's savedDay != current day (gameTime/24000) -> reset THIS
    // cow's count to 0. no global milks.clear(); other cows untouched.
    MilkEntry entryFor(
            UUID cowId,
            long gameTime
    ) {

        int currentDay =
                dayOf(gameTime);

        MilkEntry entry =
                milks.get(cowId);

        int prevDay =
                entry == null ? -1 : entry.savedDay;

        if (entry == null
                || entry.savedDay != currentDay) {

            entry = new MilkEntry();
            entry.savedDay = currentDay;

            milks.put(
                    cowId,
                    entry
            );

            setDirty();

            LOGGER.info(
                    "[CowMilk] RESET cow={} gameTime={} currentDay={} prevDay={} -> count=0",
                    id(cowId),
                    gameTime,
                    currentDay,
                    prevDay
            );
        }

        return entry;
    }


    public int getMilkCount(
            UUID cowId,
            long gameTime
    ) {

        return entryFor(
                cowId,
                gameTime
        ).count;
    }


    // reset BEFORE the limit check (so a saved 20/20 on day N becomes
    // 0/20 on day N+1 before isEmptied is evaluated).
    public boolean isEmptied(
            UUID cowId,
            long gameTime
    ) {

        MilkEntry entry =
                entryFor(
                        cowId,
                        gameTime
                );

        int count =
                entry.count;

        LOGGER.info(
                "[CowMilk] CHECK cow={} gameTime={} currentDay={} savedDay={} count={}/{}",
                id(cowId),
                gameTime,
                dayOf(gameTime),
                entry.savedDay,
                count,
                MILK_LIMIT
        );

        if (count >= MILK_LIMIT) {

            LOGGER.info(
                    "[CowMilk] BLOCK cow={} gameTime={} currentDay={} savedDay={} count={}/{}",
                    id(cowId),
                    gameTime,
                    dayOf(gameTime),
                    entry.savedDay,
                    count,
                    MILK_LIMIT
            );
        }

        return count >= MILK_LIMIT;
    }


    // called only when vanilla actually delivered milk (mixin gates via consumesAction).
    public int addMilk(
            UUID cowId,
            long gameTime
    ) {

        MilkEntry entry =
                entryFor(
                        cowId,
                        gameTime
                );

        int before =
                entry.count;

        if (entry.count < MILK_LIMIT) {
            entry.count++;
            setDirty();
        }

        LOGGER.info(
                "[CowMilk] MILK cow={} gameTime={} currentDay={} countBefore={} countAfter={}/{}",
                id(cowId),
                gameTime,
                dayOf(gameTime),
                before,
                entry.count,
                MILK_LIMIT
        );

        return entry.count;
    }


    private static final class MilkEntry {

        int count = 0;
        int savedDay = -1;
    }
}
