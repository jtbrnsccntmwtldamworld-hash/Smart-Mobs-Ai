package com.smartanimals.event;

import com.smartanimals.util.CowMilkData;
import com.smartanimals.util.MessageHelper;

import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.animal.Cow;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;

import java.util.Map;
import java.util.WeakHashMap;

public class CowMilkHandler {

    private static final long ALARM_COOLDOWN = 40L;

    private static long lastAlarmTime = -100L;

    private static final Map<Cow, Integer> SCARED_COWS =
            new WeakHashMap<>();


    public static void register() {

        UseEntityCallback.EVENT.register(
                (player, world, hand, entity, hitResult) -> {

                    if (world.isClientSide()) {
                        return InteractionResult.PASS;
                    }

                    if (!(entity instanceof Cow cow)) {
                        return InteractionResult.PASS;
                    }

                    if (!(world instanceof ServerLevel serverLevel)) {
                        return InteractionResult.PASS;
                    }

                    var held = hand == InteractionHand.MAIN_HAND
                            ? player.getMainHandItem()
                            : player.getOffhandItem();

                    if (held.getItem() != Items.BUCKET) {
                        return InteractionResult.PASS;
                    }

                    CowMilkData data =
                            CowMilkData.get(serverLevel);

                    // key = COW UUID: one shared daily counter for ALL players.
                    // reset (if new day) happens INSIDE isEmptied, BEFORE the limit check.
                    if (data.isEmptied(
                            cow.getUUID(),
                            serverLevel.getGameTime()
                    )) {

                        alarm(
                                player,
                                cow,
                                serverLevel
                        );

                        return InteractionResult.FAIL;
                    }

                    return InteractionResult.PASS;
                }
        );
    }


    private static void alarm(
            Player player,
            Cow cow,
            ServerLevel level) {

        long currentTime =
                level.getGameTime();

        if (currentTime - lastAlarmTime
                < ALARM_COOLDOWN) {

            return;
        }

        lastAlarmTime = currentTime;

        cow.playSound(
                SoundEvents.COW_AMBIENT,
                1.0F,
                1.0F
        );

        int scaredCount =
                SCARED_COWS.getOrDefault(
                        cow,
                        0
                );

        MessageHelper.sendActionBarIfEnabled(
                player,
                Component.translatable(
                        "message.smartmobs.cow_empty"
                )
        );

        SCARED_COWS.put(
                cow,
                scaredCount + 1
        );
    }


    private CowMilkHandler() {
    }
}
