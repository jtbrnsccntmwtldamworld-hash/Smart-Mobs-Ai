package com.smartanimals.event;

import com.smartanimals.util.MessageHelper;
import com.smartanimals.util.SmartMobsMessages;

import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public class SmartMobsJoinHandler {

    private static final int DARK_COLOR = 0x444444;

    private static final Component WELCOME_MSG =
            Component.translatable("message.smartmobs.welcome");

    public static void register() {

        ServerPlayConnectionEvents.JOIN.register(
                (handler, sender, server) -> {

                    ServerPlayer player =
                            handler.getPlayer();


                    com.smartanimals.network.SmartMobsServerNetwork
                            .sendSettingsResponse(player);


                    if (SmartMobsMessages.hasSeenWelcomeMessage(player)) {
                        return;
                    }



                    MessageHelper.sendMessageWithColorForce(player, WELCOME_MSG, DARK_COLOR);


                    SmartMobsMessages.markWelcomeMessageSeen(player);
                }
        );
    }

    private SmartMobsJoinHandler() {
    }
}