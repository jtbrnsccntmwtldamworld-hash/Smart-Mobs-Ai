package com.smartanimals.network;

import com.smartanimals.util.SmartMobsMessages;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;


public final class SmartMobsServerNetwork {

    public static final ResourceLocation SETTINGS_RESPONSE_PACKET =
            new ResourceLocation(
                    "smartanimals",
                    "settings_response"
            );

    public static final ResourceLocation GET_SETTINGS_PACKET =
            new ResourceLocation(
                    "smartanimals",
                    "get_settings"
            );

    public static final ResourceLocation SET_SETTINGS_PACKET =
            new ResourceLocation(
                    "smartanimals",
                    "set_settings"
            );

    private SmartMobsServerNetwork() {
    }

    public static void register() {

        ServerPlayNetworking.registerGlobalReceiver(
                GET_SETTINGS_PACKET,
                (server, player, handler, buf, responseSender) -> {

                    server.execute(() -> sendSettingsResponse(player));
                }
        );

        ServerPlayNetworking.registerGlobalReceiver(
                SET_SETTINGS_PACKET,
                (server, player, handler, buf, responseSender) -> {


                    boolean enabled = buf.readBoolean();
                    int color = buf.readInt();
                    int colorIndex = buf.readInt();
                    int customColor = buf.readInt();
                    int fontIndex = buf.readInt();
                    int opacity = buf.readInt();
                    int backgroundIndex = buf.readInt();

                    server.execute(() -> {
                        SmartMobsMessages.setSettings(
                                player,
                                enabled,
                                color,
                                colorIndex,
                                customColor,
                                fontIndex,
                                opacity,
                                backgroundIndex
                        );
                        sendSettingsResponse(player);
                    });
                }
        );
    }


    public static void sendSettingsResponse(
            ServerPlayer player
    ) {

        if (!ServerPlayNetworking.canSend(
                player,
                SETTINGS_RESPONSE_PACKET
        )) {
            return;
        }

        FriendlyByteBuf buf =
                new FriendlyByteBuf(
                        io.netty.buffer.Unpooled.buffer()
                );

        writeSettings(buf, player);

        ServerPlayNetworking.send(
                player,
                SETTINGS_RESPONSE_PACKET,
                buf
        );
    }


    static void writeSettings(
            FriendlyByteBuf buf,
            ServerPlayer player
    ) {
        boolean en = SmartMobsMessages.isEnabled(player);
        int col = SmartMobsMessages.getMessageColor(player);
        int ci = SmartMobsMessages.getColorIndex(player);
        int cc = SmartMobsMessages.getCustomColor(player);
        int fi = SmartMobsMessages.getFontIndex(player);
        int op = SmartMobsMessages.getOpacity(player);
        int bi = SmartMobsMessages.getBackgroundIndex(player);
        buf.writeBoolean(en);
        buf.writeInt(col);
        buf.writeInt(ci);
        buf.writeInt(cc);
        buf.writeInt(fi);
        buf.writeInt(op);
        buf.writeInt(bi);
    }
}