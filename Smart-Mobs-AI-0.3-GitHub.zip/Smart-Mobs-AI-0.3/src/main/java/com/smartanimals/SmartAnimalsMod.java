package com.smartanimals;

import com.smartanimals.ai.PiglinBarterMenuType;
import com.smartanimals.event.SmartMobsJoinHandler;
import com.smartanimals.item.ModItems;
import com.smartanimals.network.SmartMobsServerNetwork;
import com.smartanimals.util.MessageHelper;
import com.smartanimals.util.SmartMobsMessages;
import com.smartanimals.util.SmartMobsMessages.SettingsView;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;

import java.util.UUID;

import static net.minecraft.commands.Commands.argument;
import static net.minecraft.commands.Commands.literal;

public class SmartAnimalsMod implements ModInitializer {

    @Override
    public void onInitialize() {



        ModItems.register();
        ModSounds.register();



        Registry.register(
                BuiltInRegistries.MENU,
                new ResourceLocation(
                        "smartanimals",
                        "piglin_barter"
                ),
                PiglinBarterMenuType.PIGLIN_BARTER_MENU
        );



        SmartMobsJoinHandler.register();

        com.smartanimals.event.CowMilkHandler.register();



        SmartMobsServerNetwork.register();



        CommandRegistrationCallback.EVENT.register(
                (dispatcher, registryAccess, environment) -> {


                    record ColorOption(String name, int color) {}

                    ColorOption[] colorOptions = {
                            new ColorOption("White",   0xFFFFFF),
                            new ColorOption("Green",   0x55FF55),
                            new ColorOption("Red",     0xFF5555),
                            new ColorOption("Yellow",  0xFFFF55),
                            new ColorOption("Cyan",    0x55FFFF),
                            new ColorOption("Pink",    0xFF55FF),
                            new ColorOption("Blue",    0x5555FF),
                    };

                    var messagesNode = literal("messages");
                    messagesNode
                            .then(literal("on")
                                    .executes(context -> {
                                        ServerPlayer player =
                                                context.getSource().getPlayerOrException();
                                        SmartMobsMessages.setEnabled(player, true);
                                        MessageHelper.sendMessageIfEnabled(
                                                player,
                                                Component.translatable("message.smartmobs.cmd_messages_on")
                                        );
                                        return 1;
                                    }))
                            .then(literal("off")
                                    .executes(context -> {
                                        ServerPlayer player =
                                                context.getSource().getPlayerOrException();
                                        SmartMobsMessages.setEnabled(player, false);
                                        MessageHelper.sendMessageIfEnabled(
                                                player,
                                                Component.translatable("message.smartmobs.cmd_messages_off")
                                        );
                                        return 1;
                                    }))
                            .then(literal("toggle")
                                    .executes(context -> {
                                        ServerPlayer player =
                                                context.getSource().getPlayerOrException();
                                        boolean newState =
                                                SmartMobsMessages.toggle(player);
                                        MessageHelper.sendMessageIfEnabled(
                                                player,
                                                Component.translatable(
                                                        "message.smartmobs.cmd_messages_toggle",
                                                        newState ? "ON" : "OFF"
                                                )
                                        );
                                        return 1;
                                    }));

                    var colorNode = literal("color");
                    for (ColorOption option : colorOptions) {
                        colorNode.then(literal(option.name.toLowerCase())
                                .executes(context -> {
                                    ServerPlayer player =
                                            context.getSource().getPlayerOrException();
                                    SmartMobsMessages.setMessageColor(player, option.color);
                                    MessageHelper.sendMessageIfEnabled(
                                            player,
                                            Component.translatable(
                                                    "message.smartmobs.cmd_color_changed",
                                                    option.name
                                            )
                                    );
                                    return 1;
                                }));
                    }


                    var dumpSelf = literal("dump")
                            .executes(context -> {
                                ServerPlayer player =
                                        context.getSource().getPlayerOrException();
                                dumpSettings(player);
                                return 1;
                            });


                    var setallExec = argument("background", IntegerArgumentType.integer(0, 20))
                            .executes(context -> {
                                doSetAll(context);
                                return 1;
                            });
                    var setallOpacity = argument("opacity", IntegerArgumentType.integer(0, 100))
                            .then(setallExec);
                    var setallFont = argument("fontIndex", IntegerArgumentType.integer(0, 21))
                            .then(setallOpacity);
                    var setallCustom = argument("custom", StringArgumentType.string())
                            .then(setallFont);
                    var setallColorIndex = argument("colorIndex", IntegerArgumentType.integer(0, 52))
                            .then(setallCustom);
                    var setallColor = argument("color", StringArgumentType.string())
                            .then(setallColorIndex);
                    var setallEnabled = argument("enabled", BoolArgumentType.bool())
                            .then(setallColor);
                    var setallUuid = argument("uuid", StringArgumentType.string())
                            .then(setallEnabled);
                    var setallNode = literal("setall")
                            .then(setallUuid);


                    var getNode = literal("get")
                            .then(argument("uuid", StringArgumentType.string())
                                    .executes(context -> {
                                        doGet(context);
                                        return 1;
                                    }));

                    dispatcher.register(
                            literal("smartmobs")
                                    .then(messagesNode)
                                    .then(colorNode)
                                    .then(dumpSelf)
                                    .then(setallNode)
                                    .then(getNode)
                    );
                }
        );
    }

    private static void dumpSettings(ServerPlayer player) {
        boolean enabled = SmartMobsMessages.isEnabled(player);
        int color = SmartMobsMessages.getMessageColor(player);
        int colorIndex = SmartMobsMessages.getColorIndex(player);
        int customColor = SmartMobsMessages.getCustomColor(player);
        int font = SmartMobsMessages.getFontIndex(player);
        int opacity = SmartMobsMessages.getOpacity(player);
        int background = SmartMobsMessages.getBackgroundIndex(player);

        String hex = String.format("#%06X", color & 0x00FFFFFF);
        Component msg = Component.literal(
                "SM settings: enabled=" + enabled
                        + " color=" + hex
                        + " colorIndex=" + colorIndex
                        + " customColor=" + customColor
                        + " font=" + font
                        + " opacity=" + opacity
                        + " background=" + background
        );
        player.displayClientMessage(msg, false);
    }

    private static void doSetAll(CommandContext<CommandSourceStack> context) {
        ServerLevel level = context.getSource().getServer().overworld();
        UUID id = UUID.fromString(
                StringArgumentType.getString(context, "uuid"));
        boolean enabled = BoolArgumentType.getBool(context, "enabled");
        int color = parseHexColor(
                StringArgumentType.getString(context, "color"));
        int colorIndex = context.getArgument("colorIndex", Integer.class);
        String customStr = StringArgumentType.getString(context, "custom");
        int customColor = customStr.equalsIgnoreCase("-1")
                ? -1
                : parseHexColor(customStr);
        int fontIndex = context.getArgument("fontIndex", Integer.class);
        int opacity = context.getArgument("opacity", Integer.class);
        int backgroundIndex = context.getArgument("background", Integer.class);

        SmartMobsMessages.setSettings(
                level, id,
                enabled, color, colorIndex, customColor,
                fontIndex, opacity, backgroundIndex
        );

        String summary = String.format(
                "enabled=%s color=#%06X colorIndex=%d customColor=%s font=%d opacity=%d background=%d",
                enabled ? "true" : "false", color & 0x00FFFFFF, colorIndex,
                customColor < 0 ? "-1" : String.format("#%06X", customColor & 0x00FFFFFF),
                fontIndex, opacity, backgroundIndex);
        String msg = "[setall] " + id + " -> " + summary;
        context.getSource().sendSuccess(() -> Component.literal(msg), true);
    }

    private static void doGet(CommandContext<CommandSourceStack> context) {
        ServerLevel level = context.getSource().getServer().overworld();
        UUID id = UUID.fromString(
                StringArgumentType.getString(context, "uuid"));
        SettingsView s = SmartMobsMessages.getSettings(level, id);

        String summary = String.format(
                "enabled=%s color=#%06X colorIndex=%d customColor=%s font=%d opacity=%d background=%d",
                s.enabled ? "true" : "false", s.color & 0x00FFFFFF, s.colorIndex,
                s.customColor < 0 ? "-1" : String.format("#%06X", s.customColor & 0x00FFFFFF),
                s.fontIndex, s.opacity, s.backgroundIndex);
        String msg = "[get] " + id + " <- " + summary;
        context.getSource().sendSuccess(() -> Component.literal(msg), true);
    }

    private static int parseHexColor(String s) {
        String t = s.startsWith("#") ? s.substring(1) : s;
        return Integer.parseUnsignedInt(t, 16) & 0x00FFFFFF;
    }
}