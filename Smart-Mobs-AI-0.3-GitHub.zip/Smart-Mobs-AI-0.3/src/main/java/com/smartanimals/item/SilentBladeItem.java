package com.smartanimals.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.SwordItem;

public class SilentBladeItem extends SwordItem {

    public SilentBladeItem() {
        super(
                SilentTier.INSTANCE,
                3,
                -2.4F,
                new Item.Properties()
                        .stacksTo(1)
                        .durability(500)
        );
    }
}