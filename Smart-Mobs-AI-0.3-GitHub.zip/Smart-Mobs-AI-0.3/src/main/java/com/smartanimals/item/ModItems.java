package com.smartanimals.item;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;

public final class ModItems {

    public static final Item SILENT_BLADE = Registry.register(
            BuiltInRegistries.ITEM,
            new ResourceLocation(
                    "smartanimals",
                    "silent_blade"
            ),
            new SilentBladeItem()
    );

    private ModItems() {
    }

    public static void register() {
    }
}