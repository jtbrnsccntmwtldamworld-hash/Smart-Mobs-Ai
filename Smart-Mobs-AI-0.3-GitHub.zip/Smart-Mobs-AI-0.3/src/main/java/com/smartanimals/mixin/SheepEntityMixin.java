package com.smartanimals.mixin;

import com.smartanimals.ai.SheepGrazingGoal;
import com.smartanimals.ai.SheepGrazingGroupGoal;
import com.smartanimals.ai.SheepStormShelterGoal;
import com.smartanimals.ai.SheepWeaponPanicGoal;

import net.minecraft.world.entity.ai.goal.GoalSelector;
import net.minecraft.world.entity.animal.Sheep;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Sheep.class)
public class SheepEntityMixin {

    @Inject(
            method = "registerGoals",
            at = @At("TAIL")
    )
    private void smartAnimals$registerGoals(
            CallbackInfo ci) {

        Sheep sheep =
                (Sheep) (Object) this;

        GoalSelector goalSelector =
                ((GoalSelectorAccessor) (Object) this).smartAnimals$getGoalSelector();


        goalSelector.addGoal(
                0,
                new SheepWeaponPanicGoal(
                        sheep,
                        1.4D
                )
        );


        goalSelector.addGoal(
                1,
                new SheepStormShelterGoal(
                        sheep,
                        1.0D
                )
        );


        goalSelector.addGoal(
                4,
                new SheepGrazingGroupGoal(
                        sheep,
                        1.0D
                )
        );


        goalSelector.addGoal(
                5,
                new SheepGrazingGoal(
                        sheep,
                        1.0D
                )
        );
    }
}
