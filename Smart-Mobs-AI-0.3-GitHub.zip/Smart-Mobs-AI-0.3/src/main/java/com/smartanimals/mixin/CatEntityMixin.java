package com.smartanimals.mixin;

import com.smartanimals.ai.CatWeaponFleeGoal;
import com.smartanimals.ai.CatThunderFleeGoal;
import com.smartanimals.ai.CatWaterAvoidGoal;
import com.smartanimals.ai.CatChestPerchGoal;
import com.smartanimals.ai.CatHighPlaceGoal;
import com.smartanimals.ai.CatFurnaceSleepGoal;

import net.minecraft.world.entity.ai.goal.GoalSelector;
import net.minecraft.world.entity.animal.Cat;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Cat.class)
public class CatEntityMixin {

    @Inject(
            method = "registerGoals",
            at = @At("TAIL")
    )
    private void smartAnimals$registerGoals(
            CallbackInfo ci) {

        Cat cat =
                (Cat) (Object) this;

        GoalSelector goalSelector =
                ((GoalSelectorAccessor) (Object) this).smartAnimals$getGoalSelector();


        goalSelector.addGoal(
                1,
                new CatWeaponFleeGoal(
                        cat,
                        1.3D
                )
        );


        goalSelector.addGoal(
                2,
                new CatThunderFleeGoal(
                        cat,
                        1.2D
                )
        );


        goalSelector.addGoal(
                4,
                new CatWaterAvoidGoal(
                        cat,
                        1.2D
                )
        );


        goalSelector.addGoal(
                6,
                new CatChestPerchGoal(
                        cat,
                        1.0D
                )
        );


        goalSelector.addGoal(
                7,
                new CatHighPlaceGoal(
                        cat,
                        1.0D
                )
        );


        goalSelector.addGoal(
                8,
                new CatFurnaceSleepGoal(
                        cat,
                        1.0D
                )
        );
    }
}
