package com.smartanimals.mixin;

import com.smartanimals.ai.BlazeCombatGoal;

import net.minecraft.world.entity.ai.goal.GoalSelector;
import net.minecraft.world.entity.monster.Blaze;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Blaze.class)
public class BlazeEntityMixin {

    @Inject(
            method = "registerGoals",
            at = @At("TAIL")
    )
    private void smartAnimals$registerGoals(
            CallbackInfo ci) {

        Blaze blaze =
                (Blaze) (Object) this;

        GoalSelector goalSelector =
                ((GoalSelectorAccessor) (Object) this).smartAnimals$getGoalSelector();


        goalSelector.addGoal(
                5,
                new BlazeCombatGoal(
                        blaze
                )
        );
    }
}
