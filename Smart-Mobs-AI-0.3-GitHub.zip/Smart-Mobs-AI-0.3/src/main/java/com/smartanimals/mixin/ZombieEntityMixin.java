package com.smartanimals.mixin;

import com.smartanimals.ai.ZombieAxeJumpAttackGoal;
import com.smartanimals.ai.ZombieGroupAttackGoal;
import com.smartanimals.ai.ZombieSwordSweepAttackGoal;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.Difficulty;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.goal.GoalSelector;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ServerLevelAccessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Zombie.class)
public class ZombieEntityMixin {

    @Inject(
            method = "registerGoals",
            at = @At("TAIL")
    )
    private void smartAnimals$registerGoals(
            CallbackInfo ci) {

        Zombie zombie =
                (Zombie) (Object) this;

        GoalSelector goalSelector =
                ((GoalSelectorAccessor) (Object) this).smartAnimals$getGoalSelector();


        goalSelector.addGoal(
                2,
                new ZombieAxeJumpAttackGoal(
                        zombie
                )
        );


        goalSelector.addGoal(
                3,
                new ZombieSwordSweepAttackGoal(
                        zombie
                )
        );


        goalSelector.addGoal(
                4,
                new ZombieGroupAttackGoal(
                        zombie
                )
        );
    }



    @Inject(
            method = "finalizeSpawn",
            at = @At("TAIL")
    )
    private void smartAnimals$giveWeapon(
            ServerLevelAccessor level,
            DifficultyInstance difficulty,
            MobSpawnType spawnType,
            SpawnGroupData spawnData,
            CompoundTag tag,
            CallbackInfoReturnable<SpawnGroupData> cir) {

        Zombie zombie =
                (Zombie) (Object) this;


        if (!zombie.getMainHandItem().isEmpty()) {
            return;
        }

        Difficulty currentDifficulty =
                difficulty.getDifficulty();

        float axeChance;

        switch (currentDifficulty) {
        case EASY:
            axeChance = 0.01F;
            break;

        case NORMAL:
            axeChance = 0.025F;
            break;

        case HARD:
            axeChance = 0.05F;
            break;

        default:
            return;
        }



        float swordChance = 0.05F;


        if (level.getRandom().nextFloat() < swordChance) {

            zombie.setItemSlot(
                    EquipmentSlot.MAINHAND,
                    new ItemStack(
                            Items.IRON_SWORD
                    )
            );

            return;
        }


        if (level.getRandom().nextFloat() < axeChance) {

            zombie.setItemSlot(
                    EquipmentSlot.MAINHAND,
                    new ItemStack(
                            Items.IRON_AXE
                    )
            );
        }
    }
}
