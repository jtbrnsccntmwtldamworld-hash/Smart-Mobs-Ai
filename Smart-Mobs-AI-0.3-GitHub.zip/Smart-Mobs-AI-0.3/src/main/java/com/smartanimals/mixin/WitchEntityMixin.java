package com.smartanimals.mixin;

import com.smartanimals.ai.WitchMovementGoal;
import com.smartanimals.ai.WitchPotionSpeedGoal;

import net.minecraft.world.entity.ai.goal.GoalSelector;
import net.minecraft.world.entity.monster.Witch;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Witch.class)
public class WitchEntityMixin {

    @Inject(
            method = "registerGoals",
            at = @At("TAIL")
    )
    private void smartAnimals$registerGoals(
            CallbackInfo ci) {

        Witch witch =
                (Witch) (Object) this;

        GoalSelector goalSelector =
                ((GoalSelectorAccessor) (Object) this).smartAnimals$getGoalSelector();


        goalSelector.addGoal(
                2,
                new WitchPotionSpeedGoal(
                        witch,
                        1.0D,
                        40,
                        16.0F
                )
        );


        goalSelector.addGoal(
                6,
                new WitchMovementGoal(
                        witch
                )
        );
    }
}
