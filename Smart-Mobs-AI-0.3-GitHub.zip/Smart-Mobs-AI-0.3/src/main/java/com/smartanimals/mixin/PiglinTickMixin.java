package com.smartanimals.mixin;

import com.smartanimals.ai.PiglinTrading;

import net.minecraft.world.entity.monster.piglin.Piglin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Piglin.class)
public class PiglinTickMixin {



    @Inject(
            method = "customServerAiStep",
            at = @At("TAIL")
    )
    private void smartAnimals$tradingTick(
            CallbackInfo ci
    ) {

        Piglin piglin =
                (Piglin) (Object) this;



        if (PiglinTrading.isTrading(piglin)) {


            PiglinTrading.tick(
                    piglin
            );

            return;
        }
    }
}