package com.smartanimals.mixin;

import com.smartanimals.ai.HorseExploreGoal;
import com.smartanimals.ai.HorseHerdGoal;
import com.smartanimals.ai.HorseHerdPanicGoal;
import com.smartanimals.ai.HorseReactionGoal;
import com.smartanimals.ai.HorseWildExploreGoal;

import net.minecraft.world.entity.ai.goal.GoalSelector;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import net.minecraft.world.entity.animal.horse.Horse;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractHorse.class)
public class HorseEntityMixin {

    @Inject(
            method = "registerGoals",
            at = @At("TAIL")
    )
    private void smartAnimals$registerGoals(
            CallbackInfo ci) {

        AbstractHorse abstractHorse =
                (AbstractHorse) (Object) this;


        if (!(abstractHorse instanceof Horse horse)) {
            return;
        }

        GoalSelector goalSelector =
                ((GoalSelectorAccessor) (Object) this).smartAnimals$getGoalSelector();


        goalSelector.addGoal(
                2,
                new HorseHerdPanicGoal(
                        horse,
                        1.4D
                )
        );


        goalSelector.addGoal(
                3,
                new HorseReactionGoal(
                        horse,
                        1.2D
                )
        );


        goalSelector.addGoal(
                5,
                new HorseHerdGoal(
                        horse,
                        1.0D
                )
        );


        goalSelector.addGoal(
                6,
                new HorseWildExploreGoal(
                        horse,
                        1.0D
                )
        );


        goalSelector.addGoal(
                6,
                new HorseExploreGoal(
                        horse,
                        1.0D
                )
        );
    }
}
