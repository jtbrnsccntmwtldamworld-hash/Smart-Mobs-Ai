package com.smartanimals.mixin;

import com.smartanimals.ai.ChickenFencePerchGoal;
import com.smartanimals.ai.ChickenFoxPanicGoal;
import com.smartanimals.ai.ChickenHighGroundGoal;
import com.smartanimals.ai.ChickenWeaponPanicGoal;

import net.minecraft.world.entity.ai.goal.GoalSelector;
import net.minecraft.world.entity.animal.Chicken;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Chicken.class)
public class ChickenEntityMixin {

    @Inject(
            method = "registerGoals",
            at = @At("TAIL")
    )
    private void smartAnimals$registerGoals(
            CallbackInfo ci) {

        Chicken chicken =
                (Chicken) (Object) this;

        GoalSelector goalSelector =
                ((GoalSelectorAccessor) (Object) this).smartAnimals$getGoalSelector();


        goalSelector.addGoal(
                0,
                new ChickenWeaponPanicGoal(
                        chicken,
                        1.4D
                )
        );


        goalSelector.addGoal(
                1,
                new ChickenFoxPanicGoal(
                        chicken,
                        1.4D
                )
        );


        goalSelector.addGoal(
                2,
                new ChickenHighGroundGoal(
                        chicken,
                        1.0D
                )
        );


        goalSelector.addGoal(
                3,
                new ChickenFencePerchGoal(
                        chicken,
                        1.0D
                )
        );
    }
}
