package com.smartanimals.mixin;

import com.smartanimals.util.MessageHelper;

import net.minecraft.network.chat.Component;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.entity.player.Player;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;
import java.util.WeakHashMap;

@Mixin(Warden.class)
public abstract class WardenEntityMixin {



    @Unique
    private int smartAnimals$rageTicks = 0;


    @Unique
    private static final int SMART_ANIMALS_RAGE_DURATION =
            20 * 15;


    @Unique
    private static final double SMART_ANIMALS_RAGE_MULTIPLIER =
            1.05D;


    @Unique
    private boolean smartAnimals$rageApplied = false;


    @Unique
    private static final Map<Warden, Integer>
            SMART_ANIMALS_RAGED_WARDENS =
            new WeakHashMap<>();


    @Unique
    private static final Map<Player, Long>
            SMART_ANIMALS_LAST_MESSAGE =
            new WeakHashMap<>();


    @Unique
    private static final long
            SMART_ANIMALS_MESSAGE_COOLDOWN =
            40L;



    @Inject(
            method = "hurt",
            at = @At("HEAD")
    )
    private void smartAnimals$activateRage(
            DamageSource source,
            float amount,
            CallbackInfoReturnable<Boolean> cir
    ) {

        Warden warden =
                (Warden) (Object) this;


        if (source.getEntity() == warden) {
            return;
        }


        if (smartAnimals$rageApplied) {

            smartAnimals$rageTicks =
                    SMART_ANIMALS_RAGE_DURATION;

            smartAnimals$showRageMessage(source);

            return;
        }



        smartAnimals$rageTicks =
                SMART_ANIMALS_RAGE_DURATION;

        smartAnimals$applyRage();


        if (!warden.level().isClientSide()) {

            smartAnimals$showRageMessage(source);
        }
    }



    @Unique
    private void smartAnimals$showRageMessage(
            DamageSource source
    ) {

        Warden warden =
                (Warden) (Object) this;


        if (warden.level().isClientSide()) {
            return;
        }


        if (!(source.getEntity()
                instanceof Player player)) {
            return;
        }

        long currentTime =
                warden.level().getGameTime();

        long lastMessage =
                SMART_ANIMALS_LAST_MESSAGE
                        .getOrDefault(
                                player,
                                -100L
                        );


        if (currentTime - lastMessage
                < SMART_ANIMALS_MESSAGE_COOLDOWN) {

            return;
        }



        int nearbyWardens =
                warden.level()
                        .getEntitiesOfClass(
                                Warden.class,
                                warden.getBoundingBox()
                                        .inflate(16.0D)
                        )
                        .size();

        int rageCount =
                SMART_ANIMALS_RAGED_WARDENS
                        .getOrDefault(
                                warden,
                                0
                        );



        if (rageCount == 0) {


            if (nearbyWardens >= 3) {

                MessageHelper.sendActionBarIfEnabled(
                        player,
                        Component.translatable(
                                "message.smartmobs.wardens_enraged"
                        )
                );

            } else {

                MessageHelper.sendActionBarIfEnabled(
                        player,
                        Component.translatable(
                                "message.smartmobs.warden_enraged"
                        )
                );
            }



        } else {

            if (nearbyWardens >= 3) {

                MessageHelper.sendActionBarIfEnabled(
                        player,
                        Component.translatable(
                                "message.smartmobs.wardens_still_enraged"
                        )
                );

            } else {

                MessageHelper.sendActionBarIfEnabled(
                        player,
                        Component.translatable(
                                "message.smartmobs.warden_still_enraged"
                        )
                );
            }
        }


        SMART_ANIMALS_LAST_MESSAGE.put(
                player,
                currentTime
        );


        SMART_ANIMALS_RAGED_WARDENS.put(
                warden,
                rageCount + 1
        );
    }



    @Inject(
            method = "tick",
            at = @At("HEAD")
    )
    private void smartAnimals$rageTimer(
            CallbackInfo ci
    ) {
        if (smartAnimals$rageTicks <= 0) {
            return;
        }

        smartAnimals$rageTicks--;


        if (smartAnimals$rageTicks == 0) {

            smartAnimals$removeRage();
        }
    }



    @Unique
    private void smartAnimals$applyRage() {

        Warden warden =
                (Warden) (Object) this;


        if (smartAnimals$rageApplied) {
            return;
        }

        AttributeInstance attackDamage =
                warden.getAttribute(
                        Attributes.ATTACK_DAMAGE
                );

        if (attackDamage != null) {

            attackDamage.setBaseValue(
                    attackDamage.getBaseValue()
                            * SMART_ANIMALS_RAGE_MULTIPLIER
            );
        }

        AttributeInstance movementSpeed =
                warden.getAttribute(
                        Attributes.MOVEMENT_SPEED
                );

        if (movementSpeed != null) {

            movementSpeed.setBaseValue(
                    movementSpeed.getBaseValue()
                            * SMART_ANIMALS_RAGE_MULTIPLIER
            );
        }

        smartAnimals$rageApplied = true;
    }



    @Unique
    private void smartAnimals$removeRage() {

        Warden warden =
                (Warden) (Object) this;

        if (!smartAnimals$rageApplied) {
            return;
        }

        AttributeInstance attackDamage =
                warden.getAttribute(
                        Attributes.ATTACK_DAMAGE
                );

        if (attackDamage != null) {

            attackDamage.setBaseValue(
                    attackDamage.getBaseValue()
                            / SMART_ANIMALS_RAGE_MULTIPLIER
            );
        }

        AttributeInstance movementSpeed =
                warden.getAttribute(
                        Attributes.MOVEMENT_SPEED
                );

        if (movementSpeed != null) {

            movementSpeed.setBaseValue(
                    movementSpeed.getBaseValue()
                            / SMART_ANIMALS_RAGE_MULTIPLIER
            );
        }

        smartAnimals$rageApplied = false;
    }



    @Unique
    public boolean smartAnimals$isWardenRaging() {

        return smartAnimals$rageTicks > 0;
    }
}