package com.smartanimals.mixin;

import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Creeper.class)
public class CreeperEntityMixin {

    private boolean smartAnimals$blindSpotCreeper = false;

    private boolean smartAnimals$chanceChecked = false;

    @Inject(
            method = "tick",
            at = @At("HEAD")
    )
    private void smartAnimals$blindSpotTick(
            CallbackInfo ci
    ) {

        Creeper creeper =
                (Creeper) (Object) this;


        if (!smartAnimals$chanceChecked) {

            smartAnimals$chanceChecked = true;

            smartAnimals$blindSpotCreeper =
                    creeper.getRandom().nextFloat() < 0.03F;
        }


        if (!smartAnimals$blindSpotCreeper) {
            return;
        }


        if (!(creeper.getTarget()
                instanceof Player player)) {
            return;
        }

        if (!player.isAlive()) {
            return;
        }


        if (creeper.distanceToSqr(player)
                > 144.0D) {
            return;
        }


        var look =
                player.getViewVector(1.0F)
                        .normalize();

        var toCreeper =
                creeper.position()
                        .subtract(player.position())
                        .normalize();

        double dot =
                look.dot(toCreeper);


        if (dot < 0.55D) {


            creeper.getNavigation().moveTo(
                    player,
                    1.35D
            );
        }
    }
}