package com.smartanimals.mixin;

import com.smartanimals.util.CowMilkData;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.animal.Cow;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Cow.class)
public abstract class CowMilkLimitMixin {

    @Unique
    private boolean smartanimals$milkHeldBucket;


    @Inject(
            method = "mobInteract",
            at = @At("HEAD"),
            cancellable = true
    )
    private void smartanimals$captureHeld(
            Player player,
            InteractionHand hand,
            CallbackInfoReturnable<InteractionResult> cir) {

        this.smartanimals$milkHeldBucket =
                player.getItemInHand(hand).is(Items.BUCKET);

        if (player.level().isClientSide() && this.smartanimals$milkHeldBucket) {
            cir.setReturnValue(InteractionResult.PASS);
        }
    }


    @Inject(
            method = "mobInteract",
            at = @At("RETURN")
    )
    private void smartanimals$countMilk(
            Player player,
            InteractionHand hand,
            CallbackInfoReturnable<InteractionResult> cir) {

        if (player.level().isClientSide()) {
            return;
        }

        if (!this.smartanimals$milkHeldBucket) {
            return;
        }

        // count ONLY when milk was actually delivered (consumesAction() == SUCCESS),
        // never on a cancelled/blocked interact.
        if (!cir.getReturnValue().consumesAction()) {
            return;
        }

        ServerLevel serverLevel =
                (ServerLevel) player.level();

        // key = COW UUID: shared counter for all players.
        CowMilkData.get(serverLevel)
                .addMilk(
                        ((Cow)(Object)this).getUUID(),
                        serverLevel.getGameTime()
                );
    }
}
