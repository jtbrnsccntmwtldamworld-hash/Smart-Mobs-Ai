package com.smartanimals.mixin;

import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.GoalSelector;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(Mob.class)
public interface GoalSelectorAccessor {

    @Accessor("goalSelector")
    GoalSelector smartAnimals$getGoalSelector();
}