package com.smartanimals.mixin;

import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.EnderMan;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EnderMan.class)
public class EndermanEntityMixin {

    @Inject(method = "<init>", at = @At("TAIL"))
    private void smartAnimals$boostAttack(
            net.minecraft.world.entity.EntityType<? extends EnderMan> entityType,
            net.minecraft.world.level.Level level,
            CallbackInfo ci
    ) {
        EnderMan enderman = (EnderMan) (Object) this;

        AttributeInstance attackDamage =
                enderman.getAttribute(Attributes.ATTACK_DAMAGE);

        if (attackDamage != null) {
            attackDamage.setBaseValue(10.0D);
        }
    }
}