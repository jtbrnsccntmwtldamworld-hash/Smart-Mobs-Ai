package com.smartanimals.mixin;

import com.smartanimals.ai.DogProtectOwnerGoal;
import com.smartanimals.ai.DogThunderCarpetGoal;

import net.minecraft.world.entity.ai.goal.GoalSelector;
import net.minecraft.world.entity.animal.Wolf;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Wolf.class)
public class DogEntityMixin {

    @Inject(
            method = "registerGoals",
            at = @At("TAIL")
    )
    private void smartAnimals$registerGoals(
            CallbackInfo ci) {

        Wolf dog =
                (Wolf) (Object) this;

        GoalSelector goalSelector =
                ((GoalSelectorAccessor) (Object) this).smartAnimals$getGoalSelector();


        goalSelector.addGoal(
                2,
                new DogThunderCarpetGoal(
                        dog,
                        1.2D
                )
        );


        goalSelector.addGoal(
                3,
                new DogProtectOwnerGoal(
                        dog,
                        1.2D
                )
        );
    }
}
