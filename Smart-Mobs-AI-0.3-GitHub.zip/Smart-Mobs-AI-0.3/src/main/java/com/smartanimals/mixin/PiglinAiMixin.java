 package com.smartanimals.mixin;

import com.smartanimals.ai.PiglinUtil;
import com.smartanimals.util.MessageHelper;

import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.monster.piglin.PiglinAi;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;

@Mixin(PiglinAi.class)
public class PiglinAiMixin {



    private static final Map<Piglin, UUID>
            SMART_ANIMALS_THROWERS =
            new WeakHashMap<>();



    @Inject(
            method = "pickUpItem",
            at = @At("HEAD")
    )
    private static void smartAnimals$rememberGoldThrower(
            Piglin piglin,
            ItemEntity itemEntity,
            CallbackInfo ci
    ) {



        if (!itemEntity.getItem().is(
                Items.GOLD_INGOT
        )) {
            return;
        }



        UUID throwerUUID =
                ((ItemEntityAccessor) itemEntity)
                        .smartAnimals$getThrower();



        if (throwerUUID == null) {
            return;
        }



        SMART_ANIMALS_THROWERS.put(
                piglin,
                throwerUUID
        );
    }



    @Inject(
            method = "getBarterResponseItems",
            at = @At("HEAD"),
            cancellable = true
    )
    private static void smartAnimals$checkBarterReward(
            Piglin piglin,
            CallbackInfoReturnable<List<ItemStack>> cir
    ) {



        UUID throwerUUID =
                SMART_ANIMALS_THROWERS.get(
                        piglin
                );



        if (throwerUUID == null) {
            return;
        }



        Player thrower = null;

        for (Player player :
                piglin.level().players()) {

            if (player.getUUID().equals(
                    throwerUUID
            )) {

                thrower = player;
                break;
            }
        }



        if (thrower == null) {

            SMART_ANIMALS_THROWERS.remove(
                    piglin
            );

            return;
        }


        if (PiglinUtil.hasAnyGoldArmor(thrower)) {

            SMART_ANIMALS_THROWERS.remove(
                    piglin
            );

            return;
        }



        MessageHelper.sendActionBarIfEnabled(
                thrower,
                Component.translatable(
                        "message.smartmobs.piglin_distracted"
                )
        );



        cir.setReturnValue(
                List.of()
        );



        SMART_ANIMALS_THROWERS.remove(
                piglin
        );
    }
}