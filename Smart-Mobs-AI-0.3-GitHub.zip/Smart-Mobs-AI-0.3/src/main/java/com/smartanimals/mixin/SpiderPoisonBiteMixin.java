package com.smartanimals.mixin;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.monster.Spider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.damagesource.DamageSource;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Player.class)
public class SpiderPoisonBiteMixin {

    @Inject(
            method = "hurt",
            at = @At("RETURN")
    )
    private void smartAnimals$spiderPoisonBite(
            DamageSource source,
            float amount,
            CallbackInfoReturnable<Boolean> cir
    ) {


        if (!cir.getReturnValue()) {
            return;
        }


        Entity attacker = source.getEntity();


        if (!(attacker instanceof Spider spider)) {
            return;
        }


        if (spider.getRandom().nextFloat() >= 0.03F) {
            return;
        }

        Player player =
                (Player) (Object) this;


        player.addEffect(
                new MobEffectInstance(
                        MobEffects.POISON,
                        80,
                        0
                )
        );
    }
}