package com.smartanimals.mixin;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.MilkBucketItem;
import net.minecraft.world.level.Level;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Random;

@Mixin(MilkBucketItem.class)
public class MilkBucketItemMixin {

    private static final Random RANDOM = new Random();

    @Inject(
            method = "finishUsingItem",
            at = @At("RETURN")
    )
    private void smartAnimals$milkPoison(
            ItemStack stack,
            Level level,
            LivingEntity entity,
            CallbackInfoReturnable<ItemStack> cir
    ) {

        if (!(entity instanceof Player player)) {
            return;
        }

        if (player.isCreative() || player.isSpectator()) {
            return;
        }

        if (RANDOM.nextFloat() < 0.05F) {

            if (!level.isClientSide) {

                player.addEffect(
                        new MobEffectInstance(
                                MobEffects.POISON,
                                100,
                                0
                        )
                );
            }
        }
    }
}