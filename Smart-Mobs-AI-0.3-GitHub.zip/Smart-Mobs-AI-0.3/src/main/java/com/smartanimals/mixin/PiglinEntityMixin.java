package com.smartanimals.mixin;

import com.smartanimals.ai.PiglinBarterMenu;
import com.smartanimals.ai.PiglinTrading;
import com.smartanimals.ai.PiglinUtil;
import com.smartanimals.util.MessageHelper;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;
import java.util.WeakHashMap;

@Mixin(Piglin.class)
public class PiglinEntityMixin {



    private static final Map<Player, Boolean> PLAYERS_GOT_HINT =
            new WeakHashMap<>();



    private static final Map<Player, Long> LAST_MESSAGE_TIME =
            new WeakHashMap<>();



    private static final Map<Piglin, Integer> REFUSED_PIGLINS =
            new WeakHashMap<>();

    private static final long MESSAGE_COOLDOWN = 40L;



    @Inject(
            method = "mobInteract",
            at = @At("HEAD"),
            cancellable = true
    )
    private void smartAnimals$customPiglinBarter(
            Player player,
            InteractionHand hand,
            CallbackInfoReturnable<InteractionResult> cir
    ) {



        if (player.level().isClientSide()) {
            return;
        }

        Piglin piglin =
                (Piglin) (Object) this;



        if (piglin.isBaby()) {
            return;
        }



        if (PiglinUtil.hasAnyGoldArmor(player)) {



            PiglinTrading.start(
                    piglin,
                    player
            );



            player.openMenu(
                    new SimpleMenuProvider(
                            (containerId, inventory, menuPlayer) ->
                                    new PiglinBarterMenu(
                                            containerId,
                                            inventory,
                                            piglin
                                    ),
                            Component.translatable(
                                    "screen.smartanimals.piglin_barter"
                            )
                    )
            );



            cir.setReturnValue(
                    InteractionResult.SUCCESS
            );

            return;
        }



        refuseGold(
                piglin,
                player
        );



        cir.setReturnValue(
                InteractionResult.SUCCESS
        );
    }



    @Inject(
            method = "wantsToPickUp",
            at = @At("HEAD"),
            cancellable = true
    )
    private void smartAnimals$disableGroundGoldBarter(
            ItemStack stack,
            CallbackInfoReturnable<Boolean> cir
    ) {



        if (stack.is(Items.GOLD_INGOT)) {

            cir.setReturnValue(false);
        }
    }



    private static void refuseGold(
            Piglin piglin,
            Player player
    ) {

        long currentTime =
                piglin.level().getGameTime();

        long lastMessage =
                LAST_MESSAGE_TIME.getOrDefault(
                        player,
                        -100L
                );



        int nearbyPiglins =
                piglin.level()
                        .getEntitiesOfClass(
                                Piglin.class,
                                piglin.getBoundingBox()
                                        .inflate(10.0D)
                        )
                        .size();



        int refusedCount =
                REFUSED_PIGLINS.getOrDefault(
                        piglin,
                        0
                );



        if (currentTime - lastMessage
                >= MESSAGE_COOLDOWN) {



            if (refusedCount == 0) {

                if (nearbyPiglins >= 5) {

                    MessageHelper.sendActionBarIfEnabled(
                            player,
                            Component.translatable("message.smartmobs.piglin_refuse_plural")
                    );

                } else {

                    MessageHelper.sendActionBarIfEnabled(
                            player,
                            Component.translatable("message.smartmobs.piglin_refuse_singular")
                    );
                }

            } else {



                if (nearbyPiglins >= 5) {
                    MessageHelper.sendActionBarIfEnabled(
                            player,
                            Component.translatable("message.smartmobs.piglin_refuse_plural_repeat")
                    );

                } else {

                    MessageHelper.sendActionBarIfEnabled(
                            player,
                            Component.translatable("message.smartmobs.piglin_refuse_singular_repeat")
                    );
                }
            }

            LAST_MESSAGE_TIME.put(
                    player,
                    currentTime
            );
        }



        if (!PLAYERS_GOT_HINT.containsKey(player)) {

            Component tipsMessage =
                    Component.translatable("message.smartmobs.piglin_tip");

            MessageHelper.sendMessageIfEnabled(
                    player,
                    tipsMessage
            );

            PLAYERS_GOT_HINT.put(
                    player,
                    true
            );
        }



        REFUSED_PIGLINS.put(
                piglin,
                refusedCount + 1
        );
    }
}