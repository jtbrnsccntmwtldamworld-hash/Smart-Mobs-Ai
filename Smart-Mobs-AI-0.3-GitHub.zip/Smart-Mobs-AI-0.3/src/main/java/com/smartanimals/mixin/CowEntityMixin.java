package com.smartanimals.mixin;

import com.smartanimals.ai.CowWeaponPanicGoal;

import net.minecraft.world.entity.ai.goal.GoalSelector;
import net.minecraft.world.entity.animal.Cow;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Cow.class)
public class CowEntityMixin {

    @Inject(
            method = "registerGoals",
            at = @At("TAIL")
    )
    private void smartAnimals$registerGoals(
            CallbackInfo ci) {

        Cow cow =
                (Cow) (Object) this;

        GoalSelector goalSelector =
                ((GoalSelectorAccessor) (Object) this).smartAnimals$getGoalSelector();

        goalSelector.addGoal(
                0,
                new CowWeaponPanicGoal(
                        cow
                )
        );
    }
}
