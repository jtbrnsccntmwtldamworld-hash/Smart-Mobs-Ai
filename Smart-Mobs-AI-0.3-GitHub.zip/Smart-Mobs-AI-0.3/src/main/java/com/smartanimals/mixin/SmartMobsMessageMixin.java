package com.smartanimals.mixin;

import com.smartanimals.util.MessageHelper;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ServerPlayer.class)
public abstract class SmartMobsMessageMixin {

    @Unique
    private static final String SMARTMOBS_PREFIX = "[SMARTMOBS]";

    @Unique
    private static final int PREFIX_LENGTH = SMARTMOBS_PREFIX.length();

    @Inject(
            method = "sendSystemMessage",
            at = @At("HEAD"),
            cancellable = true
    )
    private void smartAnimals$filterMessage(
            Component message,
            CallbackInfo ci
    ) {

        ServerPlayer player =
                (ServerPlayer) (Object) this;

        String text =
                message.getString();

        if (!text.startsWith(SMARTMOBS_PREFIX)) {
            return;
        }

        if (!MessageHelper.areMessagesEnabled(player)) {
            ci.cancel();
            return;
        }

        String displayText =
                text.substring(PREFIX_LENGTH).trim();

        Component displayMessage =
                Component.literal(displayText)
                        .withStyle(message.getStyle());

        ci.cancel();

        player.connection.send(
                new net.minecraft.network.protocol.game.ClientboundSystemChatPacket(
                        displayMessage,
                        false
                )
        );
    }

    @Inject(
            method = "displayClientMessage",
            at = @At("HEAD"),
            cancellable = true
    )
    private void smartAnimals$filterActionBarMessage(
            Component message,
            boolean actionBar,
            CallbackInfo ci
    ) {

        ServerPlayer player =
                (ServerPlayer) (Object) this;

        String text =
                message.getString();

        if (!text.startsWith(SMARTMOBS_PREFIX)) {
            return;
        }

        if (!MessageHelper.areMessagesEnabled(player)) {
            ci.cancel();
            return;
        }

        ci.cancel();

        player.connection.send(
                new net.minecraft.network.protocol.game.ClientboundSystemChatPacket(
                        message,
                        actionBar
                )
        );
    }
}