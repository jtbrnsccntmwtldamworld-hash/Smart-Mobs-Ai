package com.smartanimals.mixin;

import com.smartanimals.ai.UndeadSunShelterGoal;

import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.GoalSelector;
import net.minecraft.world.entity.monster.Skeleton;
import net.minecraft.world.entity.monster.Zombie;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mob.class)
public abstract class UndeadMixin {

    @Shadow
    @Final
    protected GoalSelector goalSelector;

    @Inject(
            method = "<init>",
            at = @At("TAIL")
    )
    private void smartanimals$addUndeadShelterGoal(
            CallbackInfo ci
    ) {

        Mob mob = (Mob) (Object) this;

        if (mob instanceof Zombie zombie) {

            this.goalSelector.addGoal(
                    1,
                    new UndeadSunShelterGoal(zombie)
            );

        } else if (mob instanceof Skeleton skeleton) {

            this.goalSelector.addGoal(
                    1,
                    new UndeadSunShelterGoal(skeleton)
            );
        }
    }
}