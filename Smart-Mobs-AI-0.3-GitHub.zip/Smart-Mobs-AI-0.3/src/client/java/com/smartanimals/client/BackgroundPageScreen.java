package com.smartanimals.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;


@net.fabricmc.api.Environment(net.fabricmc.api.EnvType.CLIENT)
public class BackgroundPageScreen extends BaseConfigPageScreen {

    private static final int CARD_WIDTH = 160;
    private static final int CARD_HEIGHT = 76;
    private static final int CARD_GAP = 12;

    private static final int PREVIEW_W = 110;
    private static final int PREVIEW_H = 44;

    public BackgroundPageScreen(SmartAnimalsConfigScreen parent) {
        super(parent, Component.translatable("gui.smartanimals.page_background"));
    }

    @Override
    protected void createPageButtons() {
        addFooterButton(contentRight(), MEDIUM_BUTTON_WIDTH, BUTTON_HEIGHT,
                Component.translatable("gui.smartanimals.apply"),
                button -> {
                    parent.applySettings();
                    parent.markDirty();
                });
    }

    private int gridY(int bgCount) {
        int viewportH = contentBottom() - contentTop();
        return contentTop() + (viewportH - CARD_HEIGHT) / 2;
    }

    private int gridX(int bgCount) {
        int gridW = bgCount * CARD_WIDTH + (bgCount - 1) * CARD_GAP;
        return centerX(gridW);
    }

    @Override
    protected void renderPageContent(
            GuiGraphics graphics,
            float alpha,
            float animationProgress,
            int mouseX, int mouseY,
            float partialTick
    ) {
        int bgCount = BackgroundRenderer.BACKGROUND_NAMES.length;
        int alpha255 = (int) (alpha * 255);

        int gx = gridX(bgCount);
        int gy = gridY(bgCount);

        backgroundRenderer.setSize(PREVIEW_W, PREVIEW_H);

        for (int i = 0; i < bgCount; i++) {
            int cx = gx + i * (CARD_WIDTH + CARD_GAP);
            int cy = gy;
            boolean isSelected = parent.currentBackgroundIndex == i;
            boolean isHovered = mouseX >= cx && mouseX <= cx + CARD_WIDTH
                    && mouseY >= cy && mouseY <= cy + CARD_HEIGHT;

            int bgAlpha = (int) (alpha * (isSelected ? 140 : 70)) << 24;
            graphics.fill(cx, cy, cx + CARD_WIDTH, cy + CARD_HEIGHT, bgAlpha | 0x000000);

            int borderColor = (alpha255 << 24) | ((isSelected || isHovered) ? 0xD4AF37 : 0x888888);
            graphics.fill(cx, cy, cx + CARD_WIDTH, cy + 1, borderColor);
            graphics.fill(cx, cy + CARD_HEIGHT - 1, cx + CARD_WIDTH, cy + CARD_HEIGHT, borderColor);
            graphics.fill(cx, cy, cx + 1, cy + CARD_HEIGHT, borderColor);
            graphics.fill(cx + CARD_WIDTH - 1, cy, cx + CARD_WIDTH, cy + CARD_HEIGHT, borderColor);

            int previewX = cx + 6;
            int previewY = cy + 6;
            graphics.fill(previewX - 1, previewY - 1,
                    previewX + PREVIEW_W + 1, previewY + PREVIEW_H + 1,
                    (alpha255 << 24) | 0xFFFFFF);
            graphics.fill(previewX, previewY,
                    previewX + PREVIEW_W, previewY + PREVIEW_H,
                    (int) (alpha * 70) << 24 | 0x000000);

            graphics.pose().pushPose();
            graphics.pose().translate(previewX, previewY, 0);
            backgroundRenderer.render(graphics, (float) (alpha * 0.75f), i);
            graphics.pose().popPose();

            graphics.drawString(this.font,
                    Component.translatable(BackgroundRenderer.getBackgroundKey(i)),
                    previewX, previewY + PREVIEW_H + 4,
                    (alpha255 << 24) | 0xCCCCCC, false);

            if (isSelected) {
                graphics.drawString(this.font,
                        Component.literal("\u2713"),
                        cx + CARD_WIDTH - 14, cy + 4,
                        (alpha255 << 24) | 0xD4AF37, false);
            }
        }

        backgroundRenderer.setSize(this.width, this.height);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        boolean handled = super.mouseClicked(mouseX, mouseY, button);
        if (handled) return true;

        int bgCount = BackgroundRenderer.BACKGROUND_NAMES.length;
        int gx = gridX(bgCount);
        int gy = gridY(bgCount);

        for (int i = 0; i < bgCount; i++) {
            int cx = gx + i * (CARD_WIDTH + CARD_GAP);
            int cy = gy;
            if (mouseX >= cx && mouseX <= cx + CARD_WIDTH
                    && mouseY >= cy && mouseY <= cy + CARD_HEIGHT) {
                parent.currentBackgroundIndex = i;
                parent.markDirty();
                parent.applyColor();
                playClickSound();
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        return false;
    }
}
