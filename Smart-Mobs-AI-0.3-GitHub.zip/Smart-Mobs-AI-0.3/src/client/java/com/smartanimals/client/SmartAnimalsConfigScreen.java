package com.smartanimals.client;

import com.smartanimals.network.SmartMobsClientNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;


@net.fabricmc.api.Environment(net.fabricmc.api.EnvType.CLIENT)
public class SmartAnimalsConfigScreen extends BaseConfigPageScreen {


    public static final int[] COLORS = PresetColor.COLORS;
    public static final String[] COLOR_NAMES = PresetColor.COLOR_NAMES;

    private final Screen originalParent;


    boolean messagesEnabled = true;

    int currentColorIndex = 0;


    int customColorValue = -1;

    int currentFontIndex = 0;

    int currentBackgroundIndex = 0;

    int currentMessageOpacity = 100;

    boolean dirty = false;


    private Snapshot savedSnapshot;


    public SmartAnimalsConfigScreen(Screen parent) {
        super(null, Component.translatable("gui.smartanimals.config_title"));
        this.originalParent = parent;
        this.showBackButton = false;
    }

    @Override
    protected void init() {
        SmartAnimalsClientConfig config = clientConfig;

        if (savedSnapshot == null) {
            snapshotFromConfig();
        }

        SmartMobsHud.setHudTransparency(currentMessageOpacity);

        super.init();


        if (!config.isLoaded()) {
            SmartMobsClientNetwork.requestSettings(
                    sd -> { if (!dirty) snapshotFromConfig(); }
            );
        }
    }


    private void snapshotFromConfig() {
        SmartAnimalsClientConfig c = clientConfig;
        savedSnapshot = new Snapshot(
                c.isMessagesEnabled(),
                c.getColorIndex(),
                c.getCustomColor(),
                c.getFontIndex(),
                c.getMessageOpacity(),
                c.getBackgroundIndex()
        );
        copyFromSnapshot();
    }

    private void copyFromSnapshot() {
        messagesEnabled = savedSnapshot.enabled;
        currentColorIndex = savedSnapshot.colorIndex;
        customColorValue = savedSnapshot.customColor;
        currentFontIndex = savedSnapshot.fontIndex;
        currentMessageOpacity = savedSnapshot.opacity;
        currentBackgroundIndex = savedSnapshot.backgroundIndex;
    }

    @Override
    protected void createPageButtons() {
        int bw = BUTTON_WIDTH;

        int gridW = bw * 3 + CARD_GAP * 2;
        int gx = centerX(gridW);
        int settingsBoxBottom = contentTop() + settingsBoxHeight();
        int gy = settingsBoxBottom + SECTION_GAP;

        addPageButton(gx, gy, bw, BUTTON_HEIGHT,
                Component.translatable("gui.smartanimals.category_messages"),
                button -> minecraft.setScreen(new MessagesPageScreen(this)));
        addPageButton(gx + bw + CARD_GAP, gy, bw, BUTTON_HEIGHT,
                Component.translatable("gui.smartanimals.category_color"),
                button -> minecraft.setScreen(new ColorPageScreen(this)));
        addPageButton(gx + bw * 2 + CARD_GAP * 2, gy, bw, BUTTON_HEIGHT,
                Component.translatable("gui.smartanimals.category_background"),
                button -> minecraft.setScreen(new BackgroundPageScreen(this)));

        int right = contentRight();
        addFooterButton(contentLeft() + SMALL_BUTTON_WIDTH, SMALL_BUTTON_WIDTH, BUTTON_HEIGHT,
                Component.translatable("gui.smartanimals.restore_defaults")
                        .withStyle(ChatFormatting.GRAY),
                button -> restoreDefaults());
        addFooterButton(right, MEDIUM_BUTTON_WIDTH, BUTTON_HEIGHT,
                Component.translatable("gui.smartanimals.save"),
                button -> saveAndClose());
    }



    private int settingsBoxHeight() {
        int lines = 4;
        int lineHeight = 12;
        return 16 + lines * lineHeight + 6;
    }

    @Override
    protected void renderPageContent(
            GuiGraphics graphics,
            float alpha,
            float animationProgress,
            int mouseX, int mouseY,
            float partialTick
    ) {
        int alpha255 = (int) (alpha * 255);
        int x = contentLeft();
        int y = contentTop();

        int boxW = 210;
        int lineHeight = 12;
        int boxH = settingsBoxHeight();
        renderSectionBox(graphics, x, y, boxW, boxH,
                Component.translatable("gui.smartanimals.current_settings"), alpha);

        int cx = x + 6;
        int cy = y + 16;

        int currentColor = getEffectiveColor();
        int chipColor = (alpha255 << 24) | (currentColor & 0x00FFFFFF);
        graphics.fill(cx, cy, cx + SWATCH, cy + SWATCH, chipColor);
        graphics.fill(cx - 1, cy - 1, cx + SWATCH + 1, cy + SWATCH + 1,
                (alpha255 << 24) | 0xFFFFFF);
        graphics.drawString(this.font, Component.literal(getEffectiveColorName()),
                cx + SWATCH + 6, cy + 3, (alpha255 << 24) | 0xCCCCCC, false);
        cy += lineHeight;





        graphics.drawString(this.font,
                Component.translatable("gui.smartanimals.opacity_label_value",
                        currentMessageOpacity),
                cx, cy, (alpha255 << 24) | 0xAAAAAA, false);
        cy += lineHeight;

        graphics.drawString(this.font,
                messagesEnabled
                        ? Component.translatable("gui.smartanimals.messages_on")
                        : Component.translatable("gui.smartanimals.messages_off"),
                cx, cy, (alpha255 << 24) | (messagesEnabled ? 0x55FF55 : 0xFF5555), false);
    }



    int getEffectiveColor() {
        if (customColorValue >= 0) {
            return customColorValue & 0x00FFFFFF;
        }
        return COLORS[currentColorIndex];
    }


    String getEffectiveColorName() {
        if (customColorValue >= 0) {
            int r = (customColorValue >> 16) & 0xFF;
            int g = (customColorValue >> 8) & 0xFF;
            int b = customColorValue & 0xFF;
            return String.format("#%02X%02X%02X", r, g, b);
        }
        return COLOR_NAMES[currentColorIndex];
    }

    void markDirty() {
        dirty = true;
    }


    void applyColor() {
    }

    void applyFont() {
    }

    void applyOpacity() {
        SmartMobsHud.setHudTransparency(currentMessageOpacity);
    }


    void applySettings() {
        applyFont();
        applyOpacity();
    }


    void restoreDefaults() {
        playClickSound();
        messagesEnabled = SmartAnimalsClientConfig.DEFAULT_MESSAGES_ENABLED;
        currentColorIndex = SmartAnimalsClientConfig.DEFAULT_COLOR_INDEX;
        customColorValue = SmartAnimalsClientConfig.DEFAULT_CUSTOM_COLOR;
        currentFontIndex = SmartAnimalsClientConfig.DEFAULT_FONT_INDEX;
        currentMessageOpacity = SmartAnimalsClientConfig.DEFAULT_MESSAGE_OPACITY;
        currentBackgroundIndex = SmartAnimalsClientConfig.DEFAULT_BACKGROUND_INDEX;
        applySettings();
        markDirty();
    }


    void saveSettings() {
        boolean connected = minecraft.player != null;


        if (connected) {
            SmartMobsClientNetwork.sendSettings(
                    messagesEnabled,
                    getEffectiveColor(),
                    currentColorIndex,
                    customColorValue,
                    currentFontIndex,
                    currentMessageOpacity,
                    currentBackgroundIndex
            );
        }


        clientConfig.applyServerSettings(
                messagesEnabled,
                getEffectiveColor(),
                currentColorIndex,
                customColorValue,
                currentFontIndex,
                currentMessageOpacity,
                currentBackgroundIndex
        );

        clientConfig.save();

        savedSnapshot = new Snapshot(
                messagesEnabled,
                currentColorIndex,
                customColorValue,
                currentFontIndex,
                currentMessageOpacity,
                currentBackgroundIndex
        );

        dirty = false;
    }


    void saveAndClose() {
        playClickSound();
        saveSettings();
        applySettings();
        minecraft.setScreen(originalParent);
    }


    @Override
    public void onClose() {
        minecraft.setScreen(originalParent);
    }


    @Override
    protected SmartAnimalsConfigScreen getEffectiveParent() {
        return this;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }



    private record Snapshot(
            boolean enabled,
            int colorIndex,
            int customColor,
            int fontIndex,
            int opacity,
            int backgroundIndex
    ) {
    }
}