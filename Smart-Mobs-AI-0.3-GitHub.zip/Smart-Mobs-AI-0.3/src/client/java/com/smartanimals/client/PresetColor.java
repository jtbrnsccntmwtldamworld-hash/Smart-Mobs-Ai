package com.smartanimals.client;


public final class PresetColor {

    private final String name;
    private final int rgb;
    private final String group;

    public PresetColor(String name, int rgb, String group) {
        this.name = name;
        this.rgb = rgb & 0x00FFFFFF;
        this.group = group;
    }

    public String getName() {
        return name;
    }

    public int getRgb() {
        return rgb;
    }

    public String getGroup() {
        return group;
    }


    public static final String[] GROUP_NAMES = {
            "Reds",
            "Oranges",
            "Yellows",
            "Greens",
            "Cyans",
            "Blues",
            "Purples",
            "Pinks",
            "Dark",
            "Special"
    };


    public static final PresetColor[] PRESET_COLORS = {
            new PresetColor("Crimson",    0xDC143C, "Reds"),
            new PresetColor("Scarlet",    0xFF2400, "Reds"),
            new PresetColor("Ruby",       0xE0115F, "Reds"),
            new PresetColor("Blood Red",  0x8B0000, "Reds"),

            new PresetColor("Orange",     0xFFA500, "Oranges"),
            new PresetColor("Amber",      0xFFBF00, "Oranges"),
            new PresetColor("Pumpkin",    0xFF7518, "Oranges"),
            new PresetColor("Peach",      0xFFDAB9, "Oranges"),
            new PresetColor("Bronze",     0xCD7F32, "Oranges"),

            new PresetColor("Golden",     0xFFD700, "Yellows"),
            new PresetColor("Lemon",      0xFFF44F, "Yellows"),
            new PresetColor("Goldenrod",  0xDAA520, "Yellows"),
            new PresetColor("Sunflower",  0xFFC125, "Yellows"),

            new PresetColor("Lime",       0x00FF00, "Greens"),
            new PresetColor("Emerald",    0x50C878, "Greens"),
            new PresetColor("Forest",     0x228B22, "Greens"),
            new PresetColor("Mint",       0x98FB98, "Greens"),
            new PresetColor("Jade",       0x00A86B, "Greens"),

            new PresetColor("Teal",       0x008080, "Cyans"),
            new PresetColor("Cyan",       0x00FFFF, "Cyans"),
            new PresetColor("Aqua",       0x7FFFD4, "Cyans"),
            new PresetColor("Ice",        0x90FFFF, "Cyans"),
            new PresetColor("Frost",      0xE0FFFF, "Cyans"),

            new PresetColor("Blue",       0x0000FF, "Blues"),
            new PresetColor("Sky",        0x87CEEB, "Blues"),
            new PresetColor("Ocean",      0x1C71A8, "Blues"),
            new PresetColor("Royal Blue", 0x4169E1, "Blues"),
            new PresetColor("Navy",       0x000080, "Blues"),

            new PresetColor("Indigo",     0x4B0082, "Purples"),
            new PresetColor("Violet",     0xEE82EE, "Purples"),
            new PresetColor("Purple",     0x800080, "Purples"),
            new PresetColor("Amethyst",   0x9966CC, "Purples"),
            new PresetColor("Lilac",      0xE6E6FA, "Purples"),

            new PresetColor("Magenta",    0xFF00FF, "Pinks"),
            new PresetColor("Fuchsia",    0xFF00FF, "Pinks"),
            new PresetColor("Pink",       0xFFC0CB, "Pinks"),
            new PresetColor("Rose",       0xFF007F, "Pinks"),
            new PresetColor("Strawberry", 0xFC5A5A, "Pinks"),

            new PresetColor("Charcoal",   0x36454F, "Dark"),
            new PresetColor("Black",      0x000000, "Dark"),
            new PresetColor("Obsidian",   0x0A0A0A, "Dark"),
            new PresetColor("Dark Gray",  0x808080, "Dark"),
            new PresetColor("Gunmetal",   0x2B3244, "Dark"),

            new PresetColor("White",      0xFFFFFF, "Special"),
            new PresetColor("Silver",     0xC0C0C0, "Special"),
            new PresetColor("Light Gray", 0xD3D3D3, "Special"),
            new PresetColor("Copper",     0xB87333, "Special"),
            new PresetColor("Platinum",   0xE5E4E2, "Special"),
            new PresetColor("Neon",       0x39FF14, "Special"),
            new PresetColor("Void",       0x020202, "Special"),
            new PresetColor("Mystic",     0x9966CC, "Special"),
            new PresetColor("Aurora",     0x7FFFD4, "Special"),
            new PresetColor("Sunset",     0xFF8C00, "Special")
    };


    public static final int[] COLORS = new int[PRESET_COLORS.length];
    public static final String[] COLOR_NAMES = new String[PRESET_COLORS.length];

    static {
        for (int i = 0; i < PRESET_COLORS.length; i++) {
            COLORS[i] = PRESET_COLORS[i].getRgb();
            COLOR_NAMES[i] = PRESET_COLORS[i].getName();
        }
    }


}