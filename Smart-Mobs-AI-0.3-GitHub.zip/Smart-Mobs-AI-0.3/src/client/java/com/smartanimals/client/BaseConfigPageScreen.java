package com.smartanimals.client;

import com.smartanimals.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;


public abstract class BaseConfigPageScreen extends Screen {

    protected final SmartAnimalsConfigScreen parent;

    protected final BackgroundRenderer backgroundRenderer;

    protected final SmartAnimalsClientConfig clientConfig;

    protected boolean showBackButton = true;

    private static final int MAX_RIPPLES = 8;
    private final Ripple[] ripples = new Ripple[MAX_RIPPLES];

    private AbstractWidget pressedButton = null;

    protected float animationProgress = 0f;
    protected float backgroundTime = 0f;
    private long lastTime;

    protected static final int PANEL_INSET = 16;
    protected static final int TITLE_Y = 24;
    protected static final int CONTENT_TOP = 44;
    protected static final int FOOTER_TOP = 32;
    protected static final int SECTION_GAP = 12;
    protected static final int CONTROL_GAP = 6;
    protected static final int CARD_GAP = 10;
    protected static final int FOOTER_GAP = 8;
    protected static final int PAGE_MARGIN = PANEL_INSET;

    protected static final int GAP = CONTROL_GAP;

    protected static final int BUTTON_HEIGHT = 20;
    protected static final int BUTTON_WIDTH = 140;
    protected static final int SMALL_BUTTON_WIDTH = 96;
    protected static final int MEDIUM_BUTTON_WIDTH = 120;

    protected static final int SWATCH = 18;

    protected final List<AbstractWidget> pageWidgets = new ArrayList<>();


    protected SmartAnimalsConfigScreen getEffectiveParent() {
        if (parent != null) return parent;
        return (SmartAnimalsConfigScreen) this;
    }

    protected BaseConfigPageScreen(SmartAnimalsConfigScreen parent, Component title) {
        super(title);
        this.parent = parent;
        this.clientConfig = SmartAnimalsClientConfig.getInstance();
        this.backgroundRenderer = new BackgroundRenderer();
        for (int i = 0; i < MAX_RIPPLES; i++) {
            ripples[i] = new Ripple();
        }
        this.lastTime = System.currentTimeMillis();
    }


    protected final int contentTop() { return CONTENT_TOP; }
    protected final int contentBottom() { return height - FOOTER_TOP - FOOTER_GAP; }
    protected final int footerTop() { return height - FOOTER_TOP; }
    protected final int contentLeft() { return PANEL_INSET; }
    protected final int contentRight() { return width - PANEL_INSET; }
    protected final int contentWidth() { return width - 2 * PANEL_INSET; }

    protected final int centerX(int bw) { return contentLeft() + (contentWidth() - bw) / 2; }


    protected final Button addFooterButton(int rightEdgeX, int bw, int bh,
                                           Component message, Button.OnPress onPress) {
        return addPageButton(rightEdgeX - bw, footerTop(), bw, bh, message, onPress);
    }

    protected static final int BACK_X = PANEL_INSET;
    protected static final int BACK_Y = 12;

    @Override
    protected void init() {
        super.init();
        this.pageWidgets.clear();
        backgroundRenderer.setSize(this.width, this.height);

        if (showBackButton) {
            addPageButton(BACK_X, BACK_Y, SMALL_BUTTON_WIDTH, BUTTON_HEIGHT,
                    Component.translatable("gui.smartanimals.back"),
                    button -> onBackPressed());
        }

        createPageButtons();
    }


    protected abstract void createPageButtons();


    protected abstract void renderPageContent(
            GuiGraphics graphics,
            float alpha,
            float animationProgress,
            int mouseX, int mouseY,
            float partialTick
    );


    protected void onBackPressed() {
        playClickSound();
        this.minecraft.setScreen(parent);
    }


    @Override
    public void onClose() {
        if (parent != null) {
            playClickSound();
            this.minecraft.setScreen(parent);
        } else {
            super.onClose();
        }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        long currentTime = System.currentTimeMillis();
        float deltaTime = (currentTime - lastTime) / 1000f;
        lastTime = currentTime;

        animationProgress = Math.min(animationProgress + deltaTime * 2f, 1f);
        backgroundTime += deltaTime;
        backgroundRenderer.setTime(backgroundTime);

        float alpha = animationProgress >= 1.0f ? 1.0f : easeOutCubic(animationProgress);

        renderBlackFrame(graphics);

        backgroundRenderer.render(graphics, alpha, getEffectiveParent().currentBackgroundIndex);

        for (int i = 0; i < MAX_RIPPLES; i++) {
            if (ripples[i].active) {
                ripples[i].update(deltaTime);
                ripples[i].render(graphics, alpha);
            }
        }

        int titleColor = (int) (alpha * 255) << 24 | 0xFFFFFF;
        graphics.drawCenteredString(this.font, this.title, width / 2, TITLE_Y, titleColor);

        renderPageContent(graphics, alpha, animationProgress, mouseX, mouseY, partialTick);

        renderWidgets(graphics, mouseX, mouseY, partialTick, alpha);
    }

    private void renderWidgets(GuiGraphics graphics, int mouseX, int mouseY,
                               float partialTick, float alpha) {
        if (alpha < 0.5f) {
            for (AbstractWidget widget : pageWidgets) {
                widget.render(graphics, mouseX, mouseY, partialTick);
            }
            return;
        }
        for (AbstractWidget widget : pageWidgets) {
            if (widget instanceof Button btn && btn.isHovered()) {
                float scale = widget == pressedButton ? 0.94f : 0.96f;
                graphics.pose().pushPose();
                graphics.pose().translate(
                        btn.getX() + btn.getWidth() / 2.0,
                        btn.getY() + btn.getHeight() / 2.0,
                        0
                );
                graphics.pose().scale(scale, scale, scale);
                graphics.pose().translate(
                        -(btn.getX() + btn.getWidth() / 2.0),
                        -(btn.getY() + btn.getHeight() / 2.0),
                        0
                );
                widget.render(graphics, mouseX, mouseY, partialTick);
                graphics.pose().popPose();
            } else {
                widget.render(graphics, mouseX, mouseY, partialTick);
            }
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        boolean handled = super.mouseClicked(mouseX, mouseY, button);
        if (button == 0 && !handled) {
            createRipple((float) mouseX, (float) mouseY);
        }
        return handled;
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        pressedButton = null;
        return super.mouseReleased(mouseX, mouseY, button);
    }


    protected Button addPageButton(
            int x, int y, int width, int height,
            Component message,
            Button.OnPress onPress
    ) {
        Button btn = Button.builder(message, button -> {
            playClickSound();
            createRipple(
                    button.getX() + button.getWidth() / 2.0f,
                    button.getY() + button.getHeight() / 2.0f
            );
            pressedButton = button;
            onPress.onPress(button);
        })
        .pos(x, y)
        .size(width, height)
        .build();

        pageWidgets.add(btn);
        this.addRenderableWidget(btn);
        return btn;
    }


    protected <T extends AbstractWidget> T addPageWidget(T widget) {
        pageWidgets.add(widget);
        this.addRenderableWidget(widget);
        return widget;
    }

    private void createRipple(float x, float y) {
        for (int i = 0; i < MAX_RIPPLES; i++) {
            if (!ripples[i].active) {
                ripples[i].start(x, y);
                return;
            }
        }
        int oldest = 0;
        float minProgress = ripples[0].progress;
        for (int i = 1; i < MAX_RIPPLES; i++) {
            if (ripples[i].progress < minProgress) {
                minProgress = ripples[i].progress;
                oldest = i;
            }
        }
        ripples[oldest].start(x, y);
    }

    protected void playClickSound() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            mc.player.playSound(ModSounds.UI_CLICK, 0.5f, 1.0f);
        }
    }


    protected void renderBlackFrame(GuiGraphics graphics) {
        graphics.fill(0, 0, width, height, 0xCF000000);
        graphics.fill(0, 0, width, 2, 0xFF000000);
        graphics.fill(0, height - 2, width, height, 0xFF000000);
        graphics.fill(0, 0, 2, height, 0xFF000000);
        graphics.fill(width - 2, 0, width, height, 0xFF000000);
    }


    protected void renderSectionBox(
            GuiGraphics graphics,
            int x, int y, int w, int h,
            Component title,
            float alpha
    ) {
        int alpha255 = (int) (alpha * 255);
        int bgAlpha = (int) (alpha * 90) << 24;
        int borderAlpha = (alpha255 << 24) | 0xFFFFFF;
        int titleColor = (alpha255 << 24) | 0xFFFFFF;

        graphics.fill(x, y, x + w, y + h, bgAlpha | 0x000000);

        int bt = 1;
        graphics.fill(x, y, x + w, y + bt, borderAlpha);
        graphics.fill(x, y + h - bt, x + w, y + h, borderAlpha);
        graphics.fill(x, y, x + bt, y + h, borderAlpha);
        graphics.fill(x + w - bt, y, x + w, y + h, borderAlpha);

        graphics.drawString(this.font, title, x + 6, y + 4, titleColor, false);
    }

    private float easeOutCubic(float t) {
        return 1 - (float) Math.pow(1 - t, 3);
    }

    protected static final class Ripple {
        float x, y, progress;
        boolean active;

        Ripple() {
            this.active = false;
        }

        void start(float x, float y) {
            this.x = x;
            this.y = y;
            this.progress = 0f;
            this.active = true;
        }

        void update(float deltaTime) {
            if (!active) return;
            progress += deltaTime * 4.5f;
            if (progress >= 1.0f) active = false;
        }

        void render(GuiGraphics graphics, float alpha) {
            if (!active) return;
            float radius = progress * 90f;
            int ringAlpha = (int) (255 * alpha * 0.28f * (1f - progress));
            if (ringAlpha <= 0) return;
            int ringColor = (ringAlpha << 24) | 0xD4AF37;
            drawRippleRing(graphics, x, y, radius, ringColor);
        }

        private static void drawRippleRing(
                GuiGraphics graphics, float cx, float cy, float radius, int color
        ) {
            int r = (int) radius;
            int t = 3;
            if (r <= 0) return;
            int innerR = Math.max(0, r - t);
            graphics.fill((int) cx - r, (int) cy - r, (int) cx + r, (int) cy - innerR, color);
            graphics.fill((int) cx - r, (int) cy + innerR, (int) cx + r, (int) cy + r, color);
            graphics.fill((int) cx - r, (int) cy - innerR, (int) cx - innerR, (int) cy + innerR, color);
            graphics.fill((int) cx + innerR, (int) cy - innerR, (int) cx + r, (int) cy + innerR, color);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
