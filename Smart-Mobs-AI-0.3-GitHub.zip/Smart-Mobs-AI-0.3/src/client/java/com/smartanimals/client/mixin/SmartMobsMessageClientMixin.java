package com.smartanimals.client.mixin;

import com.smartanimals.client.SmartMobsHud;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Gui.class)
public class SmartMobsMessageClientMixin {

    @Unique
    private static final String MARKER =
            "[SMARTMOBS]";

    @Inject(
            method = "setOverlayMessage",
            at = @At("HEAD"),
            cancellable = true
    )
    private void smartAnimals$handleSmartMobsMessage(
            Component message,
            boolean animate,
            CallbackInfo ci
    ) {

        String text =
                message.getString();

        if (!text.startsWith(MARKER)) {
            return;
        }

        String cleanText = text.substring(MARKER.length()).trim();

        Component cleanedMessage = Component.literal(cleanText).withStyle(message.getStyle());

        SmartMobsHud.show(cleanedMessage);


        ci.cancel();
    }

    @Inject(
            method = "render",
            at = @At("TAIL")
    )
    private void smartAnimals$renderSmartMobsHud(
            GuiGraphics guiGraphics,
            float partialTick,
            CallbackInfo ci
    ) {

        SmartMobsHud.render(
                guiGraphics
        );
    }
}
