package com.smartanimals.client;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;

import java.io.IOException;
import java.io.InputStream;


public class BackgroundRenderer {

    private static final String KEY_PREFIX = "background.smartanimals.";

    public static final String[] BACKGROUND_NAMES = {
            "Animal Pen - Day",
            "Animal Pen - Sunset"
    };

    private static final String[] BACKGROUND_KEYS = {
            "animal_pen_day", "animal_pen_sunset"
    };


    private static final ResourceLocation[] TEXTURES = {
            new ResourceLocation("smartanimals", "textures/background/animal_pen_day.png"),
            new ResourceLocation("smartanimals", "textures/background/animal_pen_sunset.png")
    };

    private static final float ASPECT = 1920f / 1080f;


    private static boolean texturesRegistered = false;


    public static void registerTextures(TextureManager tm) {
        if (texturesRegistered) return;
        ResourceManager rm = Minecraft.getInstance().getResourceManager();
        if (rm == null) {
            return;
        }
        for (ResourceLocation rl : TEXTURES) {
            try (InputStream is = rm.open(rl)) {
                NativeImage img = NativeImage.read(is);
                DynamicTexture tex = new DynamicTexture(img);
                tm.register(rl, tex);
                tex.upload();
                System.out.println("[SmartAnimals] Background texture loaded: " + rl
                        + " (" + img.getWidth() + "x" + img.getHeight() + ")");
            } catch (IOException e) {
                System.err.println("[SmartAnimals] FAILED to load background texture: " + rl
                        + " — " + e.getClass().getSimpleName() + ": " + e.getMessage());
            } catch (RuntimeException e) {
                System.err.println("[SmartAnimals] GL/runtime error loading texture: " + rl
                        + " — " + e.getClass().getSimpleName() + ": " + e.getMessage());
            }
        }
        texturesRegistered = true;
    }

    public static String getBackgroundName(int index) {
        if (index < 0 || index >= BACKGROUND_NAMES.length) {
            index = 0;
        }
        return BACKGROUND_NAMES[index];
    }

    public static String getBackgroundKey(int index) {
        if (index < 0 || index >= BACKGROUND_KEYS.length) {
            index = 0;
        }
        return KEY_PREFIX + BACKGROUND_KEYS[index];
    }

    private int width;
    private int height;
    private float backgroundTime;

    public BackgroundRenderer() {
    }

    public void setSize(int width, int height) {
        this.width = Math.max(width, 1);
        this.height = Math.max(height, 1);
    }


    public void setTime(float backgroundTime) {
        this.backgroundTime = backgroundTime;
    }


    public void render(GuiGraphics graphics, float alpha, int backgroundIndex) {
        if (alpha <= 0f) {
            return;
        }

        if (!texturesRegistered) {
            TextureManager tm = Minecraft.getInstance().getTextureManager();
            if (tm != null) {
                registerTextures(tm);
            }
        }

        int idx = backgroundIndex;
        if (idx < 0 || idx >= TEXTURES.length) {
            idx = 0;
        }
        ResourceLocation tex = TEXTURES[idx];

        int w = width;
        int h = height;

        int drawW, drawH;
        if ((float) w / h >= ASPECT) {
            drawH = h;
            drawW = Math.round(h * ASPECT);
        } else {
            drawW = w;
            drawH = Math.round(w / ASPECT);
        }
        int sx = (w - drawW) / 2;
        int sy = (h - drawH) / 2;

        int col = ((int) (alpha * 255) << 24) | 0xFFFFFF;
        float r = ((col >> 16) & 0xFF) / 255f;
        float g = ((col >> 8) & 0xFF) / 255f;
        float b = (col & 0xFF) / 255f;
        float a = ((col >> 24) & 0xFF) / 255f;
        graphics.setColor(r, g, b, a);
        graphics.blit(tex, sx, sy, 0, 0f, 0f, drawW, drawH, drawW, drawH);
        graphics.setColor(1f, 1f, 1f, 1f);
    }
}
