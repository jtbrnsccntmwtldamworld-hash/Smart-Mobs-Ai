package com.smartanimals.client;


public final class MessageAppearance {

    private MessageAppearance() {
    }


    public static int getAlpha(int opacityPercent) {
        return Math.round(Math.max(0, Math.min(100, opacityPercent)) / 100.0f * 255f);
    }
}
