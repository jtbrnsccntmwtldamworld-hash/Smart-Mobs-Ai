package com.smartanimals.client;

import com.smartanimals.ai.PiglinBarterMenuType;
import com.smartanimals.ai.PiglinBarterScreen;
import com.smartanimals.network.SmartMobsClientNetwork;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.renderer.texture.TextureManager;

public class SmartAnimalsClient implements ClientModInitializer {

    private static boolean texturesRegistered = false;

    @Override
    public void onInitializeClient() {
        SmartMobsClientNetwork.register();
        SmartAnimalsClientConfig.getInstance();

        MenuScreens.register(
                PiglinBarterMenuType.PIGLIN_BARTER_MENU,
                PiglinBarterScreen::new
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!texturesRegistered) {
                TextureManager tm = client.getTextureManager();
                if (tm != null) {
                    BackgroundRenderer.registerTextures(tm);
                    texturesRegistered = true;
                }
            }
        });

    }
}
