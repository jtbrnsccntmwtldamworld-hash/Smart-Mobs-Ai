package com.smartanimals.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;


@net.fabricmc.api.Environment(net.fabricmc.api.EnvType.CLIENT)
public class MessagesPageScreen extends BaseConfigPageScreen {

    private AbstractSliderButton opacitySlider;
    private Button toggleButton;

    public MessagesPageScreen(SmartAnimalsConfigScreen parent) {
        super(parent, Component.translatable("gui.smartanimals.page_messages"));
    }

    @Override
    protected void createPageButtons() {
        int bw = BUTTON_WIDTH;
        int x = contentLeft();
        int y = contentTop();
        int gap = GAP;

        toggleButton = addPageButton(
                x, y, bw, BUTTON_HEIGHT,
                getToggleMessage(),
                button -> {
                    parent.messagesEnabled = !parent.messagesEnabled;
                    parent.markDirty();
                    toggleButton.setMessage(getToggleMessage());
                }
        );

        double normalized = parent.currentMessageOpacity / 100.0;
        opacitySlider = new AbstractSliderButton(
                x, y + BUTTON_HEIGHT + gap, bw, BUTTON_HEIGHT - 4,
                Component.literal(""),
                normalized
        ) {
            @Override
            protected void updateMessage() {
                int pct = (int) Math.round(this.value * 100);
                this.setMessage(Component.translatable(
                        "gui.smartanimals.message_opacity", pct));
            }

            @Override
            protected void applyValue() {
                int pct = (int) Math.round(this.value * 100);
                parent.currentMessageOpacity = pct;
                parent.applyOpacity();
                parent.markDirty();
            }
        };
        addPageWidget(opacitySlider);

        addFooterButton(contentRight(), MEDIUM_BUTTON_WIDTH, BUTTON_HEIGHT,
                Component.translatable("gui.smartanimals.apply"),
                button -> {
                    parent.applySettings();
                    parent.markDirty();
                });
    }

    private Component getToggleMessage() {
        return Component.translatable(
                parent.messagesEnabled
                        ? "gui.smartanimals.messages_on"
                        : "gui.smartanimals.messages_off"
        );
    }

    @Override
    protected void renderPageContent(
            GuiGraphics graphics,
            float alpha,
            float animationProgress,
            int mouseX, int mouseY,
            float partialTick
    ) {
        int alpha255 = (int) (alpha * 255);

        int boxW = 250, boxH = 72;
        int boxX = centerX(boxW);
        int boxY = contentTop() + BUTTON_HEIGHT + GAP + (BUTTON_HEIGHT - 4) + 26;
        if (boxY + boxH + 18 > contentBottom()) {
            boxY = contentBottom() - boxH - 18;
        }

        renderSectionBox(graphics, boxX, boxY, boxW, boxH,
                Component.translatable("gui.smartanimals.message_preview"), alpha);

        int innerX = boxX + 8;
        int innerY = boxY + 16;
        int innerW = boxW - 16;
        int innerH = 28;

        int bgAlpha = (int) (alpha * 60) << 24;
        graphics.fill(innerX, innerY, innerX + innerW, innerY + innerH,
                bgAlpha | 0x000000);

        int borderColor = (alpha255 << 24) | 0xCCCCCC;
        graphics.fill(innerX, innerY, innerX + innerW, innerY + 1, borderColor);
        graphics.fill(innerX, innerY + innerH - 1, innerX + innerW, innerY + innerH, borderColor);
        graphics.fill(innerX, innerY, innerX + 1, innerY + innerH, borderColor);
        graphics.fill(innerX + innerW - 1, innerY, innerX + innerW, innerY + innerH, borderColor);

        int currentColor = parent.getEffectiveColor();
        Minecraft mc = Minecraft.getInstance();
        Font previewFont = mc.font;

        int effectiveAlpha = MessageAppearance.getAlpha(parent.currentMessageOpacity);
        int previewColor = (currentColor & 0x00FFFFFF) | (effectiveAlpha << 24);

        Component previewText = Component.literal("Sample message text");
        int textWidth = previewFont.width(previewText);
        int textX = innerX + (innerW - textWidth) / 2;
        int textY = innerY + (innerH - previewFont.lineHeight) / 2;

        graphics.drawString(previewFont, previewText, textX, textY, previewColor, true);


    }
}
