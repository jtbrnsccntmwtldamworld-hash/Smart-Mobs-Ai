package com.smartanimals.client;

import net.fabricmc.loader.api.FabricLoader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;


public class SmartAnimalsClientConfig {


    private static final Logger LOGGER =
            LogManager.getLogger();

    private static final String CONFIG_FILE_NAME =
            "smartanimals-client.properties";


    private static final int COLOR_COUNT = PresetColor.COLORS.length;
    private static final int BACKGROUND_COUNT = BackgroundRenderer.BACKGROUND_NAMES.length;

    private static SmartAnimalsClientConfig instance;

    public static final boolean DEFAULT_MESSAGES_ENABLED = true;
    public static final int DEFAULT_COLOR_INDEX = 0;
    public static final int DEFAULT_CUSTOM_COLOR = -1;
    public static final int DEFAULT_FONT_INDEX = 0;
    public static final int DEFAULT_MESSAGE_OPACITY = 100;
    public static final int DEFAULT_HUD_TRANSPARENCY = 100;
    public static final int DEFAULT_BACKGROUND_INDEX = 0;

    private int backgroundIndex = 0;
    private int colorIndex = 0;
    private int fontIndex = 0;
    private int messageOpacity = 100;
    private boolean messagesEnabled = true;
    private int hudTransparency = 100;
    private int customColorValue = -1;


    private boolean loaded = false;

    private SmartAnimalsClientConfig() {
    }

    public static SmartAnimalsClientConfig getInstance() {
        if (instance == null) {
            instance = new SmartAnimalsClientConfig();
            instance.load();
        }
        return instance;
    }


    public int getBackgroundIndex() {
        return backgroundIndex;
    }

    public void setBackgroundIndex(int backgroundIndex) {
        int clamped = Math.max(0, Math.min(BACKGROUND_COUNT - 1, backgroundIndex));
        this.backgroundIndex = clamped;
    }

    public int getColorIndex() {
        return colorIndex;
    }

    public void setColorIndex(int colorIndex) {
        int clamped = Math.max(0, Math.min(COLOR_COUNT - 1, colorIndex));
        this.colorIndex = clamped;
    }

    public int getFontIndex() {
        return fontIndex;
    }

    public void setFontIndex(int fontIndex) {
        this.fontIndex = Math.max(0, fontIndex);
    }

    public int getMessageOpacity() {
        return messageOpacity;
    }

    public void setMessageOpacity(int messageOpacity) {
        int clamped = Math.max(0, Math.min(100, messageOpacity));
        this.messageOpacity = clamped;
        this.hudTransparency = clamped;
    }

    public boolean isMessagesEnabled() {
        return messagesEnabled;
    }

    public void setMessagesEnabled(boolean messagesEnabled) {
        this.messagesEnabled = messagesEnabled;
    }

    public int getCustomColor() {
        return customColorValue;
    }

    public void setCustomColor(int customColorValue) {
        int clamped = customColorValue < 0
                ? -1
                : (customColorValue & 0x00FFFFFF);
        this.customColorValue = clamped;
    }

    public int getHudTransparency() {
        return hudTransparency;
    }

    public void setHudTransparency(int hudTransparency) {
        int clamped = Math.max(0, Math.min(100, hudTransparency));
        this.hudTransparency = clamped;
    }


    public int getEffectiveColor() {
        if (customColorValue >= 0) {
            return customColorValue & 0x00FFFFFF;
        }
        int idx = Math.max(0, Math.min(COLOR_COUNT - 1, colorIndex));
        return PresetColor.COLORS[idx];
    }

    public boolean isLoaded() {
        return loaded;
    }


    public void applyServerSettings(
            boolean enabled,
            int color,
            int colorIndex,
            int customColor,
            int fontIndex,
            int opacity,
            int backgroundIndex
    ) {
        this.messagesEnabled = enabled;
        this.customColorValue = customColor;
        this.colorIndex = Math.max(0, Math.min(COLOR_COUNT - 1, colorIndex));
        this.fontIndex = Math.max(0, fontIndex);
        this.backgroundIndex = Math.max(0, Math.min(BACKGROUND_COUNT - 1, backgroundIndex));
        this.messageOpacity = Math.max(0, Math.min(100, opacity));
        this.hudTransparency = this.messageOpacity;

        loaded = true;

        SmartMobsHud.setHudTransparency(messageOpacity);
    }


    private static Path configPath() {
        return FabricLoader.getInstance()
                .getConfigDir()
                .resolve(CONFIG_FILE_NAME);
    }


    /**
     * Loads persisted client settings from
     * {@code config/smartanimals-client.properties} (if present) into the
     * in-memory fields. Called once from {@link #getInstance()}.
     * <p>
     * On a missing or unreadable file the field defaults are kept and the
     * method returns silently, so a first launch behaves exactly as before.
     * The server-sync flag {@link #loaded} is intentionally left untouched:
     * when a world is joined the client still asks the (integrated) server for
     * the authoritative values, while the on-disk copy makes settings survive
     * a full Minecraft restart even when configured from the title screen
     * (where {@code minecraft.player == null} and no server is available).
     */
    private void load() {
        Properties props = new Properties();
        Path path = configPath();
        try (InputStream in = Files.newInputStream(path)) {
            props.load(in);
        } catch (Exception e) {
            return;
        }

        setMessagesEnabled(
                parseBool(
                        props.getProperty("messages"),
                        DEFAULT_MESSAGES_ENABLED
                )
        );
        setColorIndex(
                parseInt(
                        props.getProperty("color_index"),
                        DEFAULT_COLOR_INDEX
                )
        );
        setCustomColor(
                parseInt(
                        props.getProperty("custom_color"),
                        DEFAULT_CUSTOM_COLOR
                )
        );
        setFontIndex(
                parseInt(
                        props.getProperty("font_index"),
                        DEFAULT_FONT_INDEX
                )
        );
        setBackgroundIndex(
                parseInt(
                        props.getProperty("background_index"),
                        DEFAULT_BACKGROUND_INDEX
                )
        );

        int opacity = parseInt(
                props.getProperty("opacity"),
                DEFAULT_MESSAGE_OPACITY
        );
        setMessageOpacity(opacity);
        setHudTransparency(opacity);

        SmartMobsHud.setHudTransparency(messageOpacity);
    }


    /**
     * Writes every Mod Menu setting to disk so it survives a full Minecraft
     * restart. Called from {@code SmartAnimalsConfigScreen.saveSettings()}.
     */
    public void save() {
        Properties props = new Properties();
        props.setProperty("messages", Boolean.toString(messagesEnabled));
        props.setProperty("color_index", Integer.toString(colorIndex));
        props.setProperty("custom_color", Integer.toString(customColorValue));
        props.setProperty("font_index", Integer.toString(fontIndex));
        props.setProperty("background_index", Integer.toString(backgroundIndex));
        props.setProperty("opacity", Integer.toString(messageOpacity));
        props.setProperty("transparency", Integer.toString(hudTransparency));

        Path path = configPath();
        try {
            Files.createDirectories(path.getParent());
            try (OutputStream out = Files.newOutputStream(path)) {
                props.store(out, "Smart Animals client settings");
            }
        } catch (Exception e) {
            LOGGER.warn("Could not save Smart Animals client config to {}", path, e);
        }
    }


    private static boolean parseBool(String value, boolean fallback) {
        if (value == null) {
            return fallback;
        }
        String trimmed = value.trim();
        if ("true".equalsIgnoreCase(trimmed)) {
            return true;
        }
        if ("false".equalsIgnoreCase(trimmed)) {
            return false;
        }
        return fallback;
    }

    private static int parseInt(String value, int fallback) {
        if (value == null) {
            return fallback;
        }
        try {
            return Integer.parseInt(value.trim());
        } catch (Exception e) {
            return fallback;
        }
    }
}
