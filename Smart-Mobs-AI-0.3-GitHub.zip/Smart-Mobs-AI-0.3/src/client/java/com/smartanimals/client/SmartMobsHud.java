package com.smartanimals.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;

public class SmartMobsHud {

    private static Component message;
    private static Integer lastMessageColor = null;
    private static int cachedTextWidth = 0;


    private static int hudTransparency = 100;



    private static boolean textWidthCached = false;

    private static long messageEndTime;

    private static int cachedX = 0;
    private static int cachedY = 0;
    private static boolean coordinatesValid = false;


    private static int cachedScreenWidth = 0;
    private static int cachedScreenHeight = 0;


    private static final long DISPLAY_TIME = 2500L;


    private static final float SCALE = 0.70F;

    private SmartMobsHud() {
    }


    public static void setHudTransparency(int transparency) {
        hudTransparency = Math.max(0, Math.min(100, transparency));
    }

    public static int getHudTransparency() {
        return hudTransparency;
    }


    public static void show(
            Component component
    ) {
        Style style = component.getStyle();
        int currentColor = 0xFFFFFF;
        if (style != null && style.getColor() != null) {
            currentColor = style.getColor().getValue();
        }

        message = component;
        lastMessageColor = currentColor;
        cachedTextWidth = 0;
        textWidthCached = false;
        coordinatesValid = false;
        cachedScreenWidth = 0;

        messageEndTime =
                System.nanoTime()
                        + DISPLAY_TIME
                        * 1_000_000L;
    }


    public static void render(
            GuiGraphics guiGraphics
    ) {

        if (message == null) {
            return;
        }

        long currentTime = System.nanoTime();


        if (currentTime >= messageEndTime) {
            message = null;
            lastMessageColor = null;
            cachedTextWidth = 0;
            textWidthCached = false;
            coordinatesValid = false;
            cachedScreenWidth = 0;
            return;
        }

        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.font == null) {
            return;
        }

        Font renderFont = minecraft.font;

        int screenWidth = minecraft.getWindow().getGuiScaledWidth();
        int screenHeight = minecraft.getWindow().getGuiScaledHeight();


        if (screenWidth != cachedScreenWidth
                || screenHeight != cachedScreenHeight) {

            coordinatesValid = false;
            cachedScreenWidth = screenWidth;
            cachedScreenHeight = screenHeight;
        }

        if (!textWidthCached) {
            cachedTextWidth = minecraft.font.width(message);
            textWidthCached = true;
        }

        if (!coordinatesValid) {
            cachedX = (int) (
                    (screenWidth - 12)
                            / SCALE
                            - cachedTextWidth
            );
            cachedY = (int) (
                    (screenHeight - 35)
                            / SCALE
            );
            coordinatesValid = true;
        }


        guiGraphics.pose().pushPose();

        guiGraphics.pose().scale(
                SCALE,
                SCALE,
                SCALE
        );


        int textColor = lastMessageColor != null
                ? lastMessageColor
                : 0xFFFFFF;

        int alpha = MessageAppearance.getAlpha(hudTransparency);
        textColor = (textColor & 0x00FFFFFF) | (alpha << 24);

        guiGraphics.drawString(
                renderFont,
                message,
                cachedX,
                cachedY,
                textColor,
                true
        );


        guiGraphics.pose().popPose();
    }
}
