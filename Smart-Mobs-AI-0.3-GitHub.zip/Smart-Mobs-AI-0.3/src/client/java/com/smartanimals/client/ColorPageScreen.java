package com.smartanimals.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.function.IntFunction;


@net.fabricmc.api.Environment(net.fabricmc.api.EnvType.CLIENT)
public class ColorPageScreen extends BaseConfigPageScreen {

    private boolean showingPresets = true;

    private static final int SWATCH_SIZE = 16;
    private static final int SWATCH_SPACING = 6;
    private static final int MIN_COLS = 4;
    private static final int MAX_COLS = 8;

    private float hsvHue = 0f;
    private float hsvSat = 0.5f;
    private float hsvVal = 1.0f;

    private int draggingSlider = 0;

    private Button setColorButton;

    private static final class SwatchPos {
        final int colorIndex;
        final int x;
        final int y;
        SwatchPos(int ci, int x, int y) { this.colorIndex = ci; this.x = x; this.y = y; }
    }
    private final List<SwatchPos> swatchPositions = new ArrayList<>();

    private int gridLeft, gridTop, gridW, gridBottom, cols, rowH;

    public ColorPageScreen(SmartAnimalsConfigScreen parent) {
        super(parent, Component.translatable("gui.smartanimals.page_color"));
    }

    @Override
    protected void init() {
        super.init();
        computeSwatchPositions();
    }


    private void computeSwatchPositions() {
        swatchPositions.clear();
        int count = PresetColor.PRESET_COLORS.length;
        int colW = SWATCH_SIZE + SWATCH_SPACING;
        cols = Math.max(MIN_COLS, Math.min(MAX_COLS, (contentWidth() + SWATCH_SPACING) / colW));
        gridW = cols * SWATCH_SIZE + (cols - 1) * SWATCH_SPACING;
        gridLeft = centerX(gridW);
        gridTop = contentTop() + BUTTON_HEIGHT + GAP;
        rowH = SWATCH_SIZE + SWATCH_SPACING;
        int rows = (count + cols - 1) / cols;
        gridBottom = gridTop + rows * rowH;
        if (gridBottom > contentBottom()) {
            gridBottom = contentBottom();
        }
        for (int i = 0; i < count; i++) {
            int row = i / cols;
            int col = i % cols;
            int sx = gridLeft + col * colW;
            int sy = gridTop + row * rowH;
            swatchPositions.add(new SwatchPos(i, sx, sy));
        }
    }

    @Override
    protected void createPageButtons() {
        int tabW = 96, tabH = BUTTON_HEIGHT;
        int cx = centerX(tabW * 2 + GAP);

        addPageButton(cx, contentTop(), tabW, tabH,
                Component.translatable("gui.smartanimals.tab_preset"),
                button -> {
                    showingPresets = true;
                    setColorButton.visible = false;
                });
        addPageButton(cx + tabW + GAP, contentTop(), tabW, tabH,
                Component.translatable("gui.smartanimals.tab_custom"),
                button -> {
                    showingPresets = false;
                    initHsvFromCurrentColor();
                    setColorButton.visible = true;
                });

        setColorButton = addFooterButton(contentRight(), MEDIUM_BUTTON_WIDTH, BUTTON_HEIGHT,
                Component.translatable("gui.smartanimals.set_color"),
                button -> {
                    setCustomColor();
                    playClickSound();
                });
        setColorButton.visible = !showingPresets;
    }

    private void initHsvFromCurrentColor() {
        int rgb = parent.getEffectiveColor();
        float[] hsv = Color.RGBtoHSB(
                (rgb >> 16) & 0xFF,
                (rgb >> 8) & 0xFF,
                rgb & 0xFF,
                null
        );
        hsvHue = hsv[0];
        hsvSat = hsv[1];
        hsvVal = hsv[2];
    }

    private int hsvToRgb() {
        return Color.HSBtoRGB(hsvHue, hsvSat, hsvVal) & 0x00FFFFFF;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        boolean handled = super.mouseClicked(mouseX, mouseY, button);
        if (handled) return true;

        if (showingPresets) {
            return handleClickGrid((int) mouseX, (int) mouseY);
        } else {
            return handleClickSlider((int) mouseX, (int) mouseY);
        }
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        if (showingPresets) return super.mouseDragged(mouseX, mouseY, button, dx, dy);

        if (draggingSlider > 0) {
            updateSliderFromMouse(mouseX, draggingSlider);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        draggingSlider = 0;
        return super.mouseReleased(mouseX, mouseY, button);
    }


    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollDelta) {
        return false;
    }


    private boolean handleClickGrid(int mx, int my) {
        for (SwatchPos sp : swatchPositions) {
            if (sp.y + SWATCH_SIZE > contentBottom()) continue;
            if (mx >= sp.x && mx <= sp.x + SWATCH_SIZE
                    && my >= sp.y && my <= sp.y + SWATCH_SIZE) {
                selectPreset(sp.colorIndex);
                playClickSound();
                return true;
            }
        }
        return false;
    }

    private void selectPreset(int index) {
        parent.currentColorIndex = index;
        parent.customColorValue = -1;
        parent.markDirty();
        parent.applyColor();
    }

    private boolean handleClickSlider(int mx, int my) {
        int sliderX = centerX(BUTTON_WIDTH);

        if (mx >= sliderX && mx <= sliderX + BUTTON_WIDTH
                && my >= sliderY(1) && my <= sliderY(1) + 12) {
            updateSliderFromMouse(mx, 1);
            draggingSlider = 1;
            return true;
        }
        if (mx >= sliderX && mx <= sliderX + BUTTON_WIDTH
                && my >= sliderY(2) && my <= sliderY(2) + 12) {
            updateSliderFromMouse(mx, 2);
            draggingSlider = 2;
            return true;
        }
        if (mx >= sliderX && mx <= sliderX + BUTTON_WIDTH
                && my >= sliderY(3) && my <= sliderY(3) + 12) {
            updateSliderFromMouse(mx, 3);
            draggingSlider = 3;
            return true;
        }
        return false;
    }

    private int sliderY(int which) {
        return contentTop() + 28 + (which - 1) * (12 + GAP);
    }

    private void updateSliderFromMouse(double mouseX, int which) {
        int sliderX = centerX(BUTTON_WIDTH);
        float frac = (float) (mouseX - sliderX) / BUTTON_WIDTH;
        frac = Math.max(0f, Math.min(1f, frac));
        switch (which) {
            case 1 -> hsvHue = frac;
            case 2 -> hsvSat = frac;
            case 3 -> hsvVal = frac;
        }
    }

    private void setCustomColor() {
        parent.customColorValue = hsvToRgb();
        parent.markDirty();
        parent.applyColor();
    }

    @Override
    protected void renderPageContent(
            GuiGraphics graphics,
            float alpha,
            float animationProgress,
            int mouseX, int mouseY,
            float partialTick
    ) {
        if (showingPresets) {
            renderPresetGrid(graphics, alpha, mouseX, mouseY);
        } else {
            renderHsvPicker(graphics, alpha, mouseX, mouseY);
        }
    }


    private void renderPresetGrid(GuiGraphics graphics, float alpha, int mx, int my) {
        int alpha255 = (int) (alpha * 255);
        int pad = 4;

        graphics.fill(gridLeft - pad, gridTop - pad,
                gridLeft + gridW + pad, gridBottom + pad,
                (int) (alpha * 70) << 24);
        int borderCol = (alpha255 << 24) | 0x888888;
        graphics.fill(gridLeft - pad, gridTop - pad, gridLeft + gridW + pad, gridTop - pad + 1, borderCol);
        graphics.fill(gridLeft - pad, gridBottom + pad - 1, gridLeft + gridW + pad, gridBottom + pad, borderCol);
        graphics.fill(gridLeft - pad, gridTop - pad, gridLeft - pad + 1, gridBottom + pad, borderCol);
        graphics.fill(gridLeft + gridW + pad - 1, gridTop - pad, gridLeft + gridW + pad, gridBottom + pad, borderCol);

        int hovered = -1;
        for (SwatchPos sp : swatchPositions) {
            if (sp.y + SWATCH_SIZE > contentBottom()) continue;

            boolean isSelected = parent.customColorValue < 0 && parent.currentColorIndex == sp.colorIndex;
            boolean isHovered = mx >= sp.x && mx <= sp.x + SWATCH_SIZE
                    && my >= sp.y && my <= sp.y + SWATCH_SIZE;
            if (isHovered) hovered = sp.colorIndex;

            int swatchBorder = (alpha255 << 24) | (isSelected ? 0xD4AF37 : (isHovered ? 0xFFFFFF : 0x888888));
            graphics.fill(sp.x - 1, sp.y - 1,
                    sp.x + SWATCH_SIZE + 1, sp.y + SWATCH_SIZE + 1, swatchBorder);

            int color = PresetColor.COLORS[sp.colorIndex];
            graphics.fill(sp.x, sp.y,
                    sp.x + SWATCH_SIZE, sp.y + SWATCH_SIZE,
                    (alpha255 << 24) | color);
        }

        int statusY = gridBottom + GAP;
        if (hovered >= 0 && statusY + this.font.lineHeight <= contentBottom()) {
            String name = PresetColor.COLOR_NAMES[hovered];
            int maxW = contentWidth() - GAP * 2;
            String shown = fitWidth(name, maxW);
            int tw = this.font.width(shown);
            int labelX = contentLeft() + (contentWidth() - tw) / 2;
            graphics.drawString(this.font, shown, labelX, statusY,
                    (alpha255 << 24) | 0xCCCCCC, false);
        }
    }

    private String fitWidth(String text, int maxWidth) {
        if (this.font.width(text) <= maxWidth) return text;
        String ellipsis = "...";
        int limit = text.length();
        while (limit > 0 && this.font.width(text.substring(0, limit) + ellipsis) > maxWidth) {
            limit--;
        }
        return limit == 0 ? ellipsis : text.substring(0, limit) + ellipsis;
    }

    @SuppressWarnings("unchecked")
    private void renderHsvPicker(GuiGraphics graphics, float alpha, int mx, int my) {
        int alpha255 = (int) (alpha * 255);
        int sliderW = BUTTON_WIDTH;
        int sliderX = centerX(sliderW);

        String[] labels = {"gui.smartanimals.hue", "gui.smartanimals.saturation", "gui.smartanimals.brightness"};
        IntFunction<Integer> hueFn = this::hueColorAt;
        IntFunction<Integer> satFn = this::satColorAt;
        IntFunction<Integer> briFn = this::briColorAt;
        IntFunction<Integer>[] fns = new IntFunction[]{hueFn, satFn, briFn};
        for (int i = 0; i < 3; i++) {
            int y = sliderY(i + 1);
            renderSliderBar(graphics, sliderX, y, sliderW, 12, alpha, fns[i]);
            int knobX = sliderX + (int) (new float[]{hsvHue, hsvSat, hsvVal}[i] * sliderW) - 4;
            graphics.fill(knobX, y - 2, knobX + 8, y + 14,
                    (alpha255 << 24) | 0xFFFFFF);
            graphics.drawString(this.font,
                    Component.translatable(labels[i]),
                    sliderX + sliderW + 6, y + 3,
                    (alpha255 << 24) | 0xCCCCCC, false);
        }

        int swatchSize = 42;
        int swatchX = centerX(swatchSize);
        int swatchY = sliderY(4) + 18;
        graphics.fill(swatchX - 2, swatchY - 2,
                swatchX + swatchSize + 2, swatchY + swatchSize + 2,
                (alpha255 << 24) | 0xFFFFFF);
        int rgb = hsvToRgb();
        graphics.fill(swatchX, swatchY,
                swatchX + swatchSize, swatchY + swatchSize,
                (int) (alpha * 255) << 24 | rgb);

        int r = (rgb >> 16) & 0xFF, g = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
        String hex = String.format("#%02X%02X%02X", r, g, b);
        graphics.drawCenteredString(this.font,
                Component.literal(hex),
                swatchX + swatchSize / 2, swatchY + swatchSize + 6,
                (alpha255 << 24) | 0xCCCCCC);
    }


    private void renderSliderBar(
            GuiGraphics graphics,
            int x, int y, int w, int h, float alpha,
            IntFunction<Integer> colorFunc
    ) {
        int fillA = (int) (alpha * 180) << 24;
        for (int i = 0; i < w; i++) {
            float frac = (float) i / (w - 1);
            int color = colorFunc.apply((int) (frac * 100));
            graphics.fill(x + i, y, x + i + 1, y + h, fillA | color);
        }
        graphics.fill(x, y, x + w, y + 1, (int)(alpha * 255) << 24 | 0xFFFFFF);
        graphics.fill(x, y + h - 1, x + w, y + h, (int)(alpha * 255) << 24 | 0xFFFFFF);
    }

    private int hueColorAt(int pct) {
        return Color.HSBtoRGB(pct / 100.0f, 1.0f, 1.0f) & 0x00FFFFFF;
    }

    private int satColorAt(int pct) {
        return Color.HSBtoRGB(hsvHue, pct / 100.0f, 1.0f) & 0x00FFFFFF;
    }

    private int briColorAt(int pct) {
        return Color.HSBtoRGB(hsvHue, hsvSat, pct / 100.0f) & 0x00FFFFFF;
    }
}
