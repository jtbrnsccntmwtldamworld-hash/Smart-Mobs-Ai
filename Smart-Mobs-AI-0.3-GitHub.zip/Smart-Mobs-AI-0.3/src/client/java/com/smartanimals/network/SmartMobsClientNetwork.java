package com.smartanimals.network;

import com.smartanimals.client.SmartAnimalsClientConfig;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;

import io.netty.buffer.Unpooled;

import java.util.function.Consumer;


public class SmartMobsClientNetwork {

    public static final ResourceLocation GET_SETTINGS_PACKET =
            new ResourceLocation(
                    "smartanimals",
                    "get_settings"
            );

    public static final ResourceLocation SETTINGS_RESPONSE_PACKET =
            new ResourceLocation(
                    "smartanimals",
                    "settings_response"
            );

    public static final ResourceLocation SET_SETTINGS_PACKET =
            new ResourceLocation(
                    "smartanimals",
                    "set_settings"
            );


    private static volatile Consumer<SettingsData> settingsCallback;

    private SmartMobsClientNetwork() {
    }

    public static void register() {
        ClientPlayNetworking.registerGlobalReceiver(
                SETTINGS_RESPONSE_PACKET,
                (client, handler, buf, responseSender) -> {

                    boolean enabled = buf.readBoolean();
                    int color = buf.readInt();
                    int colorIndex = buf.readInt();
                    int customColor = buf.readInt();
                    int fontIndex = buf.readInt();
                    int opacity = buf.readInt();
                    int backgroundIndex = buf.readInt();

                    client.execute(() -> {


                        SmartAnimalsClientConfig config =
                                SmartAnimalsClientConfig.getInstance();

                        config.applyServerSettings(
                                enabled,
                                color,
                                colorIndex,
                                customColor,
                                fontIndex,
                                opacity,
                                backgroundIndex
                        );

                        Consumer<SettingsData> callback =
                                settingsCallback;

                        if (callback != null) {
                            settingsCallback = null;
                            callback.accept(new SettingsData(
                                    enabled,
                                    color,
                                    colorIndex,
                                    customColor,
                                    fontIndex,
                                    opacity,
                                    backgroundIndex
                            ));
                        }
                    });
                }
        );
    }


    public static void requestSettings(
            Consumer<SettingsData> callback
    ) {


        if (!ClientPlayNetworking.canSend(GET_SETTINGS_PACKET)) {
            return;
        }

        settingsCallback = callback;

        ClientPlayNetworking.send(
                GET_SETTINGS_PACKET,
                new FriendlyByteBuf(Unpooled.buffer())
        );
    }


    public static void sendSettings(
            boolean enabled,
            int color,
            int colorIndex,
            int customColor,
            int fontIndex,
            int opacity,
            int backgroundIndex
    ) {

        if (!ClientPlayNetworking.canSend(SET_SETTINGS_PACKET)) {
            return;
        }

        FriendlyByteBuf buf =
                new FriendlyByteBuf(
                        Unpooled.buffer()
                );

        buf.writeBoolean(enabled);
        buf.writeInt(color);
        buf.writeInt(colorIndex);
        buf.writeInt(customColor);
        buf.writeInt(fontIndex);
        buf.writeInt(opacity);
        buf.writeInt(backgroundIndex);

        ClientPlayNetworking.send(
                SET_SETTINGS_PACKET,
                buf
        );
    }

    public static final class SettingsData {
        public final boolean enabled;
        public final int color;
        public final int colorIndex;
        public final int customColor;
        public final int fontIndex;
        public final int opacity;
        public final int backgroundIndex;

        public SettingsData(
                boolean enabled,
                int color,
                int colorIndex,
                int customColor,
                int fontIndex,
                int opacity,
                int backgroundIndex
        ) {
            this.enabled = enabled;
            this.color = color;
            this.colorIndex = colorIndex;
            this.customColor = customColor;
            this.fontIndex = fontIndex;
            this.opacity = opacity;
            this.backgroundIndex = backgroundIndex;
        }
    }
}
