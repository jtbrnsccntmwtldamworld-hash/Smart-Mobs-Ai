package com.smartanimals.ai;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ServerboundContainerButtonClickPacket;
import net.minecraft.world.entity.player.Inventory;

public class PiglinBarterScreen
        extends AbstractContainerScreen<PiglinBarterMenu> {



    private static final int GUI_WIDTH = 220;
    private static final int GUI_HEIGHT = 230;



    private static final int BACKGROUND = 0xFF0B0809;
    private static final int PANEL = 0xFF1B1214;
    private static final int PANEL_DARK = 0xFF120C0E;

    private static final int GOLD_DARK = 0xFF70451D;
    private static final int GOLD = 0xFFC98A3D;
    private static final int GOLD_LIGHT = 0xFFFFD978;

    private static final int GRID_DARK = 0xFF211416;

    private static final int TEXT_DARK = 0xFF8D7669;

    private static final int GREEN = 0xFF70D879;
    private static final int ORANGE = 0xFFFFA33B;
    private static final int RED = 0xFFE05252;

    private Button previousButton;
    private Button nextButton;

    public PiglinBarterScreen(
            PiglinBarterMenu menu,
            Inventory inventory,
            Component title
    ) {

        super(menu, inventory, title);

        imageWidth = GUI_WIDTH;
        imageHeight = GUI_HEIGHT;

        titleLabelX = -1000;
        titleLabelY = -1000;

        inventoryLabelX = -1000;
        inventoryLabelY = -1000;
    }

    @Override
    protected void init() {

        super.init();



        previousButton =
                new PiglinArrowButton(
                        leftPos + 25,
                        topPos + 76,
                        "<",
                        button -> changePage(-1)
                );

        nextButton =
                new PiglinArrowButton(
                        leftPos + GUI_WIDTH - 45,
                        topPos + 76,
                        ">",
                        button -> changePage(1)
                );

        addRenderableWidget(previousButton);
        addRenderableWidget(nextButton);

        updateButtons();
    }

    private void changePage(int direction) {

        int page =
                menu.getCurrentPage()
                        + direction;

        if (page < 0
                || page >= PiglinBarterMenu.PAGE_COUNT) {

            return;
        }



        if (net.minecraft.client.Minecraft
                .getInstance()
                .getConnection() != null) {

            net.minecraft.client.Minecraft
                    .getInstance()
                    .getConnection()
                    .send(
                            new ServerboundContainerButtonClickPacket(
                                    menu.containerId,
                                    page
                            )
                    );
        }

        menu.setCurrentPage(page);

        updateButtons();
    }

    private void updateButtons() {

        if (previousButton != null) {

            previousButton.active =
                    menu.getCurrentPage() > 0;
        }

        if (nextButton != null) {
            nextButton.active =
                    menu.getCurrentPage()
                            < PiglinBarterMenu.PAGE_COUNT - 1;
        }
    }

    @Override
    public void render(
            GuiGraphics g,
            int mouseX,
            int mouseY,
            float partialTick
    ) {

        renderBackground(g);

        super.render(
                g,
                mouseX,
                mouseY,
                partialTick
        );

        renderHeader(g);
        renderTradeInformation(g);
        renderDecorations(g);

        renderTooltip(
                g,
                mouseX,
                mouseY
        );
    }

    @Override
    protected void renderBg(
            GuiGraphics g,
            float partialTick,
            int mouseX,
            int mouseY
    ) {

        int left = leftPos;
        int top = topPos;



        g.fill(
                left,
                top,
                left + GUI_WIDTH,
                top + GUI_HEIGHT,
                BACKGROUND
        );

        g.fill(
                left + 4,
                top + 4,
                left + GUI_WIDTH - 4,
                top + GUI_HEIGHT - 4,
                PANEL
        );



        g.fill(
                left + 10,
                top + 9,
                left + GUI_WIDTH - 10,
                top + 37,
                PANEL_DARK
        );

        drawPanelFrame(
                g,
                left + 10,
                top + 9,
                GUI_WIDTH - 20,
                28
        );



        g.fill(
                left + 20,
                top + 45,
                left + GUI_WIDTH - 20,
                top + 112,
                PANEL_DARK
        );

        drawPanelFrame(
                g,
                left + 20,
                top + 45,
                GUI_WIDTH - 40,
                67
        );



        g.fill(
                left + 20,
                top + 128,
                left + GUI_WIDTH - 20,
                top + 225,
                PANEL_DARK
        );

        drawInventoryPanelFrame(
                g,
                left + 20,
                top + 128,
                GUI_WIDTH - 40,
                97
        );



        drawTradeSlotGrid(
                g,
                left + PiglinBarterMenu.GOLD_SLOT_1_X - 1,
                top + PiglinBarterMenu.TRADE_SLOT_Y - 1
        );

        drawTradeSlotGrid(
                g,
                left + PiglinBarterMenu.GOLD_SLOT_2_X - 1,
                top + PiglinBarterMenu.TRADE_SLOT_Y - 1
        );

        drawTradeSlotGrid(
                g,
                left + PiglinBarterMenu.REWARD_SLOT_X - 1,
                top + PiglinBarterMenu.TRADE_SLOT_Y - 1
        );


        final int inventoryX =
                left + PiglinBarterMenu.INVENTORY_START_X - 1;

        final int inventoryY =
                top + PiglinBarterMenu.INVENTORY_START_Y - 1;

        for (int row = 0;
             row < PiglinBarterMenu.INVENTORY_ROWS;
             row++) {

            for (int column = 0;
                 column < PiglinBarterMenu.INVENTORY_COLUMNS;
                 column++) {

                drawInventorySlotGrid(
                        g,
                        inventoryX
                                + column
                                * PiglinBarterMenu.SLOT_SIZE,
                        inventoryY
                                + row
                                * PiglinBarterMenu.SLOT_SIZE
                );
            }
        }



        final int hotbarY =
                top + PiglinBarterMenu.HOTBAR_Y - 1;

        for (int column = 0;
             column < PiglinBarterMenu.INVENTORY_COLUMNS;
             column++) {

            drawInventorySlotGrid(
                    g,
                    inventoryX
                            + column
                            * PiglinBarterMenu.SLOT_SIZE,
                    hotbarY
            );
        }



        drawMainFrame(
                g,
                left,
                top
        );
    }



    private void drawTradeSlotGrid(
            GuiGraphics g,
            int x,
            int y
    ) {

        g.fill(
                x - 1,
                y - 1,
                x + 19,
                y + 19,
                GRID_DARK
        );

        g.fill(
                x,
                y,
                x + 18,
                y + 1,
                GOLD
        );

        g.fill(
                x,
                y,
                x + 1,
                y + 18,
                GOLD_DARK
        );

        g.fill(
                x,
                y + 17,
                x + 18,
                y + 18,
                GOLD_DARK
        );

        g.fill(
                x + 17,
                y,
                x + 18,
                y + 18,
                GOLD_DARK
        );

        g.fill(
                x + 2,
                y + 2,
                x + 16,
                y + 16,
                0xFF120B0D
        );

        g.fill(
                x + 2,
                y + 2,
                x + 7,
                y + 3,
                GOLD_LIGHT
        );

        g.fill(
                x + 2,
                y + 2,
                x + 3,
                y + 7,
                GOLD_LIGHT
        );
    }



    private void drawInventorySlotGrid(
            GuiGraphics g,
            int x,
            int y
    ) {

        g.fill(
                x - 1,
                y - 1,
                x + 19,
                y + 19,
                GRID_DARK
        );

        g.fill(
                x,
                y,
                x + 18,
                y + 1,
                GOLD_DARK
        );

        g.fill(
                x,
                y,
                x + 1,
                y + 18,
                GOLD_DARK
        );

        g.fill(
                x,
                y + 17,
                x + 18,
                y + 18,
                GOLD_DARK
        );
        g.fill(
                x + 17,
                y,
                x + 18,
                y + 18,
                GOLD_DARK
        );

        g.fill(
                x + 2,
                y + 2,
                x + 16,
                y + 16,
                0xFF120B0D
        );
    }



    private void drawPanelFrame(
            GuiGraphics g,
            int x,
            int y,
            int width,
            int height
    ) {

        g.fill(
                x,
                y,
                x + width,
                y + 1,
                GOLD
        );

        g.fill(
                x,
                y + height - 1,
                x + width,
                y + height,
                GOLD_DARK
        );

        g.fill(
                x,
                y,
                x + 1,
                y + height,
                GOLD_DARK
        );

        g.fill(
                x + width - 1,
                y,
                x + width,
                y + height,
                GOLD_DARK
        );
    }



    private void drawInventoryPanelFrame(
            GuiGraphics g,
            int x,
            int y,
            int width,
            int height
    ) {

        g.fill(
                x,
                y,
                x + width,
                y + 1,
                GOLD_DARK
        );

        g.fill(
                x,
                y + height - 1,
                x + width,
                y + height,
                GOLD_DARK
        );

        g.fill(
                x,
                y,
                x + 1,
                y + height,
                GOLD_DARK
        );

        g.fill(
                x + width - 1,
                y,
                x + width,
                y + height,
                GOLD_DARK
        );
    }



    private void drawMainFrame(
            GuiGraphics g,
            int left,
            int top
    ) {

        g.fill(
                left + 2,
                top + 2,
                left + GUI_WIDTH - 2,
                top + 3,
                GOLD_DARK
        );

        g.fill(
                left + 3,
                top + 3,
                left + GUI_WIDTH - 3,
                top + 4,
                GOLD_LIGHT
        );

        g.fill(
                left + 2,
                top + GUI_HEIGHT - 3,
                left + GUI_WIDTH - 2,
                top + GUI_HEIGHT - 2,
                GOLD_DARK
        );

        g.fill(
                left + 2,
                top + 2,
                left + 3,
                top + GUI_HEIGHT - 2,
                GOLD_DARK
        );

        g.fill(
                left + GUI_WIDTH - 3,
                top + 2,
                left + GUI_WIDTH - 2,
                top + GUI_HEIGHT - 2,
                GOLD_DARK
        );

        drawCorner(
                g,
                left + 5,
                top + 5,
                0
        );

        drawCorner(
                g,
                left + GUI_WIDTH - 9,
                top + 5,
                1
        );

        drawCorner(
                g,
                left + 5,
                top + GUI_HEIGHT - 9,
                2
        );

        drawCorner(
                g,
                left + GUI_WIDTH - 9,
                top + GUI_HEIGHT - 9,
                3
        );
    }

    private void drawCorner(
            GuiGraphics g,
            int x,
            int y,
            int corner
    ) {
        if (corner == 0) {
            g.fill(
                    x,
                    y,
                    x + 4,
                    y + 1,
                    GOLD_LIGHT
            );
            g.fill(
                    x,
                    y,
                    x + 1,
                    y + 4,
                    GOLD_LIGHT
            );
        } else if (corner == 1) {
            g.fill(
                    x,
                    y,
                    x + 4,
                    y + 1,
                    GOLD_LIGHT
            );
            g.fill(
                    x + 3,
                    y,
                    x + 4,
                    y + 4,
                    GOLD_LIGHT
            );
        } else if (corner == 2) {
            g.fill(
                    x,
                    y + 3,
                    x + 4,
                    y + 4,
                    GOLD_LIGHT
            );
            g.fill(
                    x,
                    y,
                    x + 1,
                    y + 4,
                    GOLD_LIGHT
            );
        } else {
            g.fill(
                    x,
                    y + 3,
                    x + 4,
                    y + 4,
                    GOLD_LIGHT
            );
            g.fill(
                    x + 3,
                    y,
                    x + 4,
                    y + 4,
                    GOLD_LIGHT
            );
        }
    }




    private void renderHeader(
            GuiGraphics g
    ) {

        int center =
                leftPos
                        + GUI_WIDTH / 2;

        drawCentered(
                g,
                Component.translatable(
                        "screen.smartanimals.piglin_barter"
                ),
                center,
                topPos + 13,
                GOLD_LIGHT
        );

        drawCentered(
                g,
                Component.literal(
                        (menu.getCurrentPage() + 1)
                                + " / "
                                + PiglinBarterMenu.PAGE_COUNT
                ),
                center,
                topPos + 27,
                TEXT_DARK
        );
    }



    private void renderTradeInformation(
            GuiGraphics g
    ) {

        int center =
                leftPos
                        + GUI_WIDTH / 2;

        if (!menu.hasTrade()) {

            drawCentered(
                    g,
                    Component.translatable(
                            "screen.smartanimals.no_trade"
                    ),
                    center,
                    topPos + 82,
                    RED
            );

            return;
        }



        drawCentered(
                g,
                Component.literal(
                        menu.getPrice()
                                + " GOLD"
                ),
                center,
                topPos + 48,
                GOLD_LIGHT
        );



        int remaining =
                menu.getRemaining();

        int limit =
                menu.getPurchaseLimit();

        int color;

        if (remaining <= 0) {

            color = RED;

        } else if (remaining < limit) {

            color = ORANGE;

        } else {

            color = GREEN;
        }

        drawCentered(
                g,
                Component.literal(
                        remaining
                                + " / "
                                + limit
                ),
                center,
                topPos + 101,
                color
        );
    }



    private void renderDecorations(
            GuiGraphics g
    ) {

        int center =
                leftPos
                        + GUI_WIDTH / 2;



        g.fill(
                leftPos + 28,
                topPos + 120,
                leftPos + GUI_WIDTH - 28,
                topPos + 121,
                GOLD_DARK
        );

        g.fill(
                center - 4,
                topPos + 119,
                center + 4,
                topPos + 120,
                GOLD_LIGHT
        );



        drawCentered(
                g,
                Component.translatable(
                        "screen.smartanimals.inventory"
                ),
                center,
                topPos + 130,
                TEXT_DARK
        );
    }


    private void drawCentered(
            GuiGraphics g,
            Component text,
            int x,
            int y,
            int color
    ) {

        int width =
                font.width(text);

        g.drawString(
                font,
                text,
                x - width / 2,
                y,
                color,
                false
        );
    }



    @Override
    public boolean keyPressed(
            int keyCode,
            int scanCode,
            int modifiers
    ) {



        if (keyCode == 263) {

            changePage(-1);

            return true;
        }



        if (keyCode == 262) {

            changePage(1);

            return true;
        }

        return super.keyPressed(
                keyCode,
                scanCode,
                modifiers
        );
    }



    private class PiglinArrowButton extends Button {

        private final String arrow;

        public PiglinArrowButton(
                int x,
                int y,
                String arrow,
                Button.OnPress onPress
        ) {

            super(
                    x,
                    y,
                    20,
                    16,
                    Component.literal(arrow),
                    onPress,
                    Button.DEFAULT_NARRATION
            );

            this.arrow = arrow;
        }

        @Override
        protected void renderWidget(
                GuiGraphics g,
                int mouseX,
                int mouseY,
                float partialTick
        ) {



            int x = getX();
            int y = getY();
            int width = getWidth();
            int height = getHeight();



            int background =
                    isHovered()
                            ? 0xFF171011
                            : 0xFF080607;



            int border =
                    isHovered()
                            ? 0xFFC98A3D
                            : 0xFF8A5725;



            int arrowColor =
                    isHovered()
                            ? 0xFFFFFFFF
                            : 0xFFFFD978;



            g.fill(
                    x,
                    y,
                    x + width,
                    y + height,
                    background
            );



            g.fill(
                    x,
                    y,
                    x + width,
                    y + 1,
                    border
            );



            g.fill(
                    x,
                    y + height - 1,
                    x + width,
                    y + height,
                    border
            );



            g.fill(
                    x,
                    y,
                    x + 1,
                    y + height,
                    border
            );


            g.fill(
                    x + width - 1,
                    y,
                    x + width,
                    y + height,
                    border
            );



            int textWidth =
                    font.width(arrow);

            int textX =
                    x
                            + (width - textWidth)
                            / 2;

            int textY =
                    y
                            + (height - 8)
                            / 2;



            g.drawString(
                    font,
                    arrow,
                    textX,
                    textY,
                    arrowColor,
                    false
            );
        }
    }
}
